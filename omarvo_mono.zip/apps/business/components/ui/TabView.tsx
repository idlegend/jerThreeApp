import { Product, Victual, globalStyles } from '@omarvo/utils';
import { Image } from 'expo-image';
import { useEffect } from 'react';
import { Pressable, Text, View } from 'react-native';

interface Props {
  setCatPos: React.Dispatch<
    React.SetStateAction<
      {
        title: string;
        pos: number;
      }[]
    >
  >;
  calc: number;
  items: Record<string, Victual[] | Product[]>;
  handlePress: (itemId: string) => void;
}

const TabView: React.FC<Props> = ({ setCatPos, calc, items, handlePress }) => {
  useEffect(() => {
    setCatPos([{ title: 'all', pos: 0 }]);
  }, []);
  return (
    <View className="flex-1 px-5 space-y-6 py-4">
      {Object.keys(items)
        .sort((a, b) => (b === 'top selling' ? 1 : -1))
        .map((item) => (
          <View
            className="space-y-5 w-full"
            key={item}
            onLayout={(e) => {
              e.currentTarget.measure((x, y, w, h, px, py) => {
                setCatPos(
                  (prev) =>
                    (prev = [
                      ...prev,
                      { title: item, pos: Math.round(py - calc) },
                    ])
                );
              });
            }}
          >
            <Text
              className="text-base capitalize  text-mainBlack"
              style={[globalStyles.medium]}
            >
              {item}
            </Text>
            {items[item as keyof typeof items].map((i) => (
              <Pressable
                onPress={() => handlePress(i.id)}
                className="flex-row space-x-3 flex-1 overflow-hidden bg-background-300 rounded-r-lg items-center"
                key={i.id}
              >
                <Image
                  source={i?.media?.[0]?.url}
                  placeholder={i?.media?.[0]?.blur_hash}
                  style={{
                    width: 100,
                    height: 100,
                    borderTopLeftRadius: 4,
                    borderBottomLeftRadius: 4,
                  }}
                />
                <View className="w-auto max-w-[60%] space-y-2 ">
                  <Text
                    className="text-base flex-wrap text-mainBlack"
                    style={[globalStyles.regular]}
                  >
                    {i.name}
                  </Text>
                  <Text
                    className="text-base text-mainBlack "
                    style={[globalStyles.bold]}
                  >
                    ₦{i?.price?.toLocaleString()}
                  </Text>
                </View>
              </Pressable>
            ))}
          </View>
        ))}
    </View>
  );
};

export { TabView };
