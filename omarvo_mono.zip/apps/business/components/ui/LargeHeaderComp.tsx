import { View, Text, FlatList } from 'react-native';
import React from 'react';
import { LargeHeader, ScalingView } from '@codeherence/react-native-header';
import { Image } from 'expo-image';
import { Iconify } from 'react-native-iconify';
import { globalStyles } from '@omarvo/utils';
import { SharedValue } from 'react-native-reanimated';
import { SearchComponent, StatCard } from '@omarvo/ui';

interface Props {
  image?: string;
  name: string;
  description: string;
  scrollY: SharedValue<number>;
  stat: {
    value: string;
    desc: string;
  }[];
}

const LargeHeaderComp: React.FC<Props> = ({
  image,
  name,
  scrollY,
  description,
  stat,
}) => {
  return (
    <LargeHeader
      headerStyle={{
        paddingHorizontal: 0,
        paddingVertical: 0,
      }}
    >
      <View className="flex-1">
        <View className="border-b border-borderTwo w-full ">
          <View className="relative">
            <Image
              source={image}
              contentFit="cover"
              style={{ width: '100%', height: 274 }}
            />
            <View className="absolute top-0 left-0 right-0 bottom-0 justify-center items-center bg-black/50">
              <ScalingView scrollY={scrollY}>
                <Text
                  className="text-lg text-white"
                  style={[globalStyles.medium]}
                >
                  {name}
                </Text>
              </ScalingView>

              <View className="absolute right-0 top-0 p-5 flex-row space-x-6 items-center">
                <Iconify
                  icon="solar:clipboard-text-linear"
                  size={20}
                  color="#fff"
                />
                <Iconify
                  icon="iconamoon:discount-light"
                  size={24}
                  color="#fff"
                />
              </View>
            </View>
          </View>
          <View className="px-5 py-4">
            <Text
              className="text-mainBlack text-sm"
              style={[globalStyles.regular]}
            >
              {description}
            </Text>
          </View>
        </View>
        <View className="px-5 pt-6 pb-3" style={{ rowGap: 24 }}>
          <FlatList
            data={stat}
            renderItem={({ item }) => <StatCard {...item} />}
            numColumns={2}
            columnWrapperStyle={{
              columnGap: 16,
            }}
            contentContainerStyle={{
              rowGap: 16,
            }}
            style={{ rowGap: 16 }}
            scrollEnabled={false}
          />
          <SearchComponent />

          {/* <View> */}
          <Text
            className="text-base text-mainBlack "
            style={[globalStyles.bold]}
          >
            Categories
          </Text>
          {/* </View> */}
        </View>
      </View>
    </LargeHeader>
  );
};

export { LargeHeaderComp };
