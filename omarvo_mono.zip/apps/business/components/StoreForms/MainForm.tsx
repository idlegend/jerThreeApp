import { View, Text, Dimensions, Pressable, ScrollView } from 'react-native';
import React, { useState } from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { Campus, Category, Store, globalStyles } from '@omarvo/utils';
import {
  Button,
  DateTime,
  FullScreenModal,
  Input,
  MediaPicker,
  RadioGroupComp,
  Select,
  TextArea,
} from '@omarvo/ui';
import moment from 'moment';

const tabs = {
  weekdays: [1, 2, 3, 4, 5],
  weekends: [6, 0],
};

const daysArray = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

interface Props {
  data: Store;
  campuses: Campus[];
  categories: Category[];
  handleSubmit: (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => Promise<void>;
  onEditMode?: boolean;
}

const MainForm: React.FC<Props> = ({
  data,
  campuses,
  categories,
  handleSubmit,
  onEditMode = false,
}) => {
  const storeSchema = yup.object().shape({
    name: yup.string().required('This field is required.'),
    description: yup.string().required('This field is required.'),
    is_reg_business: yup.boolean().default(false),
    rc_number: yup.string().when('is_reg_business', {
      is: true,
      then: (schema) => schema.required('This field is required'),
      otherwise: (schema) => schema.optional(),
    }),
    school_address: yup
      .object({
        school_id: yup.string().required('This field is required'),
        campus_id: yup.string().required('This field is required'),
        on_campus: yup.boolean().required('This field is required'),
        is_entrepreneur: yup.boolean().default(true).optional(),
        base: yup.string().when('on_campus', {
          is: true,
          then: (schema) => schema.required('This field is required'),
        }),
        area: yup.string().when('on_campus', {
          is: false,
          then: (schema) => schema.required('This field is required'),
        }),
        landmark: yup.string().when('on_campus', {
          is: false,
          then: (schema) => schema.required('This field is required'),
        }),
      })
      .required('This field is required.'),
    opening_hours: yup
      .array(
        yup.object({
          day_of_week: yup.number().required('This field is required'),
          open_time: yup.date().optional(),
          close_time: yup.date().optional(),
        })
      )
      .required('This field is required.'),
    ...(onEditMode
      ? {}
      : {
          categories: yup
            .array(yup.string().required())
            .required('This field is required.'),
          store_banner: yup.object().required('This field is required.'),
        }),
  });

  type CreateStore = yup.InferType<typeof storeSchema>;

  const initialValues: CreateStore = {
    name: data.name,
    description: data.description,
    school_address: data.school_address,
    is_reg_business: data.is_reg_business,
    rc_number: data.rc_number,
    opening_hours: data.opening_hours?.map((item) => ({
      close_time: item.close_time ? new Date(item.close_time) : item.close_time,
      open_time: item.open_time ? new Date(item.open_time) : item.open_time,
      day_of_week: item.day_of_week,
    })),
    store_banner: data.store_banner,
    categories: data?.categories?.map((item) => item.id) || [],
  };

  const screenWidth = Dimensions.get('screen').width;
  const width = (screenWidth - 60) / 2;

  const [activeTab, setActiveTab] = useState<keyof typeof tabs>('weekdays');
  const [modalVisible, setModalVisible] = useState(false);

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values, { setSubmitting }) => {
        const body = {
          ...values,
          opening_hours: values.opening_hours
            ?.filter((i) => i.close_time && i.open_time)
            ?.map((item) => ({
              ...item,
              close_time: item.close_time!.toISOString().toString(),
              open_time: item.open_time!.toISOString().toString(),
            })),
        };
        handleSubmit(body, setSubmitting);
      }}
      validationSchema={storeSchema}
      validateOnMount
    >
      {({
        handleBlur,
        handleSubmit,
        errors,
        touched,
        values,
        setFieldValue,
        isSubmitting,
        isValid,
      }) => (
        <View className="py-6" style={{ rowGap: 52 }}>
          <View style={{ rowGap: 24 }}>
            <Input
              label="Name of Store"
              name="name"
              value={values.name}
              errors={errors.name}
              touched={touched.name}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Name"
              type="name"
              autoCapitalize="sentences"
            />
            <TextArea
              label="Description"
              name="description"
              value={values.description}
              errors={errors.description}
              touched={touched.description}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Description"
              type="none"
              autoCapitalize="sentences"
            />

            <View className="space-y-3">
              <Text
                className="text-sm text-[#6E7A8B]"
                style={globalStyles.medium}
              >
                Opening Hours
              </Text>
              <View className="p-4 rounded space-y-2 bg-[#FBFCFD] ">
                {!values.opening_hours.find(
                  (i) => i.close_time && i.open_time
                ) ? (
                  <Text
                    className="text-sm text-primaryThree"
                    style={[globalStyles.medium]}
                  >
                    You have no Opening hours.
                  </Text>
                ) : (
                  <>
                    {values.opening_hours
                      ?.filter((i) => i.open_time && i.close_time)
                      .map((i, index) => (
                        <View
                          key={index}
                          className="flex-row items-center space-x-2"
                        >
                          <Text
                            className="text-sm w-[20%] text-mainBlack"
                            style={[globalStyles.medium]}
                          >
                            {daysArray[i.day_of_week]}
                          </Text>
                          <Text
                            className="text-sm text-primaryThree"
                            style={[globalStyles.medium]}
                          >
                            {`${moment(i.open_time).format(
                              'h:mm A'
                            )} - ${moment(i.close_time).format('h:mm A')}`}
                          </Text>
                        </View>
                      ))}
                  </>
                )}
              </View>
              <Pressable onPress={() => setModalVisible(true)}>
                <Text
                  className="text-xs text-primaryOne"
                  style={[globalStyles.medium]}
                >
                  Tap here to Edit
                </Text>
              </Pressable>
            </View>

            {!onEditMode && (
              <>
                <Select
                  label="Select Categories"
                  name="categories"
                  value={values.categories}
                  errors={errors.categories}
                  touched={touched.categories}
                  handleChange={setFieldValue}
                  handleBlur={handleBlur}
                  placeholder="Select Categories"
                  items={categories.map((item) => ({
                    label: item.name,
                    value: item.id,
                  }))}
                  useDialog={false}
                  mode="MULTI"
                />

                <MediaPicker
                  label="Banner Image"
                  name="store_banner"
                  type="Images"
                  values={
                    values.store_banner ? [values.store_banner as any] : []
                  }
                  errors={errors.store_banner}
                  touched={touched.store_banner}
                  handleChange={setFieldValue}
                  handleBlur={handleBlur}
                />
              </>
            )}

            <RadioGroupComp
              label="Is this Store registered?"
              name="is_reg_business"
              value={values.is_reg_business}
              errors={errors.is_reg_business}
              touched={touched.is_reg_business}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              buttons={[
                {
                  label: 'Yes',
                  value: true,
                },
                {
                  label: 'No',
                  value: false,
                },
              ]}
            />

            {values.is_reg_business && (
              <Input
                label="RC Number"
                name="rc_number"
                value={values.rc_number}
                errors={errors.rc_number}
                touched={touched.rc_number}
                handleChange={setFieldValue}
                handleBlur={handleBlur}
                placeholder="Enter Registration Number"
                type="name"
                autoCapitalize="sentences"
              />
            )}

            {/* School Address */}
            <Select
              label="Select Campus"
              name="school_address.campus_id"
              value={values.school_address?.campus_id}
              errors={errors.school_address?.campus_id}
              touched={touched.school_address?.campus_id}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Select a Campus"
              items={campuses.map((item) => ({
                label: item.name,
                value: item.id,
              }))}
            />
            {values?.school_address?.campus_id && (
              <>
                <RadioGroupComp
                  label="Where is this store located?"
                  name="school_address.on_campus"
                  value={values.school_address?.on_campus}
                  errors={errors.school_address?.on_campus}
                  touched={touched.school_address?.on_campus}
                  handleChange={setFieldValue}
                  handleBlur={handleBlur}
                  buttons={[
                    {
                      label: 'On Campus',
                      value: true,
                    },
                    {
                      label: 'Off Campus',
                      value: false,
                    },
                  ]}
                />

                {values.school_address?.on_campus ? (
                  <>
                    <Select
                      label="Base"
                      name="school_address.base"
                      value={values.school_address?.base}
                      errors={errors.school_address?.base}
                      touched={touched.school_address?.base}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Select a Base"
                      items={
                        campuses
                          .find(
                            (c) =>
                              c.id.toString() ===
                              values.school_address?.campus_id.toString()
                          )
                          ?.bases?.map((item) => ({
                            label: item,
                            value: item,
                          })) || []
                      }
                    />
                  </>
                ) : (
                  <>
                    <Select
                      label="Area"
                      name="school_address.area"
                      value={values.school_address?.area}
                      errors={errors.school_address?.area}
                      touched={touched.school_address?.area}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Select a Area"
                      items={
                        campuses
                          .find(
                            (c) =>
                              c.id.toString() ===
                              values.school_address?.campus_id.toString()
                          )
                          ?.off_campus_areas?.map((item) => ({
                            label: item,
                            value: item,
                          })) || []
                      }
                    />
                    <TextArea
                      label="Description of Address/Landmark"
                      name="school_address.landmark"
                      value={values.school_address?.landmark || ''}
                      errors={errors.school_address?.landmark}
                      touched={touched.school_address?.landmark}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Enter address description or Landmark"
                      type="none"
                      mode="text"
                    />
                  </>
                )}
              </>
            )}
          </View>
          <Button
            text="Save"
            action={handleSubmit}
            loading={isSubmitting}
            disabled={!isValid}
          />
          {/* Modal */}
          <FullScreenModal modalVisible={modalVisible}>
            <ScrollView className="px-5 flex-1">
              <View className="space-y-2 pb-5">
                {/* Header */}
                <View className="items-center relative justify-center">
                  <Text
                    className="text-lg text-primaryOne"
                    style={[globalStyles.bold]}
                  >
                    Set Opening Hours
                  </Text>
                  <View className="absolute h-full right-0 top-0  justify-center items-center">
                    <Pressable onPress={() => setModalVisible(false)}>
                      <Text
                        className="text-sm text-primaryThree "
                        style={[globalStyles.medium]}
                      >
                        Save
                      </Text>
                    </Pressable>
                  </View>
                </View>
                <View className="space-y-6">
                  {/* Tabs */}
                  <View className="flex-row justify-evenly">
                    {Object.keys(tabs).map((key) => (
                      <Pressable
                        onPress={() => {
                          activeTab !== key &&
                            setActiveTab(key as keyof typeof tabs);
                        }}
                        key={key}
                        className={`p-4 w-auto  border-b  ${
                          activeTab === key
                            ? 'border-primaryOne'
                            : 'border-primaryThree'
                        } `}
                      >
                        <Text
                          className={` text-sm capitalize ${
                            activeTab === key
                              ? 'text-primaryOne'
                              : 'text-primaryThree'
                          }  `}
                          style={[globalStyles.medium]}
                        >
                          {key}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                  <View className="space-y-6">
                    {values.opening_hours
                      ?.filter((item) =>
                        tabs[activeTab].includes(item.day_of_week)
                      )
                      .map((item) => {
                        const index = values.opening_hours.findIndex(
                          (i) => i.day_of_week === item.day_of_week
                        );
                        const open_time =
                          values.opening_hours?.[index]?.open_time;
                        const close_time =
                          values.opening_hours?.[index]?.close_time;
                        return (
                          <View className="space-y-4" key={item.day_of_week}>
                            <Text
                              className="text-base text-primaryOne"
                              style={[globalStyles.bold]}
                            >
                              {daysArray[item.day_of_week]}
                            </Text>
                            <View className="space-y-2">
                              <View className="flex-row justify-between space-x-5">
                                <View style={{ width }}>
                                  <DateTime
                                    label="Open"
                                    name={`opening_hours.${index}.open_time`}
                                    value={open_time}
                                    errors={
                                      (errors.opening_hours?.[index] as any)
                                        ?.open_time
                                    }
                                    touched={
                                      (touched.opening_hours?.[index] as any)
                                        ?.open_time
                                    }
                                    handleChange={setFieldValue}
                                    handleBlur={handleBlur}
                                    placeholder="00:00"
                                    mode="time"
                                  />
                                </View>
                                <View style={{ width }}>
                                  <DateTime
                                    label="Close"
                                    name={`opening_hours.${index}.close_time`}
                                    value={close_time}
                                    errors={
                                      (errors.opening_hours?.[index] as any)
                                        ?.close_time
                                    }
                                    touched={
                                      (touched.opening_hours?.[index] as any)
                                        ?.close_time
                                    }
                                    handleChange={setFieldValue}
                                    handleBlur={handleBlur}
                                    placeholder="00:00"
                                    mode="time"
                                  />
                                </View>
                              </View>
                              {open_time && close_time && (
                                <Pressable
                                  onPress={() => {
                                    const newArray = values.opening_hours.map(
                                      (i) => {
                                        if (
                                          tabs[activeTab].includes(
                                            i.day_of_week
                                          )
                                        ) {
                                          return {
                                            ...i,
                                            close_time,
                                            open_time,
                                          };
                                        } else {
                                          return i;
                                        }
                                      }
                                    );
                                    setFieldValue('opening_hours', newArray);
                                  }}
                                >
                                  <Text
                                    className="text-xs text-primaryOne"
                                    style={[globalStyles.medium]}
                                  >
                                    Repeat for all
                                  </Text>
                                </Pressable>
                              )}
                            </View>
                          </View>
                        );
                      })}
                  </View>
                </View>
              </View>
            </ScrollView>
          </FullScreenModal>
        </View>
      )}
    </Formik>
  );
};

export default MainForm;
