import { View, Text, Dimensions } from 'react-native';
import React, { useEffect, useState } from 'react';
import { Category, Product, globalStyles } from '@omarvo/utils';
import { Formik } from 'formik';
import * as yup from 'yup';
import {
  Button,
  Input,
  MediaPicker,
  RadioGroupComp,
  Select,
  TextArea,
} from '@omarvo/ui';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface Props {
  data: Product;
  categories: Category[];
  handleSubmit: (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => Promise<void>;
  onEditMode?: boolean;
}

const ProductForm: React.FC<Props> = ({
  data,
  categories,
  handleSubmit,
  onEditMode = false,
}) => {
  const productSchema = yup.object().shape({
    name: yup.string().required('This field is required.'),
    description: yup.string().required('This field is required.'),
    price: yup.number().positive().required('This field is required'),
    quantity: yup.number().positive().required('This field is required'),
    is_negotiable: yup.boolean().default(false).nonNullable(),
    ...(onEditMode
      ? {}
      : {
          categories: yup
            .array(yup.string().required())
            .min(1)
            .required('This field is required.'),
          product_media: yup
            .array(yup.object())
            .min(1, 'You are to provide at least 1 media')
            .max(4, 'You are to provide at most 4 media')
            .required('This field is required'),
        }),
  });

  type ProductSchema = yup.InferType<typeof productSchema>;

  const initialValues: ProductSchema = {
    name: data.name,
    description: data.description,
    price: data.price,
    is_negotiable: data.is_negotiable,
    quantity: data.quantity,
    ...(onEditMode ? {} : { categories: [], product_media: [] }),
  };

  const { bottom, top } = useSafeAreaInsets();
  const [list, setList] = useState<Category[]>(categories);
  const [modalVisible, setModalVisible] = useState(false);

  const screenWidth = Dimensions.get('screen').width;
  const width = (screenWidth - 80) / 3;

  useEffect(() => {
    setList(categories);
  }, [categories]);

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values, { setSubmitting }) => {
        const body = {
          ...values,
        };
        handleSubmit(body, setSubmitting);
      }}
      validationSchema={productSchema}
      validateOnMount
    >
      {({
        handleBlur,
        handleSubmit,
        errors,
        touched,
        values,
        setFieldValue,
        isSubmitting,
        isValid,
        validateForm,
      }) => (
        <View className="py-6" style={{ rowGap: 52 }}>
          <View style={{ rowGap: 24 }}>
            <Input
              label="Name of Product"
              name="name"
              value={values.name}
              errors={errors.name}
              touched={touched.name}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Name"
              type="name"
              autoCapitalize="sentences"
            />
            <Input
              label="Price of Product"
              name="price"
              value={values.price ? values.price.toString() : ''}
              errors={errors.price}
              touched={touched.price}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Price"
              type="none"
              mode="decimal"
              leadingAccessory={
                <View className="bg-secondaryThree py-1 px-[10px] rounded ">
                  <Text
                    className="text-primaryOne text-base"
                    style={[globalStyles.regular]}
                  >
                    ₦
                  </Text>
                </View>
              }
              paddingLeft={54}
            />
            <Input
              label="Product Quantity"
              name="quantity"
              value={values.quantity ? values.quantity.toString() : ''}
              errors={errors.quantity}
              touched={touched.quantity}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Quantity"
              type="none"
              mode="numeric"
            />
            <TextArea
              label="Description"
              name="description"
              value={values.description}
              errors={errors.description}
              touched={touched.description}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Description"
              type="none"
              autoCapitalize="sentences"
            />
            <RadioGroupComp
              label="Is this product's price negotiable?"
              name="is_negotiable"
              value={values.is_negotiable}
              errors={errors.is_negotiable}
              touched={touched.is_negotiable}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              buttons={[
                {
                  label: 'Yes',
                  value: true,
                },
                {
                  label: 'No',
                  value: false,
                },
              ]}
            />
            {!onEditMode && (
              <Select
                label="Select Categories"
                name="categories"
                value={values.categories}
                errors={errors.categories}
                touched={touched.categories}
                handleChange={setFieldValue}
                handleBlur={handleBlur}
                placeholder="Select Categories"
                items={list.map((item) => ({
                  label: item.name.toCapitalized(),
                  value: item.id,
                }))}
                useDialog={false}
                mode="MULTI"
              />
            )}

            {!onEditMode && (
              <MediaPicker
                label="Product Media (Image, GIF)"
                name="product_media"
                type="Images"
                values={values.product_media as any}
                errors={errors.product_media}
                touched={touched.product_media}
                handleChange={setFieldValue}
                handleBlur={handleBlur}
                multiple
                limit={4}
              />
            )}
          </View>
          <Button
            text="Save"
            action={handleSubmit}
            loading={isSubmitting}
            disabled={!isValid}
          />
        </View>
      )}
    </Formik>
  );
};

export default ProductForm;
