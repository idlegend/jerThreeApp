import {
  View,
  Text,
  Platform,
  Pressable,
  Modal,
  ScrollView,
  Dimensions,
} from 'react-native';
import React, { useEffect, useState } from 'react';
import { Category, Victual, globalStyles, throwError } from '@omarvo/utils';
import { Formik } from 'formik';
import * as yup from 'yup';
import {
  Button,
  Empty,
  Input,
  MediaPicker,
  OverlayLoader,
  Select,
  TextArea,
} from '@omarvo/ui';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Iconify } from 'react-native-iconify';
import { Checkbox } from 'react-native-ui-lib';
import NoResult from '../../assets/svgs/no_result.svg';

interface Props {
  data: Victual;
  categories: Category[];
  handleSubmit: (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => Promise<void>;
  onEditMode?: boolean;
  handleDeleteSelection?: (selectionId: string) => Promise<any>;
  deletingSelection?: boolean;
}

const CreateVitualForm: React.FC<Props> = ({
  data,
  categories,
  handleSubmit,
  onEditMode = false,
  handleDeleteSelection,
  deletingSelection,
}) => {
  const victualSchema = yup.object().shape({
    name: yup.string().required('This field is required.'),
    description: yup.string().required('This field is required.'),
    price: yup.number().positive().required('This field is required'),
    selections: yup
      .array(
        yup.object({
          id: yup.string().notRequired().nullable().default(null),
          title: yup.string().required('This field is required'),
          is_required: yup.boolean().default(false),
          options: yup
            .array(
              yup.object({
                name: yup.string().required('This field is required'),
                upcharge: yup.number().optional().default(0),
              })
            )
            .min(1)
            .required('This field is required'),
        })
      )
      .optional()
      .default([]),
    ...(onEditMode
      ? {}
      : {
          categories: yup
            .array(yup.string().required())
            .min(1)
            .required('This field is required.'),
          victual_media: yup
            .array(yup.object())
            .min(1, 'You are to provide at least 1 media')
            .max(4, 'You are to provide at most 4 media')
            .required('This field is required'),
        }),
  });

  type VictualSchema = yup.InferType<typeof victualSchema>;

  const initialValues: VictualSchema = {
    name: data.name,
    description: data.description,
    price: data.price,
    selections: data.selections,
    ...(onEditMode ? {} : { categories: [], victual_media: [] }),
  };

  const { bottom, top } = useSafeAreaInsets();
  const [list, setList] = useState<Category[]>(categories);
  const [modalVisible, setModalVisible] = useState(false);

  const screenWidth = Dimensions.get('screen').width;
  const width = (screenWidth - 80) / 3;

  useEffect(() => {
    setList(categories);
  }, [categories]);

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values, { setSubmitting }) => {
        const body = {
          ...values,
        };
        handleSubmit(body, setSubmitting);
      }}
      validationSchema={victualSchema}
      validateOnMount
    >
      {({
        handleBlur,
        handleSubmit,
        errors,
        touched,
        values,
        setFieldValue,
        isSubmitting,
        isValid,
        validateForm,
      }) => (
        <View className="py-6" style={{ rowGap: 52 }}>
          <View style={{ rowGap: 24 }}>
            <Input
              label="Name of Food"
              name="name"
              value={values.name}
              errors={errors.name}
              touched={touched.name}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Name"
              type="name"
              autoCapitalize="sentences"
            />
            <Input
              label="Price of Food"
              name="price"
              value={values.price ? values.price.toString() : ''}
              errors={errors.price}
              touched={touched.price}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Price"
              type="none"
              mode="decimal"
              leadingAccessory={
                <View className="bg-secondaryThree py-1 px-[10px] rounded ">
                  <Text
                    className="text-primaryOne text-base"
                    style={[globalStyles.regular]}
                  >
                    ₦
                  </Text>
                </View>
              }
              paddingLeft={54}
            />
            <TextArea
              label="Description"
              name="description"
              value={values.description}
              errors={errors.description}
              touched={touched.description}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
              placeholder="Enter Description"
              type="none"
              autoCapitalize="sentences"
            />
            {!onEditMode && (
              <Select
                label="Select Categories"
                name="categories"
                value={values.categories}
                errors={errors.categories}
                touched={touched.categories}
                handleChange={setFieldValue}
                handleBlur={handleBlur}
                placeholder="Select Categories"
                items={list.map((item) => ({
                  label: item.name.toCapitalized(),
                  value: item.name,
                }))}
                useDialog={false}
                mode="MULTI"
                renderCustomSearch
                setMainList={setList}
              />
            )}

            <View className="space-y-3">
              <View className="flex-row">
                <Text
                  className="text-sm text-[#6E7A8B]"
                  style={globalStyles.medium}
                >
                  Selections
                </Text>
              </View>
              <View className="p-4 rounded space-y-2 bg-[#FBFCFD] ">
                {!values.selections.length ? (
                  <Text
                    className="text-sm text-primaryThree"
                    style={[globalStyles.medium]}
                  >
                    You have no Selections.
                  </Text>
                ) : (
                  <>
                    {values.selections?.map((s, index) => (
                      <View key={index}>
                        <Text
                          className="text-sm  text-mainBlack"
                          style={[globalStyles.regular]}
                        >{`${s.title} - ${s.options.length} option(s)`}</Text>
                      </View>
                    ))}
                  </>
                )}
              </View>
              <Pressable onPress={() => setModalVisible(true)}>
                <Text
                  className="text-xs text-primaryOne"
                  style={[globalStyles.medium]}
                >
                  Tap here to Edit
                </Text>
              </Pressable>
            </View>

            {!onEditMode && (
              <MediaPicker
                label="Victual Media (Image, GIF)"
                name="victual_media"
                type="Images"
                values={values.victual_media as any}
                errors={errors.victual_media}
                touched={touched.victual_media}
                handleChange={setFieldValue}
                handleBlur={handleBlur}
                multiple
                limit={4}
              />
            )}
          </View>
          <Button
            text="Save"
            action={handleSubmit}
            loading={isSubmitting}
            disabled={!isValid}
          />

          {/* Modal */}
          <Modal visible={modalVisible} animationType="slide">
            <View
              className="flex-1 bg-white"
              style={{
                paddingBottom: bottom,
                paddingTop: Platform.OS === 'ios' ? top : 16,
              }}
            >
              {/* Header */}
              <View className="items-center relative justify-center">
                <Text
                  className="text-lg text-primaryOne"
                  style={[globalStyles.bold]}
                >
                  Add Selections
                </Text>
                <View className="absolute h-full right-5 top-0  justify-center items-center">
                  <Pressable
                    onPress={async () => {
                      const res = await validateForm();
                      if (res?.selections) {
                        return throwError(
                          [
                            {
                              error:
                                'You must fill all or delete unnecessary fields to proceed',
                            },
                          ],
                          'Required Fields'
                        );
                      }
                      setModalVisible(false);
                    }}
                  >
                    <Text
                      className="text-sm text-primaryThree "
                      style={[globalStyles.medium]}
                    >
                      Save
                    </Text>
                  </Pressable>
                </View>
              </View>
              {values.selections.length < 1 ? (
                <Empty
                  text="Click the add button to add selections"
                  showButton={false}
                  svg={<NoResult />}
                />
              ) : (
                <ScrollView className="flex-1 px-5">
                  <View className="py-6 space-y-6">
                    {values.selections?.map((_, index) => {
                      const title = values.selections?.[index]?.title;
                      const id = values.selections?.[index]?.id;
                      const options = values.selections?.[index]?.options;
                      const isRequired =
                        values.selections?.[index]?.is_required;
                      const isRequiredName = `selections.${index}.is_required`;
                      return (
                        <View
                          className="space-y-4 bg-[#FBFCFD] p-3 rounded"
                          key={index}
                        >
                          <View className="flex-row justify-between items-center">
                            <Text
                              className="text-base text-primaryOne"
                              style={[globalStyles.bold]}
                            >
                              Selection {index + 1}
                            </Text>
                            <Pressable
                              onPress={async () => {
                                if (id) {
                                  const res = await handleDeleteSelection?.(id);
                                  if (res.error) {
                                    throwError(res?.payload);
                                    return;
                                  }
                                }

                                setFieldValue(
                                  'selections',
                                  values.selections?.filter(
                                    (_, i) => i !== index
                                  )
                                );
                              }}
                            >
                              <Iconify
                                icon="fluent:delete-20-filled"
                                size={20}
                                color="#BE4646"
                              />
                            </Pressable>
                          </View>

                          <View style={{ rowGap: 20 }}>
                            <Input
                              label="Title"
                              name={`selections.${index}.title`}
                              value={title}
                              errors={
                                (errors.selections?.[index] as any)?.title
                              }
                              touched={
                                (touched.selections?.[index] as any)?.title
                              }
                              handleChange={setFieldValue}
                              handleBlur={handleBlur}
                              placeholder="e.g Drink, Takeaway Pack, Side, Style e.t.c"
                              type="none"
                              bgColor="#FBFCFD"
                              autoCapitalize="sentences"
                            />
                            <View className="space-y-3">
                              <Text
                                className="text-sm text-primaryOne"
                                style={[globalStyles.medium]}
                              >
                                Options
                              </Text>
                              <View className="space-y-4">
                                {values?.selections?.[index]?.options?.map(
                                  (_, i) => {
                                    const name = options?.[i]?.name;
                                    const upcharge = options?.[i]?.upcharge;
                                    return (
                                      <View
                                        key={i}
                                        className="w-full flex-row space-x-4 items-start"
                                      >
                                        <View style={{ width: width * 2 }}>
                                          <Input
                                            label="Name"
                                            name={`selections.${index}.options.${i}.name`}
                                            value={name}
                                            errors={
                                              (
                                                errors.selections?.[
                                                  index
                                                ] as any
                                              )?.options?.[i]?.name
                                            }
                                            touched={
                                              (
                                                touched.selections?.[
                                                  index
                                                ] as any
                                              )?.options?.[i]?.name
                                            }
                                            handleChange={setFieldValue}
                                            handleBlur={handleBlur}
                                            bgColor="#FBFCFD"
                                            placeholder="Name"
                                            type="none"
                                            autoCapitalize="sentences"
                                          />
                                        </View>
                                        <View style={{ width: width }}>
                                          <Input
                                            label="Upcharge"
                                            name={`selections.${index}.options.${i}.upcharge`}
                                            value={upcharge?.toString()}
                                            errors={
                                              (
                                                errors.selections?.[
                                                  index
                                                ] as any
                                              )?.options?.[i]?.upcharge
                                            }
                                            touched={
                                              (
                                                touched.selections?.[
                                                  index
                                                ] as any
                                              )?.options?.[i]?.upcharge
                                            }
                                            handleChange={setFieldValue}
                                            handleBlur={handleBlur}
                                            bgColor="#FBFCFD"
                                            placeholder="Upcharge"
                                            type="none"
                                            mode="numeric"
                                            leadingAccessory={
                                              <View className="bg-secondaryThree py-1 px-[10px] rounded ">
                                                <Text
                                                  className="text-primaryOne text-base"
                                                  style={[globalStyles.regular]}
                                                >
                                                  ₦
                                                </Text>
                                              </View>
                                            }
                                            paddingLeft={54}
                                          />
                                        </View>
                                      </View>
                                    );
                                  }
                                )}
                              </View>
                              <View className="flex-row justify-between items-center ">
                                <Pressable
                                  onPress={() =>
                                    setFieldValue(
                                      'selections',
                                      values?.selections?.map((item, i) => {
                                        if (i === index) {
                                          return {
                                            ...item,
                                            options: [
                                              ...item.options,
                                              { name: '', upcharge: 0 },
                                            ],
                                          };
                                        } else {
                                          return item;
                                        }
                                      })
                                    )
                                  }
                                >
                                  <Text
                                    className="text-xs text-primaryOne"
                                    style={[globalStyles.medium]}
                                  >
                                    Add Another Option
                                  </Text>
                                </Pressable>

                                {values.selections?.[index]?.options?.length >
                                  1 && (
                                  <Pressable
                                    onPress={() =>
                                      setFieldValue(
                                        'selections',
                                        values?.selections?.map((item, i) => {
                                          if (i === index) {
                                            const cloned = [...item.options];
                                            cloned.pop();
                                            return {
                                              ...item,
                                              options: cloned,
                                            };
                                          } else {
                                            return item;
                                          }
                                        })
                                      )
                                    }
                                  >
                                    <Text
                                      className="text-xs text-primaryOne"
                                      style={[globalStyles.medium]}
                                    >
                                      Remove Last Option
                                    </Text>
                                  </Pressable>
                                )}
                              </View>
                            </View>
                            <Checkbox
                              value={isRequired}
                              onBlur={handleBlur(isRequiredName)}
                              onValueChange={(e) =>
                                setFieldValue(isRequiredName, e)
                              }
                              color="#00A082"
                              size={20}
                              style={{ borderRadius: 4 }}
                              label="Make it required"
                              labelStyle={[
                                globalStyles.medium,
                                { color: '#6E7A8B', fontSize: 14 },
                              ]}
                            />
                          </View>
                        </View>
                      );
                    })}
                  </View>
                </ScrollView>
              )}

              <Pressable
                onPress={() => {
                  setFieldValue('selections', [
                    ...values.selections,
                    {
                      title: '',
                      is_required: false,
                      options: [{ name: '', upcharge: 0 }],
                    },
                  ]);
                }}
                className="absolute bottom-[10%] right-3 bg-white  rounded-full"
              >
                <Iconify
                  icon="solar:add-circle-bold"
                  size={72}
                  color="#FFC244"
                />
              </Pressable>
              {deletingSelection && <OverlayLoader />}
            </View>
          </Modal>
        </View>
      )}
    </Formik>
  );
};

export default CreateVitualForm;
