import { Iconify } from 'react-native-iconify';
import OnboardingOne from '../assets/svgs/onboarding_1.svg';
import OnboardingTwo from '../assets/svgs/onboarding_2.svg';
import OnboardingThree from '../assets/svgs/onboarding_3.svg';
import OnboardingFour from '../assets/svgs/onboarding_4.svg';
import OnboardingFive from '../assets/svgs/onboarding_5.svg';
import { router } from 'expo-router';

export const slides = [
  {
    id: '1',
    title: 'Expand Your Flavour Horizon',
    description:
      'Reach a wider audience, increase visibility, and boost revenue by showcasing your delectable dishes on Omarvo.',
    image: <OnboardingOne />,
  },
  {
    id: '2',
    title: `Unlock Your Store's Potential`,
    description: `Tap into a thriving marketplace, connect with eager shoppers, and elevate your sales on Omarvo's dynamic platform.`,
    image: <OnboardingTwo />,
  },
  {
    id: '3',
    title: 'Showcase Your Craftsmanship',
    description: `Gain exposure, attract clients, and grow your business by offering your unique services to Omarvo's diverse user base.`,
    image: <OnboardingThree />,
  },
  {
    id: '4',
    title: 'Make Every Event Unforgettable',
    description: `Promote your events to a captivated audience, sell tickets seamlessly, and create memorable experiences with Omarvo's event platform.`,
    image: <OnboardingFour />,
  },
  {
    id: '5',
    title: 'Effortless Delivery Excellence',
    description: `Deliver your products promptly and reliably with Omarvo's efficient logistics, ensuring satisfied customers who keep coming back for more.`,
    image: <OnboardingFive />,
  },
];

export const openingHoursBase = [
  {
    day_of_week: 1,
    close_time: undefined,
    open_time: undefined,
  },
  {
    day_of_week: 2,
    close_time: undefined,
    open_time: undefined,
  },
  {
    day_of_week: 3,
    close_time: undefined,
    open_time: undefined,
  },
  {
    day_of_week: 4,
    close_time: undefined,
    open_time: undefined,
  },
  {
    day_of_week: 5,
    close_time: undefined,
    open_time: undefined,
  },
  {
    day_of_week: 6,
    close_time: undefined,
    open_time: undefined,
  },
  {
    day_of_week: 0,
    close_time: undefined,
    open_time: undefined,
  },
];

export const sections = [
  {
    icon: <Iconify icon="ion:restaurant-sharp" size={16} color="#fff" />,
    name: 'Restaurants',
    description: 'Build your menu and reach more customers nearby',
    primaryColor: '#DDDDFD',
    secondaryColor: '#4C4CC3',
    handlePress: () => router.push('/(main)/restaurants/'),
  },
  {
    icon: <Iconify icon="streamline:store-1-solid" size={16} color="#fff" />,
    name: 'Stores',
    description: 'Find nearby stores for all your shopping needs',
    primaryColor: '#FDF1DD',
    secondaryColor: '#E8B053',
    handlePress: () => router.push('/(main)/stores/'),
  },
];
