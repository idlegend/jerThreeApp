module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      'nativewind/babel',
      'react-native-iconify/plugin',
      'react-native-reanimated/plugin',
    ],
  };
};
