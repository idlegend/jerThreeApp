import { View, Text, ScrollView, Pressable } from 'react-native';
import React, { useEffect } from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { getCountryActiveStates, setEntrepreneurLocation } from '@omarvo/store';
import { Button, Loader, RegisterHeader, Select } from '@omarvo/ui';
import RegisterSvg from '../../../assets/svgs/register.svg';
import { globalStyles } from '@omarvo/utils';

const stateSchema = yup.object().shape({
  state_id: yup.string().required('This field is required.'),
});

interface stateValues {
  state_id: string;
}

const ChooseState = () => {
  const { states, statesLoading } = useAppSelector((state) => state.css);
  const { location } = useAppSelector((state) => state.entrepreneurRegister);

  const initialValues: stateValues = {
    state_id: location.state_id,
  };

  const { bottom } = useSafeAreaInsets();

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!location.country_id) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    dispatch(
      getCountryActiveStates({ signal, country_id: location.country_id })
    );

    return () => controller.abort();
  }, [location.country_id]);

  if (statesLoading) {
    return <Loader />;
  }

  return (
    <View
      className="flex-1 bg-white"
      style={{
        paddingBottom: bottom,
      }}
    >
      <ScrollView bounces={false} className="px-5">
        <View
          className=" py-4"
          style={{
            rowGap: 36,
          }}
        >
          <RegisterHeader
            title="Choose State"
            subText="Please provide your current residual location"
            Svg={RegisterSvg}
          />
          <Formik
            initialValues={initialValues}
            onSubmit={(values, { setSubmitting }) => {
              dispatch(setEntrepreneurLocation({ data: values }));
              setSubmitting(false);
              router.push('/auth/register/choose_school');
            }}
            validationSchema={stateSchema}
            validateOnMount
          >
            {({
              setFieldValue,
              handleBlur,
              handleSubmit,
              errors,
              touched,
              values,
              isSubmitting,
              isValid,
            }) => (
              <View
                style={{
                  rowGap: 36,
                }}
              >
                <View
                  style={{
                    rowGap: 24,
                  }}
                >
                  <View className="space-y-2">
                    <Select
                      label="Find State"
                      name="state_id"
                      value={values.state_id}
                      errors={errors.state_id}
                      touched={touched.state_id}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Select a State"
                      items={states.map((item) => ({
                        label: item.name,
                        value: item.id,
                      }))}
                    />
                    <View className="flex-row">
                      <Pressable
                        onPress={() =>
                          router.push('/auth/register/submit_location')
                        }
                      >
                        <Text
                          className="text-primaryOne text-xs"
                          style={[globalStyles.medium]}
                        >
                          Couldn’t Find Your State ?
                        </Text>
                      </Pressable>
                    </View>
                  </View>
                </View>
                <Button
                  text="Continue"
                  action={handleSubmit}
                  disabled={!isValid}
                  loading={isSubmitting}
                />
              </View>
            )}
          </Formik>
        </View>
      </ScrollView>
    </View>
  );
};

export default ChooseState;
