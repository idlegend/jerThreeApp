import React, { useEffect, useState } from 'react';
import { useRouter } from 'expo-router';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { Loader, Verification, messageAlert } from '@omarvo/ui';
import {
  postEntrepreneurResendOTP,
  postEntrepreneurVerfifyAccount,
} from '@omarvo/store';
import { throwError } from '@omarvo/utils';
import VerifcationSvg from '../../../assets/svgs/verification.svg';

const VerifyUserAccount = () => {
  const [value, setValue] = useState('');
  const router = useRouter();
  const [isLoading, setLoading] = useState(true);
  const { email, loading, resending } = useAppSelector(
    (state) => state.entrepreneurRegister
  );

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!email) {
      router.back();
    }
    setLoading(false);
  }, [email]);

  if (isLoading) {
    return <Loader />;
  }

  const handleVerify = async () => {
    const res: any = await dispatch(
      postEntrepreneurVerfifyAccount({ email, otp: value })
    );
    if (res.error) {
      throwError(res?.payload);
      return;
    }
    router.push('/auth/register/success');
  };

  const handleResendOTP = async () => {
    const res: any = await dispatch(postEntrepreneurResendOTP({ email }));
    if (res.error) {
      throwError(res?.payload);
      return;
    }
    messageAlert('Success', 'OTP resent successfully');
  };

  return (
    <Verification
      email={email}
      value={value}
      Svg={VerifcationSvg}
      setValue={setValue}
      handleVerify={handleVerify}
      handleResendOTP={handleResendOTP}
      loading={loading}
      resending={resending}
      initSec={300}
    />
  );
};

export default VerifyUserAccount;
