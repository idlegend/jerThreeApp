import { View, Text, ScrollView, Pressable } from 'react-native';
import React from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Globalization from '../../../assets/svgs/globalization.svg';
import { router } from 'expo-router';
import { globalStyles } from '@omarvo/utils';
import { Button, Globe } from '@omarvo/ui';

const SelectCountry = () => {
  const { top, bottom } = useSafeAreaInsets();
  return (
    <View className="flex-1 bg-primaryOne">
      <View
        className="flex-[0.55]  "
        style={{
          paddingTop: top,
        }}
      >
        <ScrollView bounces={false} className="px-5 py-5  ">
          <View className="items-center">
            <Globalization />
            <View className="items-center space-y-[11px]">
              <Text
                className="text-2xl text-white "
                style={[globalStyles.medium]}
              >
                Let’s Find Your Location
              </Text>
              <Text
                className="text-base text-white text-center "
                style={[globalStyles.regular]}
              >
                Help us enhance your experience by sharing your current
                location, allowing us to personalize our services and
                recommendations to your specific area
              </Text>
            </View>
          </View>
        </ScrollView>
      </View>
      <View
        className="flex-[0.45]  bg-mainGray "
        style={{
          paddingBottom: bottom,
        }}
      >
        <ScrollView bounces={false} className="px-5 py-[18px] ">
          <View className="space-y-10">
            <View className="space-y-5">
              <View className="space-y-2">
                <Text
                  className="text-xl text-mainBlack "
                  style={[globalStyles.medium]}
                >
                  Set Up Your Location
                </Text>
                <Text
                  className="text-base text-mainBlack "
                  style={[globalStyles.regular]}
                >
                  We‘ll help you set up so you can get Customers, clients, and
                  users services around you to connect with your business.
                </Text>
              </View>
              <View className="bg-mainWhite p-4 rounded-xl">
                <View className="flex-row justify-between items-center ">
                  <View className="flex-row items-center space-x-3 ">
                    <Globe />
                    <Text
                      className="text-mainBlack text-base "
                      style={[globalStyles.regular]}
                    >
                      Nigeria
                    </Text>
                  </View>
                  <View className="w-[22px] h-[22px] border border-primaryOne rounded-full items-center p-[3px] justify-center  ">
                    <View className="w-full h-full bg-primaryOne rounded-full "></View>
                  </View>
                </View>
              </View>
            </View>
            <View className="w-full space-y-5 ">
              <Button
                text="Continue"
                action={() => router.push('/auth/register/choose_state')}
              />
              <View className="w-full flex-row items-center space-x-1 justify-center ">
                <Text
                  className="text-mainBlack"
                  style={[globalStyles.regular, { fontSize: 16 }]}
                >
                  Already have an account?{' '}
                </Text>
                <Pressable
                  onPress={() =>
                    router.canGoBack()
                      ? router.back()
                      : router.push('/auth/login')
                  }
                >
                  <Text
                    className="text-primaryOne "
                    style={[globalStyles.medium, { fontSize: 16 }]}
                  >
                    Sign in
                  </Text>
                </Pressable>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

export default SelectCountry;
