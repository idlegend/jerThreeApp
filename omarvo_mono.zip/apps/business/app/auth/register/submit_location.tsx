import { View, Text, ScrollView } from 'react-native';
import React, { useState } from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { router } from 'expo-router';
import SendLocation from '../../../assets/svgs/submit_location.svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SlSuccess from '../../../assets/svgs/rp_success.svg';
import { globalStyles } from '@omarvo/utils';
import { Button, FullScreenModal, Input, Select, TextArea } from '@omarvo/ui';

const stateSchema = yup.object().shape({
  email: yup.string().email().required('This field is required.'),
  state: yup.string().required('This field is required.'),
  school: yup.string().required('This field is required.'),
  via: yup.string().required('This field is required.'),
  feedback: yup.string(),
});

interface stateValues {
  email: string;
  state: string;
  school: string;
  via: string;
  feedback: string;
}

const SubmitLocation = () => {
  const { bottom } = useSafeAreaInsets();

  const [modalVisible, setModalVisible] = useState(false);

  const initialValues: stateValues = {
    email: '',
    state: '',
    school: '',
    via: '',
    feedback: '',
  };

  return (
    <View
      className="flex-1 bg-white"
      style={{
        paddingBottom: bottom,
      }}
    >
      <ScrollView className="px-5 flex-1 ">
        <View
          className="py-4"
          style={{
            rowGap: 36,
          }}
        >
          <View className="items-center space-y-2 ">
            <SendLocation />
            <View className="items-center space-y-4">
              <Text
                className="text-center text-base text-mainBlack "
                style={[globalStyles.regular]}
              >
                We are sorry you couldn’t find your location on Omarvo, but
                we’ve got good news!
              </Text>
              <Text
                className="text-center text-base text-mainBlack "
                style={[globalStyles.regular]}
              >
                Kindly help us fill out your location details and your email so
                you will be the first to know when we expand to your vicinity 🤗
              </Text>
            </View>
          </View>
          <Formik
            initialValues={initialValues}
            onSubmit={async (values, { setSubmitting }) => {
              // Perform action here

              setSubmitting(false);
              setModalVisible(true);
            }}
            validationSchema={stateSchema}
            validateOnMount
          >
            {({
              setFieldValue,
              handleBlur,
              handleSubmit,
              errors,
              touched,
              values,
              isSubmitting,
              isValid,
            }) => (
              <View
                style={{
                  rowGap: 36,
                }}
              >
                <View
                  style={{
                    rowGap: 24,
                  }}
                >
                  <Input
                    label="Input your Email"
                    name="email"
                    value={values.email}
                    errors={errors.email}
                    touched={touched.email}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter email address"
                    type="emailAddress"
                    mode="email"
                  />
                  <Input
                    label="Input your State"
                    name="state"
                    value={values.state}
                    errors={errors.state}
                    touched={touched.state}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter state"
                    type="addressState"
                    mode="text"
                  />
                  <Input
                    label="Input your School"
                    name="school"
                    value={values.school}
                    errors={errors.school}
                    touched={touched.school}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter school"
                    type="organizationName"
                    mode="text"
                  />

                  <Select
                    label="How did you hear about us?"
                    name="via"
                    value={values.via}
                    errors={errors.via}
                    touched={touched.via}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Via Facebook"
                    showLeadingAccessory={false}
                    showSearch={false}
                    items={[
                      {
                        label: 'Facebook',
                        value: 'facebook',
                      },
                      {
                        label: 'Twitter',
                        value: 'twitter',
                      },
                      {
                        label: 'Instagram',
                        value: 'instagram',
                      },
                      {
                        label: 'Whatsapp',
                        value: 'whatsapp',
                      },
                      {
                        label: 'Google',
                        value: 'google',
                      },
                      {
                        label: 'Youtube',
                        value: 'youtube',
                      },
                      {
                        label: 'Other',
                        value: 'other',
                      },
                    ]}
                  />

                  <TextArea
                    label="Any feedback you would like us to know?"
                    name="feedback"
                    value={values.feedback}
                    errors={errors.feedback}
                    touched={touched.feedback}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter feedback"
                    type="none"
                    mode="text"
                  />
                </View>
                <Button
                  text="Submit Information"
                  action={handleSubmit}
                  disabled={!isValid}
                  loading={isSubmitting}
                />
              </View>
            )}
          </Formik>
        </View>
      </ScrollView>
      <FullScreenModal modalVisible={modalVisible}>
        <ScrollView className="px-5 flex-1">
          <View className=" py-4 items-center space-y-12 ">
            <View className="items-center">
              <SlSuccess />
              <View className="items-center space-y-2">
                <Text
                  className="text-lg text-mainBlack "
                  style={[globalStyles.medium]}
                >
                  Congratulation!🎉
                </Text>
                <Text
                  className="text-base text-mainBlack  text-center"
                  style={[globalStyles.regular]}
                >
                  We now have your information so we can keep you updated as
                  soon as we get to your vicinity. We can't wait for you to be
                  part of our journey together. Stay tuned!
                </Text>
              </View>
            </View>
            <View className="w-full">
              <Button
                text="Done"
                action={() => {
                  setModalVisible(false);
                  router.push('/');
                }}
              />
            </View>
          </View>
        </ScrollView>
      </FullScreenModal>
    </View>
  );
};

export default SubmitLocation;
