import { View, Text, ScrollView, Pressable } from 'react-native';
import React, { useEffect } from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { getCountryStateSchools, setEntrepreneurLocation } from '@omarvo/store';
import { Button, Loader, RegisterHeader, Select } from '@omarvo/ui';
import RegisterSvg from '../../../assets/svgs/register.svg';
import { globalStyles } from '@omarvo/utils';

const schoolSchema = yup.object().shape({
  state_id: yup.string().required('This field is required.'),
  school_id: yup.string().required('This field is required.'),
});

interface schoolValues {
  state_id: string;
  school_id: string;
}

const ChooseSchool = () => {
  const { schools, states, schoolsLoading } = useAppSelector(
    (state) => state.css
  );
  const { location } = useAppSelector((state) => state.entrepreneurRegister);

  const initialValues: schoolValues = {
    state_id: location.state_id,
    school_id: location.school_id,
  };

  const { bottom } = useSafeAreaInsets();

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!location.country_id || !location.state_id) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    dispatch(
      getCountryStateSchools({
        signal,
        country_id: location.country_id,
        state_id: location.state_id,
      })
    );

    return () => controller.abort();
  }, [location.country_id, location.state_id]);

  if (schoolsLoading) {
    return <Loader />;
  }

  return (
    <View
      className="flex-1 bg-white"
      style={{
        paddingBottom: bottom,
      }}
    >
      <ScrollView bounces={false} className="px-5">
        <View
          className="py-4"
          style={{
            rowGap: 36,
          }}
        >
          <RegisterHeader
            title="Choose School"
            subText="Please provide your current residual location"
            Svg={RegisterSvg}
          />
          <Formik
            initialValues={initialValues}
            onSubmit={(values, { setSubmitting }) => {
              dispatch(setEntrepreneurLocation({ data: values }));
              setSubmitting(false);
              router.push('/auth/register/');
            }}
            validationSchema={schoolSchema}
            validateOnMount
          >
            {({
              setFieldValue,
              handleBlur,
              handleSubmit,
              errors,
              touched,
              values,
              isSubmitting,
              isValid,
            }) => (
              <View
                style={{
                  rowGap: 36,
                }}
              >
                <View
                  style={{
                    rowGap: 24,
                  }}
                >
                  <Select
                    label="Find State"
                    name="state_id"
                    value={values.state_id}
                    errors={errors.state_id}
                    touched={touched.state_id}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Select a State"
                    items={states.map((item) => ({
                      label: item.name,
                      value: item.id,
                    }))}
                    disabled
                  />

                  <View className="space-y-2">
                    <Select
                      label="Find School"
                      name="school_id"
                      value={values.school_id}
                      errors={errors.school_id}
                      touched={touched.school_id}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Select a School"
                      items={schools.map((item) => ({
                        label: item.name,
                        value: item.id,
                      }))}
                    />
                    <View className="flex-row">
                      <Pressable
                        onPress={() =>
                          router.push('/auth/register/submit_location')
                        }
                      >
                        <Text
                          className="text-primaryOne text-xs"
                          style={[globalStyles.medium]}
                        >
                          Couldn’t Find Your School?
                        </Text>
                      </Pressable>
                    </View>
                  </View>
                </View>
                <Button
                  text="Continue to Sign up"
                  action={handleSubmit}
                  disabled={!isValid}
                />
              </View>
            )}
          </Formik>
        </View>
      </ScrollView>
    </View>
  );
};

export default ChooseSchool;
