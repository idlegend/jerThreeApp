import React from 'react';
import SuccessSvg from '../../../assets/svgs/rp_success.svg';
import { useNavigation } from 'expo-router';
import { Success } from '@omarvo/ui';

const ResetPasswordSuccess = () => {
  const navigation = useNavigation();

  return (
    <Success
      Svg={SuccessSvg}
      message="You have successfully reset your password"
      buttonText="Login"
      action={() => navigation.dispatch({ type: 'POP_TO_TOP' })}
    />
  );
};

export default ResetPasswordSuccess;
