import { useState } from 'react';
import { router } from 'expo-router';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import {
  postEntrepreneurVerifyEmail,
  postEntrepreneurForgotEmail,
} from '@omarvo/store';
import { throwError } from '@omarvo/utils';
import { Verification, messageAlert } from '@omarvo/ui';
import VerifcationSvg from '../../../assets/svgs/verification.svg';

export default function PasswordOTP() {
  const dispatch = useAppDispatch();
  const [resending, setResending] = useState(false);
  const { email } = useAppSelector((state) => state.entrepreneurForgotPassword);
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);

  const handleVerify = async () => {
    setLoading(true);
    const res: any = await dispatch(
      postEntrepreneurVerifyEmail({ email, otp })
    );
    if (res.error) {
      setLoading(false);
      throwError(res?.payload);
      return;
    }
    setLoading(false);
    router.replace('/auth/forgot_password/reset_password');
  };

  const handleResendOTP = async () => {
    setResending(true);
    const res: any = await dispatch(postEntrepreneurForgotEmail({ email }));
    if (res.error) {
      setResending(false);
      throwError(res?.payload);
      return;
    }
    setResending(false);
    messageAlert('Success', 'OTP resent successfully');
  };

  const values = {
    email,
    value: otp,
    setValue: setOtp,
    handleVerify,
    handleResendOTP: handleResendOTP,
    loading,
    resending: false,
    Svg: VerifcationSvg,
  };

  return <Verification {...values} buttonText="Verify" resending={resending} />;
}
