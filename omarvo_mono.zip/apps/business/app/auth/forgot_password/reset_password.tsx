import { ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import VerifcationSvg from '../../../assets/svgs/verification.svg';
import * as yup from 'yup';
import { Formik } from 'formik';
import { router } from 'expo-router';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { globalStyles, throwError } from '@omarvo/utils';
import { postEntrepreneurResetPassword } from '@omarvo/store';
import { Button, Input } from '@omarvo/ui';

interface resetPasswordValue {
  new_password: string;
  confirm_password: string;
}

const resetPasswordSchema = yup.object().shape({
  new_password: yup
    .string()
    .required('Password is required')
    .min(8, 'Password must be at least 8 characters long')
    .matches(/[a-z]/, 'Password must contain at least one lowercase letter')
    .matches(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .matches(/[0-9]/, 'Password must contain at least one number'),
  confirm_password: yup
    .string()
    .required('This field is required')
    .oneOf([yup.ref('new_password')], 'Passwords must match'),
});

export default function ResetPassword() {
  const token = useAppSelector(
    (state) => state.entrepreneurForgotPassword.token
  );
  const initialValues: resetPasswordValue = {
    new_password: '',
    confirm_password: '',
  };

  const { bottom, top } = useSafeAreaInsets();

  const dispatch = useAppDispatch();

  return (
    <View
      className="flex-1 bg-white"
      style={{
        paddingBottom: bottom,
        paddingTop: top,
      }}
    >
      <ScrollView bounces={false} className="px-5 ">
        <View className="py-6" style={{ rowGap: 36 }}>
          <View className="w-full space-y-6 items-center ">
            <VerifcationSvg />
            <View className="w-full flex flex-col items-center space-y-2 pb-10">
              <Text
                className="text-2xl text-center"
                style={[globalStyles.medium, globalStyles.textGreen]}
              >
                Reset Password
              </Text>
              <Text
                className="text-center text-base "
                style={[globalStyles.regular]}
              >
                Please Input your new password
              </Text>
            </View>
            <Formik
              initialValues={initialValues}
              onSubmit={async (values, { setSubmitting }) => {
                const res: any = await dispatch(
                  postEntrepreneurResetPassword({
                    reset_token: token,
                    password: values.confirm_password,
                  })
                );
                if (res.error) {
                  throwError(res?.payload);
                  return;
                }
                setSubmitting(false);
                router.replace('/auth/forgot_password/rp_success');
              }}
              validationSchema={resetPasswordSchema}
              validateOnMount
            >
              {({
                setFieldValue,
                handleBlur,
                handleSubmit,
                errors,
                touched,
                values,
                isSubmitting,
                isValid,
              }) => (
                <View
                  className="w-full"
                  style={{
                    rowGap: 36,
                  }}
                >
                  <View
                    style={{
                      rowGap: 24,
                    }}
                  >
                    <Input
                      label="New Password"
                      name="new_password"
                      value={values.new_password}
                      errors={errors.new_password}
                      touched={touched.new_password}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Enter password"
                      type="password"
                      secureTextEntry={true}
                    />
                    <Input
                      label="Confirm Password"
                      name="confirm_password"
                      value={values.confirm_password}
                      errors={errors.confirm_password}
                      touched={touched.confirm_password}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Re-enter password"
                      type="password"
                      secureTextEntry={true}
                    />
                    <Button
                      styles={{ marginTop: 34 }}
                      text="Submit"
                      action={handleSubmit}
                      loading={isSubmitting}
                      disabled={!isValid}
                    />
                  </View>
                </View>
              )}
            </Formik>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
