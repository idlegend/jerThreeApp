import React, { useEffect, useState } from 'react';
import { Redirect, Stack } from 'expo-router';
import { StatusBar } from 'react-native';
import { getSecureValueFor, options } from '@omarvo/utils';
import { Loader } from '@omarvo/ui';

const AuthLayout = () => {
  StatusBar.setBarStyle('dark-content');

  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    getSecureValueFor('entrepreneurToken').then((token) => {
      setToken(token);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <Loader />;
  }

  if (token) {
    return <Redirect href="/(main)/(tabs)/" />;
  }

  return (
    <Stack>
      <Stack.Screen name="login" options={{ ...options, headerShown: false }} />
      <Stack.Screen
        name="register/choose_country"
        options={{ ...options, headerShown: false }}
      />
      <Stack.Screen
        name="register/choose_state"
        options={{
          ...options,
          title: 'Choose State',
        }}
      />
      <Stack.Screen
        name="register/choose_school"
        options={{ ...options, title: 'Choose School' }}
      />
      <Stack.Screen
        name="register/submit_location"
        options={{ ...options, title: 'Submit Location' }}
      />
      <Stack.Screen
        name="register/index"
        options={{ ...options, title: 'Create Account' }}
      />
      <Stack.Screen
        name="register/verify"
        options={{ ...options, headerShown: false }}
      />
      <Stack.Screen
        name="register/success"
        options={{ ...options, headerShown: false }}
      />
      <Stack.Screen
        name="forgot_password/get_otp"
        options={{ ...options, headerShown: false }}
      />
      <Stack.Screen
        name="forgot_password/password_otp"
        options={{ ...options, headerShown: false }}
      />
      <Stack.Screen
        name="forgot_password/reset_password"
        options={{ ...options, headerShown: false }}
      />
      <Stack.Screen
        name="forgot_password/rp_success"
        options={{ ...options, headerShown: false }}
      />
    </Stack>
  );
};

export default AuthLayout;
