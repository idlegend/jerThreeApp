import { View, FlatList } from 'react-native';
import React, { useEffect } from 'react';
import { Empty, EnBusinessCard, Loader } from '@omarvo/ui';
import NoResult from '../../../assets/svgs/no_result.svg';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { getEntrepreneurRestaurants } from '@omarvo/store';
import { router } from 'expo-router';

const RestaurantScreen = () => {
  const { loading, list } = useAppSelector(
    (state) => state.entrepreneurRestaurant
  );

  const dispatch = useAppDispatch();

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;

    dispatch(getEntrepreneurRestaurants({ signal }));

    return () => {
      controller.abort();
    };
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <View className="flex-1 bg-white ">
      {list.length < 1 ? (
        <Empty
          text="Restaurant has not been created yet. Click below to get started"
          buttonText="Create Restaurant"
          svg={<NoResult />}
          action={() => router.push('/(main)/restaurants/create')}
        />
      ) : (
        <FlatList
          data={list}
          renderItem={({ item }) => (
            <EnBusinessCard
              {...item}
              action={() => router.push(`/(main)/restaurants/${item.id}/`)}
            />
          )}
          style={{ padding: 20, flex: 1 }}
        />
      )}
    </View>
  );
};

export default RestaurantScreen;
