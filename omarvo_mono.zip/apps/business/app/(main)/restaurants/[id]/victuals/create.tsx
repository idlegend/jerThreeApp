import { View, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { createVictual, getVictualCategories } from '@omarvo/store';
import { FullScreenModal, Loader, Success } from '@omarvo/ui';
import { Victual, formatFormData, throwError } from '@omarvo/utils';
import VitualForm from 'apps/business/components/RestaurantForms/VitualForm';
import { router, useLocalSearchParams } from 'expo-router';
import SuccessSvg from '../../../../../assets/svgs/rp_success.svg';

const CreateVictual = () => {
  const { id } = useLocalSearchParams<{ id: string }>();

  const { victualCategories: categories } = useAppSelector(
    (state) => state.categories
  );
  const { bottom } = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [data, _] = useState<Victual>({
    id: '',
    name: '',
    description: '',
    price: 0,
    media: [],
    selections: [],
  });

  const dispatch = useAppDispatch();

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      await dispatch(getVictualCategories({ signal }));
      setLoading(false);
    })();

    return () => {
      controller.abort();
    };
  }, []);

  if (loading) {
    return <Loader />;
  }

  const handleSubmit = async (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => {
    if (!id) {
      setSubmitting?.(false);
      return;
    }
    const body = new FormData();

    (values?.victual_media as any[])?.forEach((item) => {
      body.append('victual_media', item);
    });

    delete values?.victual_media;

    formatFormData(values, body);

    const response: any = await dispatch(
      createVictual({ body, restaurant_id: id })
    );

    if (response.error) {
      throwError(response?.payload);
      setSubmitting?.(false);
      return;
    }

    setSubmitting?.(false);
    setModalVisible(true);
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5 flex-1 ">
        <VitualForm
          data={data}
          handleSubmit={handleSubmit}
          categories={categories}
        />
      </ScrollView>
      <FullScreenModal modalVisible={modalVisible}>
        <Success
          Svg={SuccessSvg}
          message="Your meal have been added successfully! Orders are on the way"
          buttonText="Go Home"
          action={() => {
            setModalVisible(false);
            router.replace('/(main)/(tabs)/');
          }}
        />
      </FullScreenModal>
    </View>
  );
};

export default CreateVictual;
