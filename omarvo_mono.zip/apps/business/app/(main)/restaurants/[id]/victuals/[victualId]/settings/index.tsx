import { View, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  InfoSensitiveModal,
  Loader,
  OverlayLoader,
  SettingsListItem,
} from '@omarvo/ui';
import { Iconify } from 'react-native-iconify';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import {
  deleteEntrepreneurVictual,
  getEntrepreneurVictual,
  updateEntrepreneurVictualStockCondition,
} from '@omarvo/store';
import { router, useLocalSearchParams } from 'expo-router';
import { throwError } from '@omarvo/utils';
import DeleteSvg from '../../../../../../../assets/svgs/delete.svg';

const VictualSettings = () => {
  const { bottom } = useSafeAreaInsets();
  const [conditionLoading, setConditionLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  const { id, victualId } = useLocalSearchParams<{
    id: string;
    victualId: string;
  }>();
  const { data } = useAppSelector((state) => state.entrepreneurVictuals);

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!id || !victualId) return;

    if (data) {
      setLoading(false);
      return;
    }
    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      setLoading(true);
      await dispatch(
        getEntrepreneurVictual({ signal, restaurant_id: id, id: victualId })
      );
      setLoading(false);
    })();
  }, [id, victualId, data]);

  if (!data || !id || !victualId || loading) {
    return <Loader />;
  }

  const updateAvailability = async (value: boolean) => {
    if (!id) {
      return;
    }
    setConditionLoading(true);
    const res: any = await dispatch(
      updateEntrepreneurVictualStockCondition({
        id: victualId,
        restaurant_id: id,
        body: { in_stock: value },
      })
    );

    if (res.error) {
      throwError(res?.payload);
      setConditionLoading(false);
    }

    setConditionLoading(false);
  };

  const deleteVictual = async () => {
    setDeleting(true);
    const res: any = await dispatch(
      deleteEntrepreneurVictual({ restaurant_id: id, id: victualId })
    );

    if (res.error) {
      throwError(res?.payload);
    }

    setModalVisible(false);

    router.replace('/(main)/(tabs)/');
  };

  return (
    <View
      className="flex-1 bg-white relative"
      style={{ paddingBottom: bottom }}
    >
      <ScrollView className="flex-1">
        <View
          className="py-5"
          style={{
            rowGap: 8,
          }}
        >
          <SettingsListItem
            title="Toggle Availability"
            desc="Turn on/off whether in or out of stock"
            icon={
              <Iconify
                icon="flowbite:bell-active-outline"
                size={24}
                color="#00A082"
              />
            }
            action={() => {}}
            isToggle
            toggleValue={data?.in_stock}
            handleToggle={updateAvailability}
          />
          <SettingsListItem
            title="Edit Information"
            desc="Update your food information"
            icon={
              <Iconify
                icon="fluent:notepad-edit-20-regular"
                size={24}
                color="#00A082"
              />
            }
            action={() =>
              router.push(
                `/(main)/restaurants/${id}/victuals/${victualId}/settings/edit`
              )
            }
          />

          <SettingsListItem
            title="Manage Food Media"
            desc="Mangage your food media"
            icon={
              <Iconify
                icon="solar:gallery-edit-linear"
                size={20}
                color="#00A082"
              />
            }
            action={() =>
              router.push(
                `/(main)/restaurants/${id}/victuals/${victualId}/settings/media`
              )
            }
          />

          <SettingsListItem
            title="Delete Food"
            desc=""
            icon={<Iconify icon="ph:trash" size={20} color="#E1604D" />}
            showDesc={false}
            action={() => setModalVisible(true)}
            styles={{
              borderBottomColor: 'transparent',
            }}
            iconStyles={{
              backgroundColor: '#F8ECEC',
            }}
          />
        </View>
      </ScrollView>
      {conditionLoading && <OverlayLoader />}

      <InfoSensitiveModal
        modalVisible={modalVisible}
        action={deleteVictual}
        title="Delete Food"
        question="Are you sure you want to delete this food? This action is permanent"
        buttonText="Delete Food"
        loading={deleting}
        image={<DeleteSvg />}
        closeModal={() => setModalVisible(false)}
      />
    </View>
  );
};

export default VictualSettings;
