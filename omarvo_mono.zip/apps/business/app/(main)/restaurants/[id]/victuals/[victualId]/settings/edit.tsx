import { View, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { Loader } from '@omarvo/ui';
import { Victual, throwError } from '@omarvo/utils';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { router, useLocalSearchParams } from 'expo-router';
import {
  deleteEntrepreneurVictualSelection,
  getEntrepreneurVictual,
  getVictualCategories,
  updateEntrepreneurVictual,
} from '@omarvo/store';
import VitualForm from 'apps/business/components/RestaurantForms/VitualForm';

const EditVictual = () => {
  const { id, victualId } = useLocalSearchParams<{
    id: string;
    victualId: string;
  }>();

  const { data: victual } = useAppSelector(
    (state) => state.entrepreneurVictuals
  );
  const { victualCategories: categories } = useAppSelector(
    (state) => state.categories
  );
  const { bottom } = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [deletingSelection, setDeletingSelection] = useState(false);
  const [data, setData] = useState<Victual | null>(null);

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!victualId || !id) {
      return;
    }

    if (victual) {
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      await dispatch(
        getEntrepreneurVictual({ signal, id: victualId, restaurant_id: id })
      );
      setLoading(false);
    })();

    return () => {
      controller.abort();
    };
  }, [victualId, id, victual]);

  useEffect(() => {
    if (!victual) {
      return;
    }

    setData(victual);
  }, [victual]);

  if (loading || !victualId || !id || !data) {
    return <Loader />;
  }

  const handleSubmit = async (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => {
    const response: any = await dispatch(
      updateEntrepreneurVictual({
        id: victualId,
        restaurant_id: id,
        body: values,
      })
    );

    if (response.error) {
      throwError(response?.payload);
      setSubmitting?.(false);
      return;
    }
    setSubmitting?.(false);

    router.back();
  };

  const handleDeleteSelection = async (selectionId: string) => {
    if (!selectionId) {
      return;
    }
    setDeletingSelection(true);
    const res: any = await dispatch(
      deleteEntrepreneurVictualSelection({
        id: victualId,
        selectionId,
        restaurant_id: id,
      })
    );
    setDeletingSelection(false);

    return res;
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5 flex-1 ">
        <VitualForm
          data={data}
          handleSubmit={handleSubmit}
          categories={categories}
          handleDeleteSelection={handleDeleteSelection}
          deletingSelection={deletingSelection}
          onEditMode
        />
      </ScrollView>
    </View>
  );
};

export default EditVictual;
