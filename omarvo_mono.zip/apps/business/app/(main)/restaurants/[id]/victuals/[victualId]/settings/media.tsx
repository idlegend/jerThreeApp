import { View, Text, ScrollView, Pressable } from 'react-native';
import React, { useState } from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { Image } from 'expo-image';
import { Iconify } from 'react-native-iconify';
import { Button, Loader, MediaPicker, OverlayLoader } from '@omarvo/ui';
import {
  addToEntrepreneurVictualMedia,
  deleteEntrepreneurVictualMedia,
} from '@omarvo/store';
import { router, useLocalSearchParams } from 'expo-router';
import { throwError } from '@omarvo/utils';

const mediaSchema = yup.object().shape({
  victual_media: yup
    .array(yup.object())
    .min(1, 'You are to provide at least 1 media')
    .max(4, 'You are to provide at most 4 media')
    .required('This field is required'),
});

const VictualMedia = () => {
  const { bottom } = useSafeAreaInsets();

  const [deleting, setDeleting] = useState(false);

  const { data: victual } = useAppSelector(
    (state) => state.entrepreneurVictuals
  );
  const { id, victualId } = useLocalSearchParams<{
    id: string;
    victualId: string;
  }>();

  const initialValues = {
    victual_media: [],
  };

  const dispatch = useAppDispatch();

  if (!id || !victualId || !victual) {
    return <Loader />;
  }

  const handleDeleteMedia = async (mediaId: string) => {
    if (!mediaId) {
      return;
    }
    setDeleting(true);
    const res: any = await dispatch(
      deleteEntrepreneurVictualMedia({
        id: victualId,
        restaurant_id: id,
        mediaId,
      })
    );

    if (res.error) {
      setDeleting(false);
      return throwError(res?.payload);
    }
    setDeleting(false);
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5">
        <View className="py-5 flex-1" style={{ rowGap: 48 }}>
          <View className="flex-1 space-y-6">
            {victual?.media?.map((item) => (
              <View
                key={item.id}
                className="w-full flex-row pr-3 rounded-r-lg bg-[#FBFCFD] justify-between items-center"
              >
                <Image
                  source={item.url}
                  style={{
                    width: 80,
                    height: 80,
                    borderBottomLeftRadius: 8,
                    borderTopLeftRadius: 8,
                  }}
                />
                {victual?.media?.length > 1 && (
                  <Pressable
                    onPress={() => handleDeleteMedia(item.id)}
                    className="w-8 h-8 bg-[#E1604D] rounded-full justify-center items-center"
                  >
                    <Iconify icon="ph:trash" size={16} color="#fff" />
                  </Pressable>
                )}
              </View>
            ))}
          </View>
          <Formik
            initialValues={initialValues}
            onSubmit={async (values, { setSubmitting }) => {
              const body = new FormData();
              values.victual_media?.forEach((item) => {
                body.append('victual_media', item as any);
              });
              const res: any = await dispatch(
                addToEntrepreneurVictualMedia({
                  id: victualId,
                  restaurant_id: id,
                  body,
                })
              );

              if (res.error) {
                throwError(res.payload);
                setSubmitting(false);
                return;
              }

              setSubmitting(false);
              router.canGoBack() && router.back();
            }}
            validationSchema={mediaSchema}
            validateOnMount
          >
            {({
              handleBlur,
              handleSubmit,
              errors,
              touched,
              values,
              setFieldValue,
              isSubmitting,
              isValid,
            }) => (
              <View className="" style={{ rowGap: 52 }}>
                <MediaPicker
                  label="Media"
                  name="victual_media"
                  type="Images"
                  values={values.victual_media}
                  errors={errors.victual_media}
                  touched={touched.victual_media}
                  handleChange={setFieldValue}
                  handleBlur={handleBlur}
                  limit={4 - victual?.media?.length}
                  multiple
                />

                <Button
                  text="Save"
                  action={handleSubmit}
                  loading={isSubmitting}
                  disabled={!isValid}
                />
              </View>
            )}
          </Formik>
        </View>
      </ScrollView>
      {deleting && <OverlayLoader />}
    </View>
  );
};

export default VictualMedia;
