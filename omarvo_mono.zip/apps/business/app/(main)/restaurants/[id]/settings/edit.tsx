import { View, Text, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Restaurant, throwError } from '@omarvo/utils';
import { router, useLocalSearchParams } from 'expo-router';
import { Loader } from '@omarvo/ui';
import {
  getEntrepreneurRestaurant,
  getSchoolCampuses,
  updateRestaurant,
} from '@omarvo/store';
import MainForm from 'apps/business/components/RestaurantForms/MainForm';
import { openingHoursBase } from 'apps/business/constants/data';

const EditRestaurant = () => {
  const { id } = useLocalSearchParams<{ id: string }>();

  const { data: profile } = useAppSelector(
    (state) => state.entrepreneurProfile
  );
  const { resCategories: categories } = useAppSelector(
    (state) => state.categories
  );

  const { data: restaurant } = useAppSelector(
    (state) => state.entrepreneurRestaurant
  );

  const { campuses } = useAppSelector((state) => state.css);
  const { bottom } = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Restaurant | null>(null);

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!profile || !profile.schools[0] || !id) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      await dispatch(
        getSchoolCampuses({ signal, school_id: profile.schools[0].id })
      );
      if (restaurant) {
        setLoading(false);
        return;
      }
      await dispatch(getEntrepreneurRestaurant({ signal, id }));
      setLoading(false);
    })();

    return () => {
      controller.abort();
    };
  }, [profile, id, restaurant]);

  useEffect(() => {
    if (!restaurant) {
      return;
    }
    setData({
      ...restaurant,
      opening_hours: openingHoursBase.map((i) => {
        const existing = restaurant.opening_hours.find(
          (item) => item.day_of_week === i.day_of_week
        );
        if (existing) {
          return existing;
        } else {
          return i;
        }
      }),
    });
  }, [restaurant]);

  if (loading || !data || !id) {
    return <Loader />;
  }

  const handleSubmit = async (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => {
    const response: any = await dispatch(
      updateRestaurant({ id, body: values })
    );

    if (response.error) {
      throwError(response?.payload);
      setSubmitting?.(false);
      return;
    }

    router.back();
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5 flex-1 ">
        <MainForm
          data={data}
          handleSubmit={handleSubmit}
          campuses={campuses}
          categories={categories}
          onEditMode
        />
      </ScrollView>
    </View>
  );
};

export default EditRestaurant;
