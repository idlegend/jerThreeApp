import { View } from 'react-native';
import React from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { Button, Loader, MediaPicker } from '@omarvo/ui';
import { useAppDispatch } from '@omarvo/hooks';
import { updateRestaurantBannerImage } from '@omarvo/store';
import { router, useLocalSearchParams } from 'expo-router';
import { throwError } from '@omarvo/utils';

const bannerSchema = yup.object().shape({
  restaurant_banner: yup
    .object({
      uri: yup.string().required(),
      type: yup.string().required(),
      name: yup.string().required(),
    })
    .required('This field is required.'),
});

const UpdateRestaurantBanner = () => {
  const { id } = useLocalSearchParams<{ id: string }>();

  const initialValues: any = {
    restaurant_banner: null,
  };

  const dispatch = useAppDispatch();

  if (!id) {
    return <Loader />;
  }

  return (
    <View className="flex-1 bg-white p-5">
      <Formik
        initialValues={initialValues}
        onSubmit={async (values, { setSubmitting }) => {
          const body = new FormData();
          body.append('restaurant_banner', values.restaurant_banner as any);
          const res: any = await dispatch(
            updateRestaurantBannerImage({ id, body })
          );

          if (res.error) {
            throwError(res.payload);
            setSubmitting(false);
            return;
          }

          setSubmitting(false);
          router.canGoBack() && router.back();
        }}
        validationSchema={bannerSchema}
        validateOnMount
      >
        {({
          handleBlur,
          handleSubmit,
          errors,
          touched,
          values,
          setFieldValue,
          isSubmitting,
          isValid,
        }) => (
          <View className="" style={{ rowGap: 52 }}>
            <MediaPicker
              label="Banner Image"
              name="restaurant_banner"
              type="Images"
              values={
                values.restaurant_banner ? [values.restaurant_banner] : []
              }
              errors={errors.restaurant_banner}
              touched={touched.restaurant_banner}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
            />

            <Button
              text="Save"
              action={handleSubmit}
              loading={isSubmitting}
              disabled={!isValid}
            />
          </View>
        )}
      </Formik>
    </View>
  );
};

export default UpdateRestaurantBanner;
