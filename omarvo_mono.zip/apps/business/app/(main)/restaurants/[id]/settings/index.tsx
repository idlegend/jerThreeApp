import { View, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Loader, OverlayLoader, SettingsListItem } from '@omarvo/ui';
import { Iconify } from 'react-native-iconify';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import {
  getEntrepreneurRestaurant,
  updateRestaurantActiveCondition,
} from '@omarvo/store';
import { router, useLocalSearchParams } from 'expo-router';
import { throwError } from '@omarvo/utils';

const RestaurantSettings = () => {
  const { bottom } = useSafeAreaInsets();
  const [activityLoading, setActivityLoading] = useState(false);
  const [loading, setLoading] = useState(true);

  const { id } = useLocalSearchParams<{ id: string }>();
  const { data } = useAppSelector((state) => state.entrepreneurRestaurant);

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (data || !id) {
      setLoading(false);
      return;
    }
    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      setLoading(true);
      await dispatch(getEntrepreneurRestaurant({ signal, id }));
      setLoading(false);
    })();
  }, [id, data]);

  if (!data || !id || loading) {
    return <Loader />;
  }

  const updateAvailability = async (value: boolean) => {
    if (!id) {
      return;
    }
    setActivityLoading(true);
    const res: any = await dispatch(
      updateRestaurantActiveCondition({ id, body: { is_active: value } })
    );

    if (res.error) {
      throwError(res?.payload);
      setActivityLoading(false);
    }

    setActivityLoading(false);
  };

  return (
    <View
      className="flex-1 bg-white relative"
      style={{ paddingBottom: bottom }}
    >
      <ScrollView className="flex-1">
        <View
          className="py-5"
          style={{
            rowGap: 8,
          }}
        >
          <SettingsListItem
            title="Toggle Availability"
            desc="Turn on/off based on your activity"
            icon={
              <Iconify
                icon="flowbite:bell-active-outline"
                size={24}
                color="#00A082"
              />
            }
            action={() => {}}
            isToggle
            toggleValue={data?.is_active}
            handleToggle={updateAvailability}
          />
          <SettingsListItem
            title="Edit Information"
            desc="Update your restaurant information"
            icon={
              <Iconify
                icon="fluent:notepad-edit-20-regular"
                size={24}
                color="#00A082"
              />
            }
            action={() =>
              router.push(`/(main)/restaurants/${id}/settings/edit`)
            }
          />

          <SettingsListItem
            title="Update Banner Image"
            desc="Update your banner image"
            icon={
              <Iconify
                icon="solar:gallery-edit-linear"
                size={20}
                color="#00A082"
              />
            }
            action={() =>
              router.push(`/(main)/restaurants/${id}/settings/banner`)
            }
          />

          <SettingsListItem
            title="Delete Restaurant"
            desc=""
            icon={<Iconify icon="ph:trash" size={20} color="#E1604D" />}
            showDesc={false}
            action={() => {}}
            styles={{
              borderBottomColor: 'transparent',
            }}
            iconStyles={{
              backgroundColor: '#F8ECEC',
            }}
          />
        </View>
      </ScrollView>
      {activityLoading && <OverlayLoader />}
    </View>
  );
};

export default RestaurantSettings;
