import React, { useEffect, useRef, useState } from 'react';
import {
  FlatList,
  NativeScrollEvent,
  Pressable,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SectionListWithHeaders } from '@codeherence/react-native-header';
import { Iconify } from 'react-native-iconify';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { router, useLocalSearchParams } from 'expo-router';
import {
  getEntrepreneurRestaurant,
  getEntrepreneurVictuals,
  resetEntrepreneurRestaurantDetails,
} from '@omarvo/store';
import { Loader } from '@omarvo/ui';
import { globalStyles } from '@omarvo/utils';
import Animated, {
  runOnJS,
  scrollTo,
  useAnimatedRef,
  useDerivedValue,
  useSharedValue,
} from 'react-native-reanimated';
import {
  HeaderComp,
  LargeHeaderComp,
  TabView,
} from 'apps/business/components/ui';

const RestaurantDetailScreen: React.FC<any> = () => {
  const [headerHeight, setHeaderHeight] = useState(0);
  const [catPos, setCatPos] = useState<{ title: string; pos: number }[]>([]);
  const [active, setActive] = useState(0);
  const [loading, setLoading] = useState(true);

  const { bottom, top } = useSafeAreaInsets();
  const { data: restaurant } = useAppSelector(
    (state) => state.entrepreneurRestaurant
  );
  const { list: victuals } = useAppSelector(
    (state) => state.entrepreneurVictuals
  );

  const { id } = useLocalSearchParams<{ id: string }>();
  const ref = useRef<FlatList>(null);
  const animatedRef = useAnimatedRef<Animated.ScrollView>();
  const scroll = useSharedValue<number>(0);

  useDerivedValue(() => {
    scrollTo(animatedRef, 0, scroll.value, true);
  });

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!id) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      setLoading(true);
      await dispatch(getEntrepreneurRestaurant({ signal, id }));
      await dispatch(getEntrepreneurVictuals({ signal, restaurant_id: id }));
      setLoading(false);
    })();

    return () => {
      controller.abort();
      dispatch(resetEntrepreneurRestaurantDetails());
    };
  }, [id]);

  useEffect(() => {
    if (!ref.current) {
      return;
    }
    ref.current.scrollToIndex({
      animated: true,
      index: active,
      viewOffset: 20,
    });
  }, [active]);

  const data = [
    {
      title: 'Top Selling',
      data: [0],
    },
  ];

  if (loading || !restaurant) {
    return <Loader />;
  }

  const stat = [
    {
      value: `${restaurant.stats?.num_of_items}`,
      desc: 'Number of Items In Inventory',
    },
    {
      value: `₦ ${restaurant.stats?.todays_earning}`,
      desc: 'Total Amount Earned Today',
    },
    {
      value: `${restaurant.stats?.ongoing_orders_count}`,
      desc: 'Number of Ongoing Orders',
    },
    {
      value: `${restaurant.stats?.completed_order_count}`,
      desc: 'Number of Completed Orders',
    },
  ];

  const handleScroll = async (evt: NativeScrollEvent) => {
    const offset = Math.round(evt.contentOffset.y);
    const index = catPos.findLastIndex((item) => item.pos <= offset);
    if (index === -1) {
      return;
    }
    setActive(index);
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <SectionListWithHeaders
        HeaderComponent={({ showNavBar }) => (
          <HeaderComp
            showNavBar={showNavBar}
            handlePress={() =>
              router.push(`/(main)/restaurants/${id}/settings/`)
            }
            name={restaurant.name}
          />
        )}
        ref={animatedRef}
        LargeHeaderComponent={({ scrollY }) => (
          <LargeHeaderComp
            name={restaurant?.name}
            description={restaurant.description}
            image={restaurant?.media?.url}
            scrollY={scrollY}
            stat={stat}
          />
        )}
        contentContainerStyle={{
          backgroundColor: '#fff',
        }}
        sections={data}
        disableAutoFixScroll
        ignoreLeftSafeArea
        ignoreRightSafeArea
        headerFadeInThreshold={0.2}
        disableLargeHeaderFadeAnim
        onScrollWorklet={(evt: NativeScrollEvent) => {
          'worklet';
          runOnJS(handleScroll)(evt);
        }}
        style={{ flex: 1, backgroundColor: '#fff' }}
        containerStyle={{ backgroundColor: '#fff' }}
        renderItem={() => (
          <TabView
            setCatPos={setCatPos}
            calc={headerHeight + 40 + top}
            items={victuals}
            handlePress={(i) =>
              router.push(`/(main)/restaurants/${id}/victuals/${i}/`)
            }
          />
        )}
        bounces={false}
        stickySectionHeadersEnabled
        renderSectionHeader={() => {
          return (
            <View className="w-full flex-1">
              <FlatList
                data={[
                  { title: 'All', value: '' },
                  ...Object.keys(victuals)
                    .sort((a, b) => (b === 'top selling' ? 1 : -1))
                    .map((i) => ({ title: i, value: i })),
                ]}
                ref={ref}
                renderItem={({ item, index }) => {
                  const isActive = index === active;
                  return (
                    <Pressable
                      onPress={() => {
                        scroll.value = catPos[index].pos || 0;
                      }}
                      className={`px-4 ${
                        isActive ? 'bg-primaryOne' : 'bg-white'
                      }   rounded-lg py-[3px]`}
                    >
                      <Text
                        className={`text-base capitalize  ${
                          isActive ? 'text-white' : 'text-mainBlack'
                        }  `}
                        style={[globalStyles.regular]}
                      >
                        {item.title}
                      </Text>
                    </Pressable>
                  );
                }}
                horizontal
                bounces={false}
                contentContainerStyle={{
                  paddingHorizontal: 20,
                  paddingVertical: 8,
                  backgroundColor: '#fff',
                }}
                onLayout={(e) => {
                  setHeaderHeight(e?.nativeEvent?.layout?.height || 0);
                }}
                showsHorizontalScrollIndicator={false}
              />
            </View>
          );
        }}
      />
      <Pressable
        onPress={() => router.push(`/(main)/restaurants/${id}/victuals/create`)}
        className="absolute bottom-[6%] right-3 bg-white  rounded-full"
      >
        <Iconify icon="solar:add-circle-bold" size={72} color="#FFC244" />
      </Pressable>
    </View>
  );
};

export default RestaurantDetailScreen;
