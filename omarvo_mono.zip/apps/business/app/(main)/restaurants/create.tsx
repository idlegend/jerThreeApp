import { View, Text, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import MainForm from 'apps/business/components/RestaurantForms/MainForm';
import { Restaurant, formatFormData, throwError } from '@omarvo/utils';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import {
  createRestaurant,
  getRestaurantCategories,
  getSchoolCampuses,
} from '@omarvo/store';
import { Loader } from '@omarvo/ui';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { openingHoursBase } from 'apps/business/constants/data';

const CreateRestaurant = () => {
  const { data: profile } = useAppSelector(
    (state) => state.entrepreneurProfile
  );
  const { resCategories: categories } = useAppSelector(
    (state) => state.categories
  );
  const { campuses } = useAppSelector((state) => state.css);
  const { bottom } = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Restaurant>({
    id: '',
    name: '',
    description: '',
    is_reg_business: false,
    rc_number: '',
    school_address: {
      base: '',
      campus_id: '',
      school_id: '',
      on_campus: true,
      is_entrepreneur: true,
    },
    categories: [],
    opening_hours: openingHoursBase,
  });

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!profile || !profile.schools[0]) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      dispatch(getSchoolCampuses({ signal, school_id: profile.schools[0].id }));
      dispatch(getRestaurantCategories({ signal }));
      setData(
        (prev) =>
          (prev = {
            ...prev,
            school_address: {
              ...prev.school_address,
              school_id: profile.schools[0].id,
            },
          })
      );
      setLoading(false);
    })();

    return () => {
      controller.abort();
    };
  }, [profile]);

  if (loading) {
    return <Loader />;
  }

  const handleSubmit = async (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => {
    const body = new FormData();

    body.append('restaurant_banner', values.restaurant_banner);

    delete values?.restaurant_banner;

    formatFormData(values, body);

    const response: any = await dispatch(createRestaurant(body));

    if (response.error) {
      throwError(response?.payload);
      setSubmitting?.(false);
      return;
    }

    router.back();
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5 flex-1 ">
        <MainForm
          data={data}
          handleSubmit={handleSubmit}
          campuses={campuses}
          categories={categories}
        />
      </ScrollView>
    </View>
  );
};

export default CreateRestaurant;

// Object.keys(values).forEach((key) => {
//   if (key === 'opening_hours') {
//     values.opening_hours.forEach((i: any, index: number) => {
//       body.append(
//         `opening_hours[${index}].day_of_week`,
//         i.day_of_week.toString()
//       );
//       body.append(`opening_hours[${index}].open_time`, i.open_time as any);
//       body.append(
//         `opening_hours[${index}].close_time`,
//         i.close_time as any
//       );
//     });
//   } else if (key === 'categories') {
//     values.categories.forEach((i: any, index: number) => {
//       body.append(`categories[${index}]`, i);
//     });
//   } else if (key === 'school_address') {
//     Object.keys(values.school_address).forEach((k) => {
//       body.append(
//         `school_address.${k}`,
//         values.school_address[
//           k as keyof (typeof values)['school_address']
//         ] as string
//       );
//     });
//   } else {
//     body.append(key, values[key as keyof typeof values] as string);
//   }
// });
