import React, { useEffect } from 'react';
import { Stack } from 'expo-router';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { getCurrentEntrepreneurProfile } from '@omarvo/store';
import { Loader } from '@omarvo/ui';
import { options } from '@omarvo/utils';

export default function TabLayout() {
  const { loading, data } = useAppSelector(
    (state) => state.entrepreneurProfile
  );

  const dispatch = useAppDispatch();

  useEffect(() => {
    (async () => {
      await dispatch(getCurrentEntrepreneurProfile());
    })();
  }, []);

  if (loading || !data) {
    return <Loader />;
  }

  return <MainLayout />;
}

const MainLayout = () => {
  return (
    <Stack>
      <Stack.Screen
        name="(tabs)"
        options={{
          ...options,
          headerShown: false,
        }}
      />

      {/* Restaurant */}
      <Stack.Screen
        name="restaurants/index"
        options={{
          ...options,
          title: 'Restaurants',
        }}
      />
      <Stack.Screen
        name="restaurants/create"
        options={{
          ...options,
          title: 'Create Restaurant',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/index"
        options={{
          ...options,
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/settings/index"
        options={{
          ...options,
          title: 'Restaurant Settings',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/settings/edit"
        options={{
          ...options,
          title: 'Edit Restaurant',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/settings/banner"
        options={{
          ...options,
          title: 'Update Banner Image',
        }}
      />
      {/* Restaurant Victuals */}
      <Stack.Screen
        name="restaurants/[id]/victuals/create"
        options={{
          ...options,
          title: 'Add Food',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/victuals/[victualId]/index"
        options={{
          ...options,
          title: '',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/victuals/[victualId]/settings/index"
        options={{
          ...options,
          title: 'Food Settings',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/victuals/[victualId]/settings/edit"
        options={{
          ...options,
          title: 'Edit Food',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/victuals/[victualId]/settings/media"
        options={{
          ...options,
          title: 'Manage Food Media',
        }}
      />

      {/* Store */}
      <Stack.Screen
        name="stores/index"
        options={{
          ...options,
          title: 'Stores',
        }}
      />
      <Stack.Screen
        name="stores/create"
        options={{
          ...options,
          title: 'Create Store',
        }}
      />
      <Stack.Screen
        name="stores/[id]/index"
        options={{
          ...options,
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="stores/[id]/settings/index"
        options={{
          ...options,
          title: 'Store Settings',
        }}
      />
      <Stack.Screen
        name="stores/[id]/settings/edit"
        options={{
          ...options,
          title: 'Edit Store',
        }}
      />
      <Stack.Screen
        name="stores/[id]/settings/banner"
        options={{
          ...options,
          title: 'Update Banner Image',
        }}
      />
      {/* Store Products */}
      <Stack.Screen
        name="stores/[id]/products/create"
        options={{
          ...options,
          title: 'Add Product',
        }}
      />
      <Stack.Screen
        name="stores/[id]/products/[productId]/index"
        options={{
          ...options,
          title: '',
        }}
      />
      <Stack.Screen
        name="stores/[id]/products/[productId]/settings/index"
        options={{
          ...options,
          title: 'Product Settings',
        }}
      />
      <Stack.Screen
        name="stores/[id]/products/[productId]/settings/edit"
        options={{
          ...options,
          title: 'Edit Product',
        }}
      />
      <Stack.Screen
        name="stores/[id]/products/[productId]/settings/media"
        options={{
          ...options,
          title: 'Manage Product Media',
        }}
      />
    </Stack>
  );
};
