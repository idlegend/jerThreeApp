import { View, Text } from 'react-native';
import React from 'react';

const OrderScreen = () => {
  return (
    <View>
      <Text>OrderScreen</Text>
    </View>
  );
};

export default OrderScreen;
