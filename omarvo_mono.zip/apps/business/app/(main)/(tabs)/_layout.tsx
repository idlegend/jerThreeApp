import React from 'react';
import { Tabs } from 'expo-router';
import { Feed, Home, Wallet } from '@omarvo/ui';
import { globalStyles } from '@omarvo/utils';
import { Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Iconify } from 'react-native-iconify';
// You can explore the built-in icon families and icons on the web at https://icons.expo.fyi/

export default function TabLayout() {
  const { bottom } = useSafeAreaInsets();
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#00A082',
        tabBarInactiveTintColor: '#8A97AB',
        tabBarStyle: {
          height: 72 + bottom,
          borderTopColor: '#B2E2D9',
          borderTopWidth: 1,
        },
        tabBarShowLabel: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          headerShown: false,
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? <Home state="fill" /> : <Home state="outline" />}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Home
              </Text>
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="message"
        options={{
          title: 'Message',
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? (
                <Iconify icon="ph:chat-text-fill" size={22} color={color} />
              ) : (
                <Iconify icon="ph:chat-text" size={22} color={color} />
              )}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Message
              </Text>
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="feed"
        options={{
          title: 'Feed',
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? <Feed state="fill" /> : <Feed state="outline" />}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Feed
              </Text>
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="wallet"
        options={{
          title: 'Wallet',
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? <Wallet state="fill" /> : <Wallet state="outline" />}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Wallet
              </Text>
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="orders"
        options={{
          title: 'Orders',
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? (
                <Iconify
                  icon="solar:clipboard-text-bold"
                  size={20}
                  color={color}
                />
              ) : (
                <Iconify
                  icon="solar:clipboard-text-linear"
                  size={20}
                  color={color}
                />
              )}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Orders
              </Text>
            </View>
          ),
        }}
      />
    </Tabs>
  );
}
