import { View, Text } from 'react-native';
import React from 'react';

const WalletScreen = () => {
  return (
    <View>
      <Text>WalletScreen</Text>
    </View>
  );
};

export default WalletScreen;
