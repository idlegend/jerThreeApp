import { View, Text } from 'react-native';
import React from 'react';

const FeedScreen = () => {
  return (
    <View>
      <Text>FeedScreen</Text>
    </View>
  );
};

export default FeedScreen;
