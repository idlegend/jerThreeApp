import { router } from 'expo-router';
import { FlatList, ScrollView, Text, View } from 'react-native';
import { deleteSecure, globalStyles } from '@omarvo/utils';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppSelector } from '@omarvo/hooks';
import { Iconify } from 'react-native-iconify';
import { Notification, SectionCard, WalletCard } from '@omarvo/ui';
import { sections } from 'apps/business/constants/data';

export default function HomeScreen() {
  const { top } = useSafeAreaInsets();
  const { data } = useAppSelector((state) => state.entrepreneurProfile);

  const handleLogout = async () => {
    // await CookieManager.clearAll();
    await deleteSecure('entrepreneurToken');
    router.replace('/auth/login');
  };

  return (
    <View
      style={{
        paddingTop: top,
      }}
      className="flex-1 bg-white "
    >
      <ScrollView className="px-5">
        <View className="flex-1 py-5" style={{ rowGap: 24 }}>
          <View className="flex-row justify-between items-center">
            <Text
              className="text-base text-mainBlack "
              style={[globalStyles.bold]}
            >
              Welcome {data?.first_name}
            </Text>
            <View
              className="flex-row items-center "
              style={{
                columnGap: 22,
              }}
            >
              <Iconify
                icon="radix-icons:avatar"
                onPress={handleLogout}
                size={24}
                color="#00A082"
              />
              <Notification />
            </View>
          </View>
          <WalletCard image={require('../../../assets/images/wallet_bg.png')} />
          <View className="space-y-3">
            <Text
              className="text-base text-mainBlack "
              style={[globalStyles.bold]}
            >
              Get Started Here
            </Text>

            <FlatList
              data={sections}
              renderItem={({ item }) => <SectionCard {...item} />}
              numColumns={2}
              columnWrapperStyle={{
                justifyContent: 'space-between',
              }}
              scrollEnabled={false}
            />
          </View>
        </View>
      </ScrollView>
      {/* <Button text="Log Out" action={handleLogout} /> */}
    </View>
  );
}
