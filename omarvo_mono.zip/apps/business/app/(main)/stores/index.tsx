import { FlatList, View } from 'react-native';
import React, { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { getEntrepreneurStores } from '@omarvo/store';
import { Empty, EnBusinessCard, Loader } from '@omarvo/ui';
import NoResult from '../../../assets/svgs/no_result.svg';
import { router } from 'expo-router';

const StoresScreen = () => {
  const { loading, list } = useAppSelector((state) => state.entrepreneurStore);

  const dispatch = useAppDispatch();

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;

    dispatch(getEntrepreneurStores({ signal }));

    return () => {
      controller.abort();
    };
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <View className="flex-1 bg-white ">
      {list.length < 1 ? (
        <Empty
          text="Store has not been created yet. Click below to get started"
          buttonText="Create Store"
          svg={<NoResult />}
          action={() => router.push('/(main)/stores/create')}
        />
      ) : (
        <FlatList
          data={list}
          renderItem={({ item }) => (
            <EnBusinessCard
              {...item}
              action={() => router.push(`/(main)/stores/${item.id}/`)}
            />
          )}
          style={{ padding: 20, flex: 1 }}
        />
      )}
    </View>
  );
};

export default StoresScreen;
