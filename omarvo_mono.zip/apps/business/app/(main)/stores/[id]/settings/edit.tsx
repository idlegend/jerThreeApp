import { View, Text, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Store, throwError } from '@omarvo/utils';
import { router, useLocalSearchParams } from 'expo-router';
import { Loader } from '@omarvo/ui';
import {
  getEntrepreneurStore,
  getSchoolCampuses,
  updateStore,
} from '@omarvo/store';
import MainForm from 'apps/business/components/StoreForms/MainForm';
import { openingHoursBase } from 'apps/business/constants/data';

const EditStoreScreen = () => {
  const { id } = useLocalSearchParams<{ id: string }>();

  const { data: profile } = useAppSelector(
    (state) => state.entrepreneurProfile
  );
  const { resCategories: categories } = useAppSelector(
    (state) => state.categories
  );

  const { data: store } = useAppSelector((state) => state.entrepreneurStore);

  const { campuses } = useAppSelector((state) => state.css);
  const { bottom } = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Store | null>(null);

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!profile || !profile.schools[0] || !id) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      await dispatch(
        getSchoolCampuses({ signal, school_id: profile.schools[0].id })
      );
      if (store) {
        setLoading(false);
        return;
      }
      await dispatch(getEntrepreneurStore({ signal, id }));
      setLoading(false);
    })();

    return () => {
      controller.abort();
    };
  }, [profile, id, store]);

  useEffect(() => {
    if (!store) {
      return;
    }
    setData({
      ...store,
      opening_hours: openingHoursBase.map((i) => {
        const existing = store.opening_hours.find(
          (item) => item.day_of_week === i.day_of_week
        );
        if (existing) {
          return existing;
        } else {
          return i;
        }
      }),
    });
  }, [store]);

  if (loading || !data || !id) {
    return <Loader />;
  }

  const handleSubmit = async (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => {
    const response: any = await dispatch(updateStore({ id, body: values }));

    if (response.error) {
      throwError(response?.payload);
      setSubmitting?.(false);
      return;
    }

    router.back();
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5 flex-1 ">
        <MainForm
          data={data}
          handleSubmit={handleSubmit}
          campuses={campuses}
          categories={categories}
          onEditMode
        />
      </ScrollView>
    </View>
  );
};

export default EditStoreScreen;
