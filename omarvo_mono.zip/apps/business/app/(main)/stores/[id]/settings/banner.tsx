import { View } from 'react-native';
import React from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { Button, Loader, MediaPicker } from '@omarvo/ui';
import { useAppDispatch } from '@omarvo/hooks';
import { updateStoreBannerImage } from '@omarvo/store';
import { router, useLocalSearchParams } from 'expo-router';
import { throwError } from '@omarvo/utils';

const bannerSchema = yup.object().shape({
  store_banner: yup
    .object({
      uri: yup.string().required(),
      type: yup.string().required(),
      name: yup.string().required(),
    })
    .required('This field is required.'),
});

const UpdateStoreBannerScreen = () => {
  const { id } = useLocalSearchParams<{ id: string }>();

  const initialValues: any = {
    store_banner: null,
  };

  const dispatch = useAppDispatch();

  if (!id) {
    return <Loader />;
  }

  return (
    <View className="flex-1 bg-white p-5">
      <Formik
        initialValues={initialValues}
        onSubmit={async (values, { setSubmitting }) => {
          const body = new FormData();
          body.append('store_banner', values.store_banner as any);
          const res: any = await dispatch(updateStoreBannerImage({ id, body }));

          if (res.error) {
            throwError(res.payload);
            setSubmitting(false);
            return;
          }

          setSubmitting(false);
          router.canGoBack() && router.back();
        }}
        validationSchema={bannerSchema}
        validateOnMount
      >
        {({
          handleBlur,
          handleSubmit,
          errors,
          touched,
          values,
          setFieldValue,
          isSubmitting,
          isValid,
        }) => (
          <View className="" style={{ rowGap: 52 }}>
            <MediaPicker
              label="Banner Image"
              name="store_banner"
              type="Images"
              values={values.store_banner ? [values.store_banner] : []}
              errors={errors.store_banner}
              touched={touched.store_banner}
              handleChange={setFieldValue}
              handleBlur={handleBlur}
            />

            <Button
              text="Save"
              action={handleSubmit}
              loading={isSubmitting}
              disabled={!isValid}
            />
          </View>
        )}
      </Formik>
    </View>
  );
};

export default UpdateStoreBannerScreen;
