import { View, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { Loader } from '@omarvo/ui';
import { Product, throwError } from '@omarvo/utils';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { router, useLocalSearchParams } from 'expo-router';
import {
  getEntrepreneurProduct,
  updateEntrepreneurProduct,
} from '@omarvo/store';
import ProductForm from 'apps/business/components/StoreForms/ProductForm';

const EditProductScreen = () => {
  const { id, productId } = useLocalSearchParams<{
    id: string;
    productId: string;
  }>();

  const { data: product } = useAppSelector(
    (state) => state.entrepreneurProducts
  );
  const { prodCategories: categories } = useAppSelector(
    (state) => state.categories
  );
  const { bottom } = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Product | null>(null);

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!productId || !id) {
      return;
    }

    if (product) {
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      await dispatch(
        getEntrepreneurProduct({ signal, id: productId, store_id: id })
      );
      setLoading(false);
    })();

    return () => {
      controller.abort();
    };
  }, [productId, id, product]);

  useEffect(() => {
    if (!product) {
      return;
    }

    setData(product);
  }, [product]);

  if (loading || !productId || !id || !data) {
    return <Loader />;
  }

  const handleSubmit = async (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => {
    const response: any = await dispatch(
      updateEntrepreneurProduct({
        id: productId,
        store_id: id,
        body: values,
      })
    );

    if (response.error) {
      throwError(response?.payload);
      setSubmitting?.(false);
      return;
    }
    setSubmitting?.(false);

    router.back();
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5 flex-1 ">
        <ProductForm
          data={data}
          handleSubmit={handleSubmit}
          categories={categories}
          onEditMode
        />
      </ScrollView>
    </View>
  );
};

export default EditProductScreen;
