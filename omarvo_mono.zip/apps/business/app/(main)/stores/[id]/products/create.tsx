import { View, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { createProduct, getProductCategories } from '@omarvo/store';
import { FullScreenModal, Loader, Success } from '@omarvo/ui';
import { Product, formatFormData, throwError } from '@omarvo/utils';
import { router, useLocalSearchParams } from 'expo-router';
import SuccessSvg from '../../../../../assets/svgs/rp_success.svg';
import ProductForm from 'apps/business/components/StoreForms/ProductForm';

const CreateStoreProduct = () => {
  const { id } = useLocalSearchParams<{ id: string }>();

  const { prodCategories: categories } = useAppSelector(
    (state) => state.categories
  );
  const { bottom } = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [data, _] = useState<Product>({
    id: '',
    name: '',
    description: '',
    price: 0,
    quantity: 0,
    is_negotiable: false,
    media: [],
  });

  const dispatch = useAppDispatch();

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      await dispatch(getProductCategories({ signal }));
      setLoading(false);
    })();

    return () => {
      controller.abort();
    };
  }, []);

  if (loading) {
    return <Loader />;
  }

  const handleSubmit = async (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => {
    if (!id) {
      setSubmitting?.(false);
      return;
    }
    const body = new FormData();

    (values?.product_media as any[])?.forEach((item) => {
      body.append('product_media', item);
    });

    delete values?.product_media;

    formatFormData(values, body);

    const response: any = await dispatch(createProduct({ body, store_id: id }));

    if (response.error) {
      throwError(response?.payload);
      setSubmitting?.(false);
      return;
    }

    setSubmitting?.(false);
    setModalVisible(true);
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5 flex-1 ">
        <ProductForm
          data={data}
          handleSubmit={handleSubmit}
          categories={categories}
        />
      </ScrollView>
      <FullScreenModal modalVisible={modalVisible}>
        <Success
          Svg={SuccessSvg}
          message="Your product has been added successfully! Orders are on the way"
          buttonText="Go Home"
          action={() => {
            setModalVisible(false);
            router.replace('/(main)/(tabs)/');
          }}
        />
      </FullScreenModal>
    </View>
  );
};

export default CreateStoreProduct;
