import { View, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  InfoSensitiveModal,
  Loader,
  OverlayLoader,
  SettingsListItem,
} from '@omarvo/ui';
import { Iconify } from 'react-native-iconify';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import {
  deleteEntrepreneurProduct,
  getEntrepreneurProduct,
  updateEntrepreneurProductStockCondition,
} from '@omarvo/store';
import { router, useLocalSearchParams } from 'expo-router';
import { throwError } from '@omarvo/utils';
import DeleteSvg from '../../../../../../../assets/svgs/delete.svg';

const StoreProductSettingScreen = () => {
  const { bottom } = useSafeAreaInsets();
  const [conditionLoading, setConditionLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  const { id, productId } = useLocalSearchParams<{
    id: string;
    productId: string;
  }>();
  const { data } = useAppSelector((state) => state.entrepreneurProducts);

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!id || !productId) return;

    if (data) {
      setLoading(false);
      return;
    }
    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      setLoading(true);
      await dispatch(
        getEntrepreneurProduct({ signal, store_id: id, id: productId })
      );
      setLoading(false);
    })();
  }, [id, productId, data]);

  if (!data || !id || !productId || loading) {
    return <Loader />;
  }

  const updateAvailability = async (value: boolean) => {
    if (!id) {
      return;
    }
    setConditionLoading(true);
    const res: any = await dispatch(
      updateEntrepreneurProductStockCondition({
        id: productId,
        store_id: id,
        body: { in_stock: value },
      })
    );

    if (res.error) {
      throwError(res?.payload);
      setConditionLoading(false);
    }

    setConditionLoading(false);
  };

  const deleteProduct = async () => {
    setDeleting(true);
    const res: any = await dispatch(
      deleteEntrepreneurProduct({ store_id: id, id: productId })
    );

    if (res.error) {
      throwError(res?.payload);
    }

    setModalVisible(false);

    router.replace('/(main)/(tabs)/');
  };

  return (
    <View
      className="flex-1 bg-white relative"
      style={{ paddingBottom: bottom }}
    >
      <ScrollView className="flex-1">
        <View
          className="py-5"
          style={{
            rowGap: 8,
          }}
        >
          <SettingsListItem
            title="Toggle Availability"
            desc="Turn on/off whether in or out of stock"
            icon={
              <Iconify
                icon="flowbite:bell-active-outline"
                size={24}
                color="#00A082"
              />
            }
            action={() => {}}
            isToggle
            toggleValue={data?.in_stock}
            handleToggle={updateAvailability}
          />
          <SettingsListItem
            title="Edit Information"
            desc="Update your product information"
            icon={
              <Iconify
                icon="fluent:notepad-edit-20-regular"
                size={24}
                color="#00A082"
              />
            }
            action={() =>
              router.push(
                `/(main)/stores/${id}/products/${productId}/settings/edit`
              )
            }
          />

          <SettingsListItem
            title="Manage Product Media"
            desc="Mangage your product media"
            icon={
              <Iconify
                icon="solar:gallery-edit-linear"
                size={20}
                color="#00A082"
              />
            }
            action={() =>
              router.push(
                `/(main)/stores/${id}/products/${productId}/settings/media`
              )
            }
          />

          <SettingsListItem
            title="Delete Product"
            desc=""
            icon={<Iconify icon="ph:trash" size={20} color="#E1604D" />}
            showDesc={false}
            action={() => setModalVisible(true)}
            styles={{
              borderBottomColor: 'transparent',
            }}
            iconStyles={{
              backgroundColor: '#F8ECEC',
            }}
          />
        </View>
      </ScrollView>
      {conditionLoading && <OverlayLoader />}

      <InfoSensitiveModal
        modalVisible={modalVisible}
        action={deleteProduct}
        title="Delete Product"
        question="Are you sure you want to delete this product? This action is permanent"
        buttonText="Delete Product"
        loading={deleting}
        image={<DeleteSvg />}
        closeModal={() => setModalVisible(false)}
      />
    </View>
  );
};

export default StoreProductSettingScreen;
