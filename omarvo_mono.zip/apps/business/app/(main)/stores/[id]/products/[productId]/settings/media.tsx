import { View, ScrollView, Pressable } from 'react-native';
import React, { useState } from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { Image } from 'expo-image';
import { Iconify } from 'react-native-iconify';
import { Button, Loader, MediaPicker, OverlayLoader } from '@omarvo/ui';
import {
  addToEntrepreneurProductMedia,
  deleteEntrepreneurProductMedia,
} from '@omarvo/store';
import { router, useLocalSearchParams } from 'expo-router';
import { throwError } from '@omarvo/utils';

const mediaSchema = yup.object().shape({
  product_media: yup
    .array(yup.object())
    .min(1, 'You are to provide at least 1 media')
    .max(4, 'You are to provide at most 4 media')
    .required('This field is required'),
});

const ManageMediaScreen = () => {
  const { bottom } = useSafeAreaInsets();

  const [deleting, setDeleting] = useState(false);

  const { data: product } = useAppSelector(
    (state) => state.entrepreneurProducts
  );
  const { id, productId } = useLocalSearchParams<{
    id: string;
    productId: string;
  }>();

  const initialValues = {
    product_media: [],
  };

  const dispatch = useAppDispatch();

  if (!id || !productId || !product) {
    return <Loader />;
  }

  const handleDeleteMedia = async (mediaId: string) => {
    if (!mediaId) {
      return;
    }
    setDeleting(true);
    const res: any = await dispatch(
      deleteEntrepreneurProductMedia({
        id: productId,
        store_id: id,
        mediaId,
      })
    );

    if (res.error) {
      setDeleting(false);
      return throwError(res?.payload);
    }
    setDeleting(false);
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5">
        <View className="py-5 flex-1" style={{ rowGap: 48 }}>
          <View className="flex-1 space-y-6">
            {product?.media?.map((item) => (
              <View
                key={item.id}
                className="w-full flex-row pr-3 rounded-r-lg bg-[#FBFCFD] justify-between items-center"
              >
                <Image
                  source={item.url}
                  style={{
                    width: 80,
                    height: 80,
                    borderBottomLeftRadius: 8,
                    borderTopLeftRadius: 8,
                  }}
                />
                {product?.media?.length > 1 && (
                  <Pressable
                    onPress={() => handleDeleteMedia(item.id)}
                    className="w-8 h-8 bg-[#E1604D] rounded-full justify-center items-center"
                  >
                    <Iconify icon="ph:trash" size={16} color="#fff" />
                  </Pressable>
                )}
              </View>
            ))}
          </View>
          <Formik
            initialValues={initialValues}
            onSubmit={async (values, { setSubmitting }) => {
              const body = new FormData();
              values.product_media?.forEach((item) => {
                body.append('product_media', item as any);
              });
              const res: any = await dispatch(
                addToEntrepreneurProductMedia({
                  id: productId,
                  store_id: id,
                  body,
                })
              );

              if (res.error) {
                throwError(res.payload);
                setSubmitting(false);
                return;
              }

              setSubmitting(false);
              router.canGoBack() && router.back();
            }}
            validationSchema={mediaSchema}
            validateOnMount
          >
            {({
              handleBlur,
              handleSubmit,
              errors,
              touched,
              values,
              setFieldValue,
              isSubmitting,
              isValid,
            }) => (
              <View className="" style={{ rowGap: 52 }}>
                <MediaPicker
                  label="Media"
                  name="product_media"
                  type="Images"
                  values={values.product_media}
                  errors={errors.product_media}
                  touched={touched.product_media}
                  handleChange={setFieldValue}
                  handleBlur={handleBlur}
                  limit={4 - product?.media?.length}
                  multiple
                />

                <Button
                  text="Save"
                  action={handleSubmit}
                  loading={isSubmitting}
                  disabled={!isValid}
                />
              </View>
            )}
          </Formik>
        </View>
      </ScrollView>
      {deleting && <OverlayLoader />}
    </View>
  );
};

export default ManageMediaScreen;
