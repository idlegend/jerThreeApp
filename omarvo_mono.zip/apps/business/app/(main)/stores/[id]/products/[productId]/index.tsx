import {
  View,
  Text,
  ScrollView,
  FlatList,
  Animated,
  Dimensions,
  Pressable,
  TouchableOpacity,
} from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { getEntrepreneurProduct } from '@omarvo/store';
import { Loader, Paginator, StatCard } from '@omarvo/ui';
import { Image } from 'expo-image';
import { globalStyles } from '@omarvo/utils';
import { truncate } from 'lodash';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Iconify } from 'react-native-iconify';

const StoreProductDetailsScreen = () => {
  const { id, productId } = useLocalSearchParams<{
    id: string;
    productId: string;
  }>();
  const [currentIndex, setCurrentIndex] = useState(0);

  const { bottom } = useSafeAreaInsets();

  const scrollX = useRef(new Animated.Value(0)).current;
  const slidesRef = useRef<any>(null);

  const dispatch = useAppDispatch();

  const { data, dataLoading } = useAppSelector(
    (state) => state.entrepreneurProducts
  );

  const viewableItemsChanged = useRef(({ viewableItems }: any) => {
    setCurrentIndex(viewableItems[0]?.index);
  }).current;

  const viewConfig = useRef({ viewAreaCoveragePercentThreshold: 50 }).current;

  useEffect(() => {
    if (!id || !productId) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      await dispatch(
        getEntrepreneurProduct({ signal, store_id: id, id: productId })
      );
    })();

    return () => {
      controller.abort();
    };
  }, [id, productId]);

  if (dataLoading || !data) {
    return <Loader />;
  }

  const stat = [
    {
      value: `${data.stats?.todays_orders || 0}`,
      desc: 'Number of Times Ordered Today',
    },
    {
      value: `₦ ${data.stats?.todays_earning || 0}`,
      desc: 'Total Amount Earned Today',
    },
    {
      value: `${data.stats?.ongoing_orders_count || 0}`,
      desc: 'Number of Ongoing Orders',
    },
    {
      value: `${data.stats?.completed_order_count || 0}`,
      desc: 'Number of Completed Orders',
    },
  ];

  return (
    <View className="flex-1 bg-white " style={{ paddingBottom: bottom }}>
      <Stack.Screen
        options={{
          title: truncate(data.name),
          headerRight: () => (
            <TouchableOpacity
              onPress={() =>
                router.push(
                  `/(main)/stores/${id}/products/${productId}/settings/`
                )
              }
            >
              <Iconify icon="carbon:settings" size={24} color="#00A082" />
            </TouchableOpacity>
          ),
        }}
      />
      <ScrollView>
        <View className="flex-1 pb-5 space-y-5">
          <View className="space-y-4">
            <FlatList
              data={data.media}
              renderItem={({ item }) => (
                <Image
                  source={item?.url}
                  placeholder={item?.blur_hash}
                  contentFit="cover"
                  style={{ width: Dimensions.get('screen').width, height: 333 }}
                />
              )}
              horizontal
              showsHorizontalScrollIndicator={false}
              pagingEnabled
              bounces={false}
              keyExtractor={(item, index) => String(index)}
              onScroll={Animated.event(
                [
                  {
                    nativeEvent: {
                      contentOffset: {
                        x: scrollX,
                      },
                    },
                  },
                ],
                { useNativeDriver: false }
              )}
              scrollEventThrottle={32}
              onViewableItemsChanged={viewableItemsChanged}
              ref={slidesRef}
              viewabilityConfig={viewConfig}
              style={{ flex: 1 }}
            />
            <Paginator
              data={data.media}
              currentIndex={currentIndex}
              scrollX={scrollX}
              backgroundColor="#00A082"
              faintColor="#CCECE6"
              style={{ justifyContent: 'center', columnGap: 4 }}
              range={[16, 58, 16]}
            />
            <View className="flex-row px-5 space-x-[13px] ">
              {data.media.map((i, index) => (
                <Pressable
                  onPress={() => {
                    slidesRef.current.scrollToIndex({
                      animated: true,
                      index: index,
                    });
                  }}
                  key={index}
                  className={` rounded ${
                    index === currentIndex
                      ? 'border border-primaryOne'
                      : 'border border-transparent'
                  } `}
                >
                  <Image
                    source={i?.url}
                    placeholder={i?.blur_hash}
                    style={{ height: 64, width: 64, borderRadius: 4 }}
                  />
                </Pressable>
              ))}
            </View>
          </View>
          <View className="px-5" style={{ rowGap: 40 }}>
            <View className="space-y-6">
              <View className="max-w-[65%] space-y-2">
                <Text
                  className="text-base text-mainBlack"
                  style={[globalStyles.medium]}
                >
                  {data.name}
                </Text>
                <Text
                  className="text-lg text-success-500 "
                  style={[globalStyles.bold]}
                >
                  ₦{data.price}
                </Text>
              </View>
              <FlatList
                data={stat}
                renderItem={({ item }) => <StatCard {...item} />}
                numColumns={2}
                columnWrapperStyle={{
                  columnGap: 16,
                }}
                contentContainerStyle={{
                  rowGap: 16,
                }}
                style={{ rowGap: 16 }}
                scrollEnabled={false}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default StoreProductDetailsScreen;
