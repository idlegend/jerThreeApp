import { View, Text, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Store, formatFormData, throwError } from '@omarvo/utils';
import { openingHoursBase } from 'apps/business/constants/data';
import {
  createStore,
  getSchoolCampuses,
  getStoreCategories,
} from '@omarvo/store';
import { Loader } from '@omarvo/ui';
import { router } from 'expo-router';
import MainForm from 'apps/business/components/StoreForms/MainForm';

const CreateStoreScreen = () => {
  const { data: profile } = useAppSelector(
    (state) => state.entrepreneurProfile
  );
  const { storeCategories: categories } = useAppSelector(
    (state) => state.categories
  );
  const { campuses } = useAppSelector((state) => state.css);
  const { bottom } = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Store>({
    id: '',
    name: '',
    description: '',
    is_reg_business: false,
    rc_number: '',
    school_address: {
      base: '',
      campus_id: '',
      school_id: '',
      on_campus: true,
      is_entrepreneur: true,
    },
    categories: [],
    opening_hours: openingHoursBase,
  });

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!profile || !profile.schools[0]) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      dispatch(getSchoolCampuses({ signal, school_id: profile.schools[0].id }));
      dispatch(getStoreCategories({ signal }));
      setData(
        (prev) =>
          (prev = {
            ...prev,
            school_address: {
              ...prev.school_address,
              school_id: profile.schools[0].id,
            },
          })
      );
      setLoading(false);
    })();

    return () => {
      controller.abort();
    };
  }, [profile]);

  if (loading) {
    return <Loader />;
  }

  const handleSubmit = async (
    values: any,
    setSubmitting?: (isSubmitting: boolean) => void
  ) => {
    const body = new FormData();

    body.append('store_banner', values.store_banner);

    delete values?.store_banner;

    formatFormData(values, body);

    const response: any = await dispatch(createStore(body));

    if (response.error) {
      throwError(response?.payload);
      setSubmitting?.(false);
      return;
    }

    router.back();
  };

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <ScrollView className="px-5 flex-1 ">
        <MainForm
          data={data}
          handleSubmit={handleSubmit}
          campuses={campuses}
          categories={categories}
        />
      </ScrollView>
    </View>
  );
};

export default CreateStoreScreen;
