/** @type {import('tailwindcss').Config} */
const { join } = require('path');
const { createGlobPatternsForDependencies } = require('@nx/react/tailwind');

module.exports = {
  content: [
    join(
      __dirname,
      '{src,pages,components,app}/**/*!(*.stories|*.spec).{ts,tsx,html}'
    ),
    ...createGlobPatternsForDependencies(__dirname),
  ],
  theme: {
    extend: {
      colors: {
        primaryOne: '#00A082',
        primary: {
          100: '#CCECE6',
        },
        primaryTwo: '#FFC244',
        primaryThree: '#6E7A8B',
        secondaryOne: '#99D9CD',
        secondary: {
          50: '#FFF9EC',
          100: '#FFF9EC',
          700: '#997429',
        },
        background: {
          300: '#FBFCFD',
          400: '#FCFCFC',
        },
        success: {
          500: '#51AE7E',
        },
        text: {
          300: '#535C6C',
        },
        danger: {
          500: '#BE4646',
        },
        secondaryTwo: '#E3D8C1',
        secondaryThree: '#E5F5F2',
        secondaryFour: '#FFDA8F',
        mainBlack: '#1B222D',
        secBlack: '#1F2937',
        borderOne: '#373F4C',
        borderThree: '#F9F9F9',
        borderTwo: '#E6E6E6',
        mainGray: '#EEEFF3',
        mainWhite: '#F9FAFC',
      },
    },
  },
  plugins: [],
};
