import { View, Text, StyleProp, ViewStyle } from 'react-native';
import React from 'react';
import { Timer1 } from 'iconsax-react-native';
import { globalStyles } from '@omarvo/utils';
import { Iconify } from 'react-native-iconify';

interface Props {
  icon: React.JSX.Element | null;
  styles?: StyleProp<ViewStyle>;
}

export const CustomIcon: React.FC<Props> = ({ styles, icon }) => {
  return (
    <View
      style={[styles]}
      className="w-7 h-7 rounded-full justify-center items-center bg-primaryOne "
    >
      {icon}
    </View>
  );
};

interface DTProps {
  time: string;
}

export const DeliveryTime: React.FC<DTProps> = ({ time }) => {
  return (
    <View className="flex-row items-center space-x-3">
      <Timer1 size={16} color="#00A082" />
      <Text className="text-sm text-borderOne" style={[globalStyles.regular]}>
        {time}
      </Text>
    </View>
  );
};

interface RProps {
  rating: string;
  showCount?: boolean;
}

export const RatingComp: React.FC<RProps> = ({ rating, showCount = true }) => {
  return (
    <View className="flex-row space-x-1 items-center">
      <Iconify icon="ion:star" size={17} color="#F0B44D" />
      <Text className="text-borderOne text-sm " style={[globalStyles.regular]}>
        {rating}
        {showCount && (
          <>
            {' '}
            <Text className="text-primaryThree">(400+)</Text>
          </>
        )}
      </Text>
    </View>
  );
};
