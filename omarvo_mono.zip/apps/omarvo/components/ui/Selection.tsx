import { View, Text, Pressable } from 'react-native';
import React, { useState } from 'react';
import { Selection as SelectionTD, globalStyles } from '@omarvo/utils';
import { Iconify } from 'react-native-iconify';

interface Props extends SelectionTD {}

const Selection: React.FC<Props> = ({ title, is_required, options }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  return (
    <View className="border-b border-borderTwo">
      <View className="flex-row items-center justify-between pb-4  ">
        <View className="w-full flex-row items-center space-x-4 max-w-[80%]">
          <Text
            className="text-sm text-borderOne "
            style={[globalStyles.regular]}
          >
            Choose Your {title}
          </Text>
          {is_required && (
            <View className="py-[3px] px-7 bg-[#F8ECEC] border border-danger-500 rounded-full  ">
              <Text className="text-xs text-danger-500  ">Required</Text>
            </View>
          )}
        </View>
        <Pressable onPress={() => setIsOpen(!isOpen)}>
          <Iconify
            icon="ic:round-arrow-back-ios"
            transform={[{ rotate: isOpen ? '90deg' : '270deg' }]}
            size={20}
            color="#222B38"
          />
        </Pressable>
      </View>
      {isOpen && (
        <View className="pb-5 space-y-2">
          <Text
            className="text-primaryThree text-sm "
            style={[globalStyles.regular]}
          >
            Please choose One
          </Text>
          <View className="space-y-5">
            {options?.map((option, index) => {
              const active = selected === index;
              return (
                <View
                  key={index}
                  className="flex-row items-center justify-between"
                >
                  <View className="space-y-1 max-w-[80%]">
                    <Text
                      className="text-primaryThree text-sm "
                      style={[globalStyles.regular]}
                    >
                      {option.name}
                    </Text>
                    <Text
                      className="text-primaryOne text-sm "
                      style={[globalStyles.regular]}
                    >
                      +₦{option.upcharge?.toLocaleString()}
                    </Text>
                  </View>
                  <Pressable
                    onPress={() => setSelected(active ? null : index)}
                    className={`w-5 h-5 rounded-full justify-center items-center border border-primaryOne ${
                      active ? 'bg-primaryOne' : 'bg-none'
                    } `}
                  >
                    {active && (
                      <View className="w-2 h-2 rounded-full bg-white"></View>
                    )}
                  </Pressable>
                </View>
              );
            })}
          </View>
        </View>
      )}
    </View>
  );
};

export { Selection };
