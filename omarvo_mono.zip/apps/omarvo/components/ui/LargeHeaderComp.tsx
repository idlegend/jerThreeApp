import { View, Text, FlatList } from 'react-native';
import React from 'react';
import { LargeHeader, ScalingView } from '@codeherence/react-native-header';
import { Image } from 'expo-image';
import { Iconify } from 'react-native-iconify';
import { Openinghour, globalStyles } from '@omarvo/utils';
import { SharedValue } from 'react-native-reanimated';
import { Button, SearchComponent, StatCard } from '@omarvo/ui';
import { CustomIcon, DeliveryTime, RatingComp } from './common';
import { SearchNormal1 } from 'iconsax-react-native';
import { truncate } from 'lodash';
import { daysArray } from 'apps/omarvo/constants/data';
import moment from 'moment';

interface Props {
  image?: string;
  name: string;
  description: string;
  scrollY: SharedValue<number>;
  openingHour: Openinghour | null;
  nextOpenDay?: Openinghour | undefined;
  isStore?: boolean;
}

const LargeHeaderComp: React.FC<Props> = ({
  image,
  name,
  scrollY,
  description,
  openingHour,
  nextOpenDay,
  isStore = false,
}) => {
  return (
    <LargeHeader
      headerStyle={{
        paddingHorizontal: 0,
        paddingVertical: 0,
      }}
    >
      <View className="flex-1">
        <View className=" w-full ">
          {/* Banner */}
          <View className="relative">
            <Image
              source={image}
              contentFit="cover"
              style={{ width: '100%', height: 274 }}
            />
            <View className="absolute top-0 left-0 right-0 bottom-0 justify-center items-center bg-black/50">
              <ScalingView scrollY={scrollY}>
                <Text
                  className="text-lg text-white"
                  style={[globalStyles.medium]}
                >
                  {name}
                </Text>
              </ScalingView>
            </View>
          </View>
          {/* Opening Hour */}
          {openingHour && (
            <View className="flex-row items-center py-3 px-5 justify-between ">
              <Text
                className="text-secBlack text-base  "
                style={[globalStyles.medium]}
              >
                Opens today at {moment(openingHour.open_time).format('h:mma')} -{' '}
                {moment(openingHour.close_time).format('h:mma')}
              </Text>
              <View className="flex-row items-center" style={{ columnGap: 16 }}>
                <CustomIcon
                  icon={
                    <Iconify icon="mdi:heart-outline" size={16} color="#fff" />
                  }
                />
                <CustomIcon icon={<SearchNormal1 size="16" color="#fff" />} />
                <CustomIcon
                  icon={
                    <Iconify icon="ic:baseline-share" size={16} color="#fff" />
                  }
                />
              </View>
            </View>
          )}

          <View
            className={`px-5 ${
              openingHour ? 'border-y border-borderTwo' : 'border-none'
            }  space-y-3 py-3`}
          >
            {/* Prep Time */}
            {!isStore && (
              <View className="flex-row items-center justify-between ">
                <Text
                  className="text-secBlack text-base  "
                  style={[globalStyles.medium]}
                >
                  Preparation Time -{' '}
                  <Text className="text-primaryOne">30-35min</Text>
                </Text>
                <RatingComp rating="4.5" />
              </View>
            )}

            {/* Descriptio */}
            <Text
              className="text-mainBlack text-sm"
              style={[globalStyles.regular]}
            >
              {truncate(description, { length: 150 })}
            </Text>
            {/* Delivery time */}
            {openingHour && (
              <View className="flex-row justify-between items-center">
                <DeliveryTime time="45 -50 mins" />
                {isStore && <RatingComp rating="4.5" />}
              </View>
            )}
          </View>
          {!openingHour && (
            <View
              className="px-5 py-4 bg-secondary-100 "
              style={{ rowGap: 24 }}
            >
              <View className="space-y-1">
                {nextOpenDay && (
                  <Text
                    className="text-secondary-700 text-sm "
                    style={[globalStyles.medium]}
                  >
                    Restaurant will Reopen on{' '}
                    {daysArray[nextOpenDay.day_of_week]}{' '}
                    {moment(nextOpenDay.open_time).format('h:mma')} -{' '}
                    {moment(nextOpenDay.close_time).format('h:mma')}
                  </Text>
                )}

                <Text
                  className="text-secBlack text-xs "
                  style={[globalStyles.regular]}
                >
                  You can click “Notify Me” to get notified when they are back
                </Text>
              </View>
              <Button
                text="Notify Me"
                action={() => {}}
                styles={{ paddingVertical: 10 }}
                textStyles={{ fontSize: 14 }}
              />
            </View>
          )}
        </View>
      </View>
    </LargeHeader>
  );
};

export { LargeHeaderComp };
