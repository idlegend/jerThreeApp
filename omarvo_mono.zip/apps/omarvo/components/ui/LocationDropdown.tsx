import { View, Text } from 'react-native';
import React from 'react';
import { Location } from 'iconsax-react-native';
import { globalStyles } from '@omarvo/utils';
import { Iconify } from 'react-native-iconify';

interface Props {
  location: string;
}

const LocationDropdown: React.FC<Props> = ({ location }) => {
  return (
    <View className="flex-row space-x-2 items-center">
      <Location size="20" color="#1B222D" />
      <Text className="text-sm text-mainBlack " style={[globalStyles.medium]}>
        {location}
      </Text>
      <Iconify icon="icon-park-outline:down" size={16} color="#1B222D" />
    </View>
  );
};

export { LocationDropdown };
