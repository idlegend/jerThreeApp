import { Header } from '@codeherence/react-native-header';
import { router } from 'expo-router';
import { truncate } from 'lodash';
import { Platform, Text, TouchableOpacity } from 'react-native';
import { Iconify } from 'react-native-iconify';
import { SharedValue } from 'react-native-reanimated';

const HeaderComp = ({
  showNavBar,
  name,
  handlePress,
}: {
  showNavBar: SharedValue<number>;
  name: string;
  handlePress: () => void;
}) => {
  return (
    <Header
      showNavBar={showNavBar}
      headerCenter={
        <Text
          style={{
            fontWeight: '500',
            fontFamily: 'medium',
            fontSize: 18,
            color: '#00A082',
          }}
        >
          {truncate(name, { length: 16 })}
        </Text>
      }
      headerLeftStyle={{ paddingHorizontal: 14, paddingTop: 8 }}
      headerRightStyle={{ paddingHorizontal: 20, paddingTop: 8 }}
      headerLeft={
        <TouchableOpacity onPress={() => router.back()}>
          {Platform.OS === 'ios' ? (
            <Iconify
              icon="material-symbols:arrow-back-ios-rounded"
              size={24}
              color="#222B38"
            />
          ) : (
            <Iconify icon="ic:sharp-arrow-back" size={24} color="#222B38" />
          )}
        </TouchableOpacity>
      }
      headerStyle={{
        backgroundColor: '#fff',
        paddingVertical: 8,
        alignItems: 'center',
      }}
      noBottomBorder
    />
  );
};

export { HeaderComp };
