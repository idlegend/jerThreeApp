import { View, Text, Pressable, TouchableOpacity } from 'react-native';
import React from 'react';
import { Restaurant, globalStyles } from '@omarvo/utils';
import { Image } from 'expo-image';
import { Iconify } from 'react-native-iconify';
import { DeliveryTime, RatingComp } from './common';

interface Props extends Restaurant {
  handlePress: () => void;
}

const ResStoreCard: React.FC<Props> = ({
  media,
  name,
  categories,
  handlePress,
}) => {
  return (
    <Pressable
      onPress={handlePress}
      className="rounded-lg bg-background-400 overflow-hidden"
    >
      <Image
        source={media?.url}
        placeholder={media?.blur_hash}
        style={{
          width: '100%',
          height: 134,
        }}
      />
      <View className="p-3 space-y-3">
        <View className="space-y-2">
          <View className="flex-row items-center justify-between ">
            <Text
              className="text-sm text-mainBlack "
              style={[globalStyles.bold]}
            >
              {name}
            </Text>
            <RatingComp rating="4.5" />
          </View>
          <Text
            className="text-sm text-text-300 "
            style={[globalStyles.regular]}
          >
            {categories?.map((item) => item.name).join(' - ')}
          </Text>
        </View>
        <View className="flex-row items-center justify-between">
          <DeliveryTime time="45 -50 mins" />
          <TouchableOpacity>
            <Iconify icon="heroicons:heart" size={20} color="#00A082" />
          </TouchableOpacity>
        </View>
      </View>
    </Pressable>
  );
};

export { ResStoreCard };
