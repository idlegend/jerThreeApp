import { View, Text, Dimensions, TouchableOpacity } from 'react-native';
import React from 'react';
import { Product, globalStyles } from '@omarvo/utils';
import { Image } from 'expo-image';
import { RatingComp } from './common';
import { Iconify } from 'react-native-iconify';

interface Props extends Product {}

const ProductCard: React.FC<Props> = ({ media, name, price }) => {
  const calc = Dimensions.get('screen').width - (40 + 18);
  const width = calc / 2;
  return (
    <View className="space-y-3 " style={{ width }}>
      <Image
        source={media?.[0]?.url || ''}
        placeholder={media?.[0]?.blur_hash}
        style={{ width: '100%', height: 125, borderRadius: 8.58 }}
      />
      <View className="space-y-2">
        <Text className="text-sm text-mainBlack" style={[globalStyles.regular]}>
          {name}
        </Text>
        <Text className="text-base text-primaryOne" style={[globalStyles.bold]}>
          ₦ {price?.toLocaleString()}
        </Text>
        <View className="w-full flex-row justify-between items-center">
          <RatingComp rating="4.5" showCount={false} />
          <TouchableOpacity>
            <Iconify icon="heroicons:heart" size={20} color="#00A082" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export { ProductCard };
