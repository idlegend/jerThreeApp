import FontAwesome from '@expo/vector-icons/FontAwesome';
import { Stack, router } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import axios from 'axios';

import {
  useFonts,
  Ubuntu_700Bold,
  Ubuntu_400Regular,
  Ubuntu_500Medium,
  Ubuntu_300Light,
} from '@expo-google-fonts/ubuntu';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar, Text } from 'react-native';
import { deleteSecure, options } from '@omarvo/utils';
import NetInfo from '@react-native-community/netinfo';
import { Provider } from 'react-redux';
import { store } from '@omarvo/store';

export {
  // Catch any errors thrown by the Layout component.
  ErrorBoundary,
} from 'expo-router';

// export const unstable_settings = {
//   // Ensure that reloading on `/modal` keeps a back button.
//   initialRouteName: "index",
// };

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

axios.defaults.baseURL = process.env.EXPO_PUBLIC_API_URL;

axios.interceptors.response.use(
  function (response) {
    return response;
  },
  async function (error) {
    const url = error.config.url as string;

    if (url.includes('user/profile')) {
      if (error?.response?.status === 401) {
        await deleteSecure('userToken');
        router.push('/auth/');
      }
    }

    return Promise.reject(error);
  }
);

export default function RootLayout() {
  StatusBar.setBarStyle('dark-content');
  const [loaded, error] = useFonts({
    bold: Ubuntu_700Bold,
    medium: Ubuntu_500Medium,
    regular: Ubuntu_400Regular,
    light: Ubuntu_300Light,
    ...FontAwesome.font,
  });

  // Expo Router uses Error Boundaries to catch errors in the navigation tree.
  useEffect(() => {
    if (error) throw error;
  }, [error]);

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      // console.log("Connection type", state.type);
      // console.log("Is connected?", state.isConnected);
    });

    return () => {
      unsubscribe();
    };
  });

  if (!loaded) {
    return null;
  }

  return (
    <Provider store={store}>
      <SafeAreaProvider>
        <RootLayoutNav />
      </SafeAreaProvider>
    </Provider>
  );
}

function RootLayoutNav() {
  return (
    <Stack>
      <Stack.Screen name="index" options={{ ...options, headerShown: false }} />
      <Stack.Screen name="auth" options={{ ...options, headerShown: false }} />
      <Stack.Screen name="(main)" options={{ headerShown: false }} />
      <Stack.Screen name="modal" options={{ presentation: 'modal' }} />
    </Stack>
  );
}
