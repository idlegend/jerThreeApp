import React, { useEffect } from 'react';
import { Stack } from 'expo-router';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { getCurrentUserProfile } from '@omarvo/store';
import { Loader } from '@omarvo/ui';
import { options } from '@omarvo/utils';

export default function TabLayout() {
  const { loading, data } = useAppSelector((state) => state.profile);

  const dispatch = useAppDispatch();

  useEffect(() => {
    (async () => {
      await dispatch(getCurrentUserProfile());
    })();
  }, []);

  if (loading || !data) {
    return <Loader />;
  }

  return <MainLayout />;
}

const MainLayout = () => {
  return (
    <Stack>
      <Stack.Screen
        name="(tabs)"
        options={{
          ...options,
          headerShown: false,
        }}
      />
      {/* Restaurant */}
      <Stack.Screen
        name="restaurants/index"
        options={{
          ...options,
          title: 'Restaurants',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/index"
        options={{
          ...options,
          title: '',
        }}
      />
      <Stack.Screen
        name="restaurants/[id]/victuals/[victualId]"
        options={{
          ...options,
          title: '',
        }}
      />

      {/* Store */}
      <Stack.Screen
        name="stores/index"
        options={{
          ...options,
          title: 'Stores',
        }}
      />
      <Stack.Screen
        name="stores/[id]/index"
        options={{
          ...options,
          title: '',
        }}
      />
      <Stack.Screen
        name="stores/[id]/products/[productId]"
        options={{
          ...options,
          title: '',
        }}
      />
    </Stack>
  );
};
