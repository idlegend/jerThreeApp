import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Pressable,
} from 'react-native';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import {
  DeliveryTime,
  LocationDropdown,
  ResStoreCard,
} from 'apps/omarvo/components';
import { ClipboardText, ShoppingCart, Timer1 } from 'iconsax-react-native';
import { Loader, SearchComponent } from '@omarvo/ui';
import { globalStyles } from '@omarvo/utils';
import { getRestaurants } from '@omarvo/store';
import { iconifyIcons } from 'apps/omarvo/constants/data';
import {
  SectionListWithHeaders,
  LargeHeader,
} from '@codeherence/react-native-header';
import { Image } from 'expo-image';
import { Iconify } from 'react-native-iconify';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';

const RestaurantsScreen = () => {
  const [loading, setLoading] = useState(true);
  const { data: profile } = useAppSelector((state) => state.profile);
  const { list } = useAppSelector((state) => state.restaurant);
  const { resCategories } = useAppSelector((state) => state.categories);
  const [params, setParams] = useState({
    category_id: '',
  });

  const { bottom } = useSafeAreaInsets();

  const dispatch = useAppDispatch();

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      setLoading(true);
      const clone: Record<any, any> = { ...params };

      Object.keys(clone).forEach((key) => {
        if (!clone[key]) {
          delete clone[key];
        }
      });

      await dispatch(getRestaurants({ signal, params: clone }));
      setLoading(false);
    })();

    return () => controller.abort();
  }, [params]);

  if (!profile) {
    return <Loader />;
  }

  const icons = iconifyIcons();

  const data = [
    {
      title: '',
      data: [0],
    },
  ];

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <SectionListWithHeaders
        HeaderComponent={({}) => <></>}
        LargeHeaderComponent={({}) => (
          <LargeHeader
            headerStyle={{
              paddingHorizontal: 0,
              paddingVertical: 0,
              paddingTop: 20,
            }}
          >
            <View className="px-5 w-full space-y-5">
              <View style={{ rowGap: 24 }}>
                <View className="flex-row items-center justify-between ">
                  <LocationDropdown location={profile?.schools?.[0]?.name} />
                  <View className="flex-row items-center space-x-6">
                    <ShoppingCart color="#00A082" />
                    <ClipboardText color="#00A082" />
                  </View>
                </View>
                <SearchComponent showFilter />
              </View>
              <Text
                className="text-base text-mainBlack "
                style={[globalStyles.bold]}
              >
                Categories
              </Text>
            </View>
          </LargeHeader>
        )}
        contentContainerStyle={{
          backgroundColor: '#fff',
          rowGap: 20,
        }}
        sections={data}
        disableAutoFixScroll
        ignoreLeftSafeArea
        ignoreRightSafeArea
        headerFadeInThreshold={0.2}
        disableLargeHeaderFadeAnim
        style={{ flex: 1, backgroundColor: '#fff' }}
        containerStyle={{ backgroundColor: '#fff' }}
        renderItem={() => (
          <View className="space-y-3 flex-1 relative px-5">
            {loading ? (
              <View className="pt-20">
                <Loader />
              </View>
            ) : (
              <FlatList
                data={list.data}
                renderItem={({ item }) => (
                  <ResStoreCard
                    {...item}
                    handlePress={() =>
                      router.push(`/(main)/restaurants/${item.id}/`)
                    }
                  />
                )}
                style={{ rowGap: 24 }}
              />
            )}
          </View>
        )}
        bounces={false}
        stickySectionHeadersEnabled
        renderSectionHeader={() => {
          return (
            <View className="w-full py-1 bg-white">
              <FlatList
                data={resCategories}
                renderItem={({ item }) => {
                  const isActive = params.category_id.includes(item.id);
                  return (
                    <TouchableOpacity
                      onPress={() => {
                        const ids = params.category_id
                          ? params.category_id.split(',')
                          : [];

                        if (isActive) {
                          const index = ids.indexOf(item.id);
                          ids.splice(index, 1);
                        } else {
                          ids.push(item.id);
                        }

                        setParams(
                          (prev) =>
                            (prev = {
                              ...prev,
                              category_id: ids.join(','),
                            })
                        );
                      }}
                      className={`p-2 w-[70px] rounded-lg border ${
                        isActive
                          ? 'bg-primaryOne border-primaryOne'
                          : 'bg-white border-[#F9F9F9]'
                      }   space-y-1 items-center justify-center `}
                    >
                      {icons[item.icon || '']}
                      <Text
                        className={`text-sm ${
                          isActive ? 'text-white' : 'text-borderOne'
                        } `}
                        style={[globalStyles.medium]}
                      >
                        {item.name}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{
                  columnGap: 16,
                  paddingHorizontal: 20,
                }}
                horizontal
              />
            </View>
          );
        }}
      />
    </View>
  );
};

export default RestaurantsScreen;
