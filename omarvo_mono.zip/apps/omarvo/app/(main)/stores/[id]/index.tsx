import React, { useEffect, useRef, useState } from 'react';
import {
  FlatList,
  NativeScrollEvent,
  Platform,
  Pressable,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SectionListWithHeaders } from '@codeherence/react-native-header';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { getStore, getProducts, resetStoreDetails } from '@omarvo/store';
import { Loader } from '@omarvo/ui';
import { Openinghour, globalStyles } from '@omarvo/utils';
import Animated, {
  runOnJS,
  scrollTo,
  useAnimatedRef,
  useDerivedValue,
  useSharedValue,
} from 'react-native-reanimated';
import { LargeHeaderComp, TabView } from 'apps/omarvo/components';
import { truncate } from 'lodash';
import ClosedSvg from '../../../../assets/svgs/closed.svg';

const StoreDetailScreen: React.FC<any> = () => {
  const [headerHeight, setHeaderHeight] = useState(0);
  const [catPos, setCatPos] = useState<{ title: string; pos: number }[]>([]);
  const [active, setActive] = useState(0);
  const [loading, setLoading] = useState(true);
  const [openingHour, setOpeningHour] = useState<Openinghour | null>();
  const [nextOpenDay, setNextOpenDay] = useState<Openinghour>();

  const { bottom, top } = useSafeAreaInsets();
  const { data: store } = useAppSelector((state) => state.store);
  const { list: products } = useAppSelector((state) => state.products);

  const { id } = useLocalSearchParams<{ id: string }>();
  const ref = useRef<FlatList>(null);
  const animatedRef = useAnimatedRef<Animated.ScrollView>();
  const scroll = useSharedValue<number>(0);

  useDerivedValue(() => {
    scrollTo(animatedRef, 0, scroll.value, true);
  });

  const dispatch = useAppDispatch();

  const getNextOpenDay: any = (
    prospective: number,
    openingHours: Openinghour[]
  ) => {
    let existing = openingHours.find((oh) => oh.day_of_week === prospective);

    if (existing) {
      return existing;
    }

    const value = prospective === 6 ? 0 : prospective + 1;
    existing = getNextOpenDay(value, openingHours);
    return existing;
  };

  function parseTimeString(timeString: string) {
    let [hours, minutes] = timeString.split(':').map(Number);
    let date = new Date();
    date.setHours(hours, minutes, 0, 0); // set hours, minutes, seconds, milliseconds
    return date;
  }

  useEffect(() => {
    if (!id) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      setLoading(true);
      await dispatch(getProducts({ signal, store_id: id }));
      await dispatch(getStore({ signal, id }));
      setLoading(false);
    })();

    return () => {
      controller.abort();
      dispatch(resetStoreDetails());
    };
  }, [id]);

  useEffect(() => {
    if (!store) {
      return;
    }

    const current = new Date(Date.now());
    const weekDay = current.getDay();

    const existingDay = store.opening_hours?.find(
      (oh) => oh.day_of_week === weekDay
    );

    const nextOpenDay = getNextOpenDay(
      weekDay === 6 ? 0 : weekDay + 1,
      store.opening_hours
    );

    setNextOpenDay(nextOpenDay);

    if (!existingDay) {
      setOpeningHour(null);

      return;
    }

    const currentTime = parseTimeString(
      `${current.getHours()}:${current.getMinutes()}`
    );

    const busOpenDate = new Date(existingDay.open_time);
    const openTime = parseTimeString(
      `${busOpenDate.getHours()}:${busOpenDate.getMinutes()}`
    );

    const busCloseDate = new Date(existingDay.close_time);
    const closeTime = parseTimeString(
      `${busCloseDate.getHours()}:${busCloseDate.getMinutes()}`
    );

    if (current < openTime) {
      setOpeningHour(null);
      setNextOpenDay(existingDay);
      return;
    }

    if (currentTime >= closeTime) {
      setOpeningHour(null);
      return;
    }

    setOpeningHour(existingDay);
  }, [store]);

  useEffect(() => {
    if (!ref.current) {
      return;
    }
    ref.current.scrollToIndex({
      animated: true,
      index: active,
      viewOffset: 20,
    });
  }, [active]);

  const data = [
    {
      title: '',
      data: [0],
    },
  ];

  if (loading || !store || openingHour === undefined) {
    return <Loader />;
  }

  const handleScroll = async (evt: NativeScrollEvent) => {
    const offset = Math.round(evt.contentOffset.y);
    const index = catPos.findLastIndex((item) => item.pos <= offset);
    if (index === -1) {
      return;
    }
    setActive(index);
  };

  const mainHeaderHeight = Platform.OS === 'android' ? 50 : 40;

  return (
    <View className="flex-1 bg-white" style={{ paddingBottom: bottom }}>
      <Stack.Screen
        options={{
          title: truncate(store.name),
        }}
      />
      <SectionListWithHeaders
        HeaderComponent={({}) => <></>}
        ref={animatedRef}
        LargeHeaderComponent={({ scrollY }) => (
          <LargeHeaderComp
            name={store?.name}
            description={store.description}
            openingHour={openingHour}
            nextOpenDay={nextOpenDay}
            image={store?.media?.url}
            scrollY={scrollY}
            isStore
          />
        )}
        contentContainerStyle={{
          backgroundColor: '#fff',
        }}
        sections={data}
        disableAutoFixScroll
        ignoreLeftSafeArea
        ignoreRightSafeArea
        headerFadeInThreshold={0.2}
        disableLargeHeaderFadeAnim
        onScrollWorklet={(evt: NativeScrollEvent) => {
          'worklet';
          runOnJS(handleScroll)(evt);
        }}
        style={{ flex: 1, backgroundColor: '#fff' }}
        containerStyle={{ backgroundColor: '#fff' }}
        renderItem={() => (
          <>
            {openingHour ? (
              <TabView
                setCatPos={setCatPos}
                calc={headerHeight + mainHeaderHeight + top}
                items={products}
                handlePress={(i) =>
                  router.push(`/(main)/stores/${id}/products/${i}/`)
                }
              />
            ) : (
              <View className="py-16 items-center w-full">
                <ClosedSvg />
              </View>
            )}
          </>
        )}
        bounces={false}
        stickySectionHeadersEnabled
        renderSectionHeader={() => {
          return (
            <View className="w-full">
              {openingHour && (
                <FlatList
                  data={[
                    { title: 'All', value: '' },
                    ...Object.keys(products)
                      .sort((a, b) => (b === 'top selling' ? 1 : -1))
                      .map((i) => ({ title: i, value: i })),
                  ]}
                  ref={ref}
                  renderItem={({ item, index }) => {
                    const isActive = index === active;
                    return (
                      <Pressable
                        onPress={() => {
                          scroll.value = catPos[index].pos || 0;
                        }}
                        className={`px-4 ${
                          isActive ? 'bg-primaryOne' : 'bg-white'
                        }   rounded-lg py-[3px]`}
                      >
                        <Text
                          className={`text-base capitalize  ${
                            isActive ? 'text-white' : 'text-mainBlack'
                          }  `}
                          style={[globalStyles.regular]}
                        >
                          {item.title}
                        </Text>
                      </Pressable>
                    );
                  }}
                  horizontal
                  bounces={false}
                  contentContainerStyle={{
                    paddingHorizontal: 20,
                    paddingVertical: 16,
                    backgroundColor: '#fff',
                  }}
                  onLayout={(e) => {
                    setHeaderHeight(e?.nativeEvent?.layout?.height || 0);
                  }}
                  showsHorizontalScrollIndicator={false}
                />
              )}
            </View>
          );
        }}
      />
    </View>
  );
};

export default StoreDetailScreen;
