import {
  View,
  Text,
  ScrollView,
  FlatList,
  Animated,
  Dimensions,
  Pressable,
  TouchableOpacity,
} from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { Stack, useLocalSearchParams } from 'expo-router';
import { getProduct } from '@omarvo/store';
import { Button, Loader, Paginator } from '@omarvo/ui';
import { Image } from 'expo-image';
import { globalStyles } from '@omarvo/utils';
import { truncate } from 'lodash';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Iconify } from 'react-native-iconify';
import { RatingComp } from 'apps/omarvo/components';
import ReactNativeModal from 'react-native-modal';

const ProductDetails = () => {
  const { id, productId } = useLocalSearchParams<{
    id: string;
    productId: string;
  }>();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);

  const { bottom } = useSafeAreaInsets();

  const scrollX = useRef(new Animated.Value(0)).current;
  const slidesRef = useRef<any>(null);

  const dispatch = useAppDispatch();

  const { data, dataLoading } = useAppSelector((state) => state.products);

  const viewableItemsChanged = useRef(({ viewableItems }: any) => {
    setCurrentIndex(viewableItems[0]?.index);
  }).current;

  const viewConfig = useRef({ viewAreaCoveragePercentThreshold: 50 }).current;

  useEffect(() => {
    if (!id || !productId) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      await dispatch(getProduct({ signal, store_id: id, id: productId }));
    })();

    return () => {
      controller.abort();
    };
  }, [id, productId]);

  if (dataLoading || !data) {
    return <Loader />;
  }

  return (
    <View className="flex-1 bg-white " style={{ paddingBottom: bottom }}>
      <Stack.Screen
        options={{
          title: truncate(data.name),
          headerRight: () => (
            <TouchableOpacity onPress={() => {}}>
              <Iconify icon="mdi:heart-outline" size={24} color="#00A082" />
            </TouchableOpacity>
          ),
        }}
      />
      <ScrollView>
        <View className="flex-1 pb-5 space-y-6">
          {/* Head */}
          <View className="space-y-4">
            <FlatList
              data={data.media}
              renderItem={({ item }) => (
                <Image
                  source={item?.url}
                  placeholder={item?.blur_hash}
                  contentFit="cover"
                  style={{ width: Dimensions.get('screen').width, height: 333 }}
                />
              )}
              horizontal
              showsHorizontalScrollIndicator={false}
              pagingEnabled
              bounces={false}
              keyExtractor={(item, index) => String(index)}
              onScroll={Animated.event(
                [
                  {
                    nativeEvent: {
                      contentOffset: {
                        x: scrollX,
                      },
                    },
                  },
                ],
                { useNativeDriver: false }
              )}
              scrollEventThrottle={32}
              onViewableItemsChanged={viewableItemsChanged}
              ref={slidesRef}
              viewabilityConfig={viewConfig}
            />
            <Paginator
              data={data.media}
              currentIndex={currentIndex}
              scrollX={scrollX}
              backgroundColor="#00A082"
              faintColor="#CCECE6"
              style={{ justifyContent: 'center', columnGap: 4 }}
              range={[16, 58, 16]}
            />
            <View className="flex-row px-5 space-x-[13px] ">
              {data.media.map((i, index) => (
                <Pressable
                  onPress={() => {
                    slidesRef.current.scrollToIndex({
                      animated: true,
                      index: index,
                    });
                  }}
                  key={index}
                  className={` rounded ${
                    index === currentIndex
                      ? 'border border-primaryOne'
                      : 'border border-transparent'
                  } `}
                >
                  <Image
                    source={i?.url}
                    placeholder={i?.blur_hash}
                    style={{ height: 64, width: 64, borderRadius: 4 }}
                  />
                </Pressable>
              ))}
            </View>
          </View>
          {/* Body */}
          <View className="px-5" style={{ rowGap: 40 }}>
            <View className="space-y-3">
              <View className="flex-row justify-between items-stretch  ">
                <View className="max-w-[65%] space-y-2 justify-between">
                  <Text
                    className="text-base text-mainBlack"
                    style={[globalStyles.medium]}
                  >
                    {data.name}
                  </Text>
                  <Text
                    className="text-lg text-success-500 "
                    style={[globalStyles.bold]}
                  >
                    ₦{data.price}
                  </Text>
                </View>
                <View className="items-end" style={{ rowGap: 12 }}>
                  <TouchableOpacity onPress={() => setModalVisible(true)}>
                    <Iconify
                      icon="tabler:zoom-scan"
                      size={24}
                      color="#00A082"
                    />
                  </TouchableOpacity>
                  <RatingComp rating="4.5" />
                </View>
              </View>
              <Text
                className="text-sm text-mainBlack"
                style={[globalStyles.regular]}
              >
                {data.description}
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
      <View className="py-3 px-5 space-x-10 items-center flex-row ">
        <View className="px-4 py-3 border space-x-3 border-primaryOne flex-row items-center rounded-lg">
          <Iconify icon="ic:round-minus" size={16} color={'#00A082'} />
          <Text
            className="text-primaryOne w-10 text-center text-base "
            style={[globalStyles.medium]}
          >
            1
          </Text>
          <Iconify icon="ic:round-plus" size={16} color={'#00A082'} />
        </View>
        {/* <View></View> */}
        <View className="flex-1">
          <Button
            text={`Add ₦${data.price?.toLocaleString()}`}
            action={() => {}}
          />
        </View>
      </View>
      <ReactNativeModal
        isVisible={modalVisible}
        backdropOpacity={0.8}
        onBackdropPress={() => setModalVisible(false)}
        className="m-0 p-0 justify-center items-center"
      >
        <View style={{ height: Dimensions.get('screen').height / 2 }}>
          <FlatList
            data={data.media}
            renderItem={({ item }) => (
              <Image
                source={item?.url}
                placeholder={item?.blur_hash}
                contentFit="contain"
                style={{
                  width: Dimensions.get('screen').width,
                  height: Dimensions.get('screen').height / 2,
                }}
              />
            )}
            horizontal
            showsHorizontalScrollIndicator={false}
            pagingEnabled
            bounces={false}
            scrollEventThrottle={32}
          />
        </View>
      </ReactNativeModal>
    </View>
  );
};

export default ProductDetails;
