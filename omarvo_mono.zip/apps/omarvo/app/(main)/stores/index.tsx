import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import {
  LocationDropdown,
  ProductCard,
  ResStoreCard,
} from 'apps/omarvo/components';
import { ClipboardText, ShoppingCart } from 'iconsax-react-native';
import { Loader, SearchComponent } from '@omarvo/ui';
import { globalStyles } from '@omarvo/utils';
import { getStores, getTrendingProducts } from '@omarvo/store';
import { iconifyIcons } from 'apps/omarvo/constants/data';
import {
  SectionListWithHeaders,
  LargeHeader,
} from '@codeherence/react-native-header';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';

const StoresScreen = () => {
  const [loading, setLoading] = useState(true);
  const { data: profile } = useAppSelector((state) => state.profile);
  const { list } = useAppSelector((state) => state.store);
  const { trending } = useAppSelector((state) => state.products);
  const { storeCategories } = useAppSelector((state) => state.categories);
  const [params, setParams] = useState({
    category_id: '',
  });

  const { bottom } = useSafeAreaInsets();

  const dispatch = useAppDispatch();

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      setLoading(true);
      const clone: Record<any, any> = { ...params };

      Object.keys(clone).forEach((key) => {
        if (!clone[key]) {
          delete clone[key];
        }
      });

      await dispatch(getStores({ signal, params: clone }));
      await dispatch(getTrendingProducts({ signal }));
      setLoading(false);
    })();

    return () => controller.abort();
  }, [params]);

  if (!profile) {
    return <Loader />;
  }

  const icons = iconifyIcons();

  const data = [
    {
      title: '',
      data: [0],
    },
  ];

  return (
    <View className="flex-1 pb-5 bg-white" style={{ paddingBottom: bottom }}>
      <SectionListWithHeaders
        HeaderComponent={({}) => <></>}
        LargeHeaderComponent={({}) => (
          <LargeHeader
            headerStyle={{
              paddingHorizontal: 0,
              paddingVertical: 0,
              paddingTop: 20,
            }}
          >
            <View className="px-5 w-full space-y-5">
              <View style={{ rowGap: 24 }}>
                <View className="flex-row items-center justify-between ">
                  <LocationDropdown location={profile?.schools?.[0]?.name} />
                  <View className="flex-row items-center space-x-6">
                    <ShoppingCart color="#00A082" />
                    <ClipboardText color="#00A082" />
                  </View>
                </View>
                <SearchComponent showFilter />
              </View>
              <Text
                className="text-base text-mainBlack "
                style={[globalStyles.bold]}
              >
                Categories
              </Text>
            </View>
          </LargeHeader>
        )}
        contentContainerStyle={{
          backgroundColor: '#fff',
          rowGap: 20,
        }}
        sections={data}
        disableAutoFixScroll
        ignoreLeftSafeArea
        ignoreRightSafeArea
        headerFadeInThreshold={0.2}
        disableLargeHeaderFadeAnim
        style={{ flex: 1, backgroundColor: '#fff' }}
        containerStyle={{ backgroundColor: '#fff' }}
        renderItem={() => (
          <View className="space-y-3  relative px-5" style={{ rowGap: 32 }}>
            {loading ? (
              <View className="pt-20">
                <Loader />
              </View>
            ) : (
              <>
                <FlatList
                  data={list.data}
                  ListHeaderComponent={() => (
                    <View className="w-full flex-row justify-between items-center">
                      <Text
                        className="text-base text-mainBlack "
                        style={[globalStyles.medium]}
                      >
                        Top Stores
                      </Text>
                      <Text
                        className="text-sm text-mainBlack "
                        style={[globalStyles.regular]}
                      >
                        View all
                      </Text>
                    </View>
                  )}
                  renderItem={({ item }) => (
                    <ResStoreCard
                      {...item}
                      handlePress={() =>
                        router.push(`/(main)/stores/${item.id}/`)
                      }
                    />
                  )}
                  style={{ rowGap: 24 }}
                />
                <FlatList
                  ListHeaderComponent={() => (
                    <View className="w-full flex-row justify-between items-center">
                      <Text
                        className="text-base text-mainBlack "
                        style={[globalStyles.medium]}
                      >
                        Trending Items
                      </Text>
                      <Text
                        className="text-sm text-mainBlack "
                        style={[globalStyles.regular]}
                      >
                        View all
                      </Text>
                    </View>
                  )}
                  data={trending.data}
                  renderItem={({ item }) => <ProductCard {...item} />}
                  style={{ rowGap: 24 }}
                  columnWrapperStyle={{ columnGap: 18 }}
                  numColumns={2}
                />
              </>
            )}
          </View>
        )}
        bounces={false}
        stickySectionHeadersEnabled
        renderSectionHeader={() => {
          return (
            <View className="w-full py-1 bg-white">
              <FlatList
                data={storeCategories}
                renderItem={({ item }) => {
                  const isActive = params.category_id.includes(item.id);
                  return (
                    <TouchableOpacity
                      onPress={() => {
                        const ids = params.category_id
                          ? params.category_id.split(',')
                          : [];

                        if (isActive) {
                          const index = ids.indexOf(item.id);
                          ids.splice(index, 1);
                        } else {
                          ids.push(item.id);
                        }

                        setParams(
                          (prev) =>
                            (prev = {
                              ...prev,
                              category_id: ids.join(','),
                            })
                        );
                      }}
                      className={`p-2 min-w-[70px] rounded-lg border ${
                        isActive
                          ? 'bg-primaryOne border-primaryOne'
                          : 'bg-white border-[#F9F9F9]'
                      }   space-y-1 items-center justify-center `}
                    >
                      {icons[item.icon || '']}
                      <Text
                        className={`text-sm ${
                          isActive ? 'text-white' : 'text-borderOne'
                        } `}
                        style={[globalStyles.medium]}
                      >
                        {item.name}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{
                  columnGap: 16,
                  paddingHorizontal: 20,
                }}
                horizontal
              />
            </View>
          );
        }}
      />
    </View>
  );
};

export default StoresScreen;
