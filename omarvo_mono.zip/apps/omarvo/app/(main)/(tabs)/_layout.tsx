import React, { useEffect, useState } from 'react';
import { Tabs } from 'expo-router';
import { Feed, Home, Loader, Wallet } from '@omarvo/ui';
import { globalStyles } from '@omarvo/utils';
import { Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Iconify } from 'react-native-iconify';
import { useAppDispatch } from '@omarvo/hooks';
import { getRestaurantCategories, getStoreCategories } from '@omarvo/store';
// You can explore the built-in icon families and icons on the web at https://icons.expo.fyi/

export default function TabLayout() {
  const { bottom } = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);

  const dispatch = useAppDispatch();

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;

    (async () => {
      setLoading(true);
      await dispatch(getRestaurantCategories({ signal }));
      await dispatch(getStoreCategories({ signal }));
      setLoading(false);
    })();

    return () => controller.abort();
  }, []);

  if (loading) {
    return <Loader />;
  }

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#00A082',
        tabBarInactiveTintColor: '#8A97AB',
        tabBarStyle: {
          height: 72 + bottom,
          borderTopColor: '#B2E2D9',
          borderTopWidth: 1,
        },
        tabBarShowLabel: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          headerShown: false,
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? <Home state="fill" /> : <Home state="outline" />}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Home
              </Text>
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="message"
        options={{
          title: 'Message',
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? (
                <Iconify icon="ph:chat-text-fill" size={22} color={color} />
              ) : (
                <Iconify icon="ph:chat-text" size={22} color={color} />
              )}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Message
              </Text>
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="feed"
        options={{
          title: 'Feed',
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? <Feed state="fill" /> : <Feed state="outline" />}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Feed
              </Text>
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="wallet"
        options={{
          title: 'Wallet',
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? <Wallet state="fill" /> : <Wallet state="outline" />}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Wallet
              </Text>
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="account"
        options={{
          title: 'Account',
          tabBarIcon: ({ focused, color }) => (
            <View
              className={`items-center space-y-2 p-1 rounded-sm border-b-2 ${
                focused ? ' border-primaryOne' : 'border-transparent'
              } `}
            >
              {focused ? (
                <Iconify icon="ph:user-circle-fill" size={24} color={color} />
              ) : (
                <Iconify icon="ph:user-circle" size={24} color={color} />
              )}
              <Text
                className="text-xs"
                style={[globalStyles.regular, { color }]}
              >
                Account
              </Text>
            </View>
          ),
        }}
      />
    </Tabs>
  );
}
