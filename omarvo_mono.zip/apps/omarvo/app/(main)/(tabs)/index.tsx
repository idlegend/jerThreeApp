import { router } from 'expo-router';
import { FlatList, ScrollView, Text, View } from 'react-native';
import { Loader, SearchComponent, SectionCard } from '@omarvo/ui';
import { deleteSecure, globalStyles } from '@omarvo/utils';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppSelector } from '@omarvo/hooks';
import { Bag2, Location, Notification } from 'iconsax-react-native';
import { Iconify } from 'react-native-iconify';
import { sections } from 'apps/omarvo/constants/data';
import { LocationDropdown } from 'apps/omarvo/components';

export default function TabOneScreen() {
  const { top } = useSafeAreaInsets();
  const { data } = useAppSelector((state) => state.profile);

  const handleLogout = async () => {
    // await CookieManager.clearAll();
    await deleteSecure('userToken');
    router.replace('/auth/login');
  };

  if (!data) {
    return <Loader />;
  }

  return (
    <View className="flex-1 bg-white" style={{ paddingTop: top }}>
      <ScrollView className="px-5">
        <View className="py-5 " style={{ rowGap: 24 }}>
          <View className="flex-row items-center justify-between ">
            <LocationDropdown location={data?.schools?.[0]?.name} />
            <View className="flex-row items-center space-x-6">
              <Bag2 color="#00A082" />
              <Notification color="#00A082" />
            </View>
          </View>
          <SearchComponent />

          <View className="space-y-3">
            <Text
              className="text-mainBlack text-base "
              style={[globalStyles.bold]}
            >
              What would you like to find today ?
            </Text>
            <FlatList
              data={sections}
              renderItem={({ item }) => <SectionCard {...item} />}
              numColumns={2}
              columnWrapperStyle={{
                justifyContent: 'space-between',
              }}
              scrollEnabled={false}
            />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
