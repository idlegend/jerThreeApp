import { View, Text } from 'react-native';
import React from 'react';
import { deleteSecure } from '@omarvo/utils';
import { router } from 'expo-router';
import { Button } from '@omarvo/ui';

const AccountScreen = () => {
  const handleLogout = async () => {
    // await CookieManager.clearAll();
    await deleteSecure('userToken');
    router.replace('/auth/login');
  };
  return (
    <View>
      <Button text="Logout" action={handleLogout} />
    </View>
  );
};

export default AccountScreen;
