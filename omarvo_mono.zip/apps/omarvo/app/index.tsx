import { globalStyles } from '@omarvo/utils';
import { useRouter } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import {
  Animated,
  FlatList,
  StatusBar,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { slides } from '../constants/data';
import { Button, OnboardingItem, Paginator } from '@omarvo/ui';

const Onboarding = () => {
  const { bottom, top } = useSafeAreaInsets();

  const [loading, setLoading] = useState(false);
  const [alreadyViewd, setAlreadyViewd] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const scrollX = useRef(new Animated.Value(0)).current;
  const titleOpacity = useRef(new Animated.Value(0)).current;
  const descriptionOpacity = useRef(new Animated.Value(0)).current;
  const slidesRef = useRef<any>(null);
  const router = useRouter();

  const { width } = useWindowDimensions();
  const cal = width - 40 - 8 * 6;
  const mainWidth = cal / 6;
  const range = [mainWidth, mainWidth * 2, mainWidth];

  const viewableItemsChanged = useRef(({ viewableItems }: any) => {
    setCurrentIndex(viewableItems[0]?.index);
  }).current;

  const viewConfig = useRef({ viewAreaCoveragePercentThreshold: 50 }).current;

  // const checkViewedOnboarding = async () => {
  //   try {
  //     const viewdOnboarding = await AsyncStorage.getItem("@viewdOnboarding");

  //     if (viewdOnboarding === "true") {
  //       setAlreadyViewd(true);
  //     }
  //   } catch (error) {
  //     console.log(error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // const handleGetStarted = async () => {
  //   try {
  //     await AsyncStorage.setItem("@viewdOnboarding", "true");
  //   } catch (error) {
  //     console.log(error);
  //   } finally {
  //     router.replace("/");
  //   }
  // };

  // useEffect(() => {
  //   checkViewedOnboarding();
  // }, []);

  useEffect(() => {
    if (loading) {
      return;
    }
    const interval = setInterval(() => {
      const nextSlideIndex = (currentIndex + 1) % slides.length;

      slidesRef.current.scrollToIndex({
        animated: true,
        index: nextSlideIndex,
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [currentIndex, loading]);

  useEffect(() => {
    if (loading) {
      return;
    }
    Animated.timing(titleOpacity, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: false,
    }).start();

    Animated.timing(descriptionOpacity, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: false,
    }).start();

    const timeout = setTimeout(() => {
      Animated.timing(titleOpacity, {
        toValue: 0,
        duration: 1000,
        useNativeDriver: false,
      }).start();

      Animated.timing(descriptionOpacity, {
        toValue: 0,
        duration: 1000,
        useNativeDriver: false,
      }).start();
    }, 4000);

    return () => {
      clearTimeout(timeout);
    };
  }, [currentIndex, loading]);

  // if (loading) {
  //   return <Loader />;
  // }

  // if (alreadyViewd) {
  //   return <Redirect href="/(auth)/" />;
  // }

  return (
    <View
      className="flex-1  bg-secondaryOne"
      style={{
        paddingBottom: bottom,
      }}
    >
      <StatusBar barStyle={'light-content'} />
      <View
        className="flex-[0.82] relative bg-primaryOne "
        style={{
          paddingTop: top,
        }}
      >
        <View className="flex-[0.7] items-center pt-4 font-bold">
          <Paginator
            data={slides}
            currentIndex={currentIndex}
            scrollX={scrollX}
            range={range}
          />
          <Text
            onPress={() => router.replace('/auth/login')}
            className="self-end pt-6 pr-6 text-lg text-white font-bold"
          >
            Skip
          </Text>
        </View>
        <View className="flex-[0.3] px-5 ">
          <View
            className="flex-1 h-full w-full  items-center"
            style={{
              rowGap: 24,
            }}
          >
            <View className="flex flex-col h-[150px] space-y-3">
              <Animated.Text
                className="text-2xl leading-[26px] text-white text-center  "
                style={[globalStyles.medium, { opacity: titleOpacity }]}
              >
                {slides[currentIndex]?.title}
              </Animated.Text>
              <Animated.Text
                className="text-base text-white text-secondaryBlack text-center "
                style={[
                  globalStyles.regular,
                  {
                    opacity: descriptionOpacity,
                  },
                ]}
              >
                {slides[currentIndex]?.description}
              </Animated.Text>
            </View>
          </View>
        </View>
        <View className="absolute top-24 bottom-0 left-0 right-0 ">
          <FlatList
            data={slides}
            renderItem={({ item }) => <OnboardingItem item={item} />}
            horizontal
            showsHorizontalScrollIndicator={false}
            pagingEnabled
            bounces={false}
            keyExtractor={(item) => item.id}
            onScroll={Animated.event(
              [
                {
                  nativeEvent: {
                    contentOffset: {
                      x: scrollX,
                    },
                  },
                },
              ],
              { useNativeDriver: false }
            )}
            scrollEventThrottle={32}
            onViewableItemsChanged={viewableItemsChanged}
            ref={slidesRef}
            style={{ flex: 1 }}
            viewabilityConfig={viewConfig}
          />
        </View>
      </View>
      {/* Get Started */}
      <View className="flex-[0.18] justify-center px-5">
        <Button
          text="Next"
          action={() =>
            slides.length === currentIndex + 1
              ? router.replace('/auth/login')
              : (() => {
                  const nextSlideIndex = (currentIndex + 1) % slides.length;

                  slidesRef.current.scrollToIndex({
                    animated: true,
                    index: nextSlideIndex,
                  });
                })()
          }
          styles={{
            borderColor: '#00A082',
            borderWidth: 1,
            backgroundColor: '#fff',
          }}
          textStyles={{
            color: '#00A082',
          }}
        />
      </View>
    </View>
  );
};

export default Onboarding;
