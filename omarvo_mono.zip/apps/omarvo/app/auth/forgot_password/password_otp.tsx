import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useState } from 'react';
import { router } from 'expo-router';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import { postVerifyEmail } from '@omarvo/store';
import { throwError } from '@omarvo/utils';
import { Verification } from '@omarvo/ui';
import VerifcationSvg from '../../../assets/svgs/verification.svg';

export default function PasswordOTP() {
  const dispatch = useAppDispatch();
  const email = useAppSelector((state) => state.forgotPassword.email);
  const { bottom, top } = useSafeAreaInsets();
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);

  const handleVerify = async () => {
    setLoading(true);
    const res: any = await dispatch(postVerifyEmail({ email, otp }));
    if (res.error) {
      setLoading(false);
      throwError(res?.payload);
      return;
    }
    setLoading(false);
    router.replace('/auth/forgot_password/reset_password');
  };

  const values = {
    email,
    value: otp,
    setValue: setOtp,
    handleVerify,
    handleResendOTP: async () => {},
    loading,
    resending: false,
    Svg: VerifcationSvg,
  };

  return <Verification {...values} />;
}
