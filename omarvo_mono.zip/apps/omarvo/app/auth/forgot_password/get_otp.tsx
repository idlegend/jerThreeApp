import { Text, View, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import VerifcationSvg from '../../../assets/svgs/verification.svg';
import { Formik } from 'formik';
import * as yup from 'yup';
import { router } from 'expo-router';
import { useAppDispatch } from '@omarvo/hooks';
import { globalStyles, throwError } from '@omarvo/utils';
import { postForgotEmail } from '@omarvo/store';
import { Button, Input } from '@omarvo/ui';

interface forgotPasswordValue {
  email: string;
}

const forgotPasswordSchema = yup.object().shape({
  email: yup
    .string()
    .email('Enter a valid email address')
    .required('This field is required.'),
});

export default function GetOtp() {
  const initialValues: forgotPasswordValue = {
    email: '',
  };
  const { bottom, top } = useSafeAreaInsets();

  const dispatch = useAppDispatch();

  return (
    <View
      className="flex-1 bg-white"
      style={{
        paddingBottom: bottom,
        paddingTop: top,
      }}
    >
      <ScrollView bounces={false} className="px-5">
        <View className="py-6" style={{ rowGap: 36 }}>
          <View className="flex flex-col space-y-6 items-center">
            <VerifcationSvg />
            <View className="w-full flex flex-col items-center space-y-2 pb-10">
              <Text
                className="text-2xl text-center"
                style={[globalStyles.medium, globalStyles.textGreen]}
              >
                Forgot Password
              </Text>
              <Text
                className="text-center text-base "
                style={[globalStyles.regular]}
              >
                Enter the email of your account
              </Text>
            </View>
            <Formik
              initialValues={initialValues}
              onSubmit={async (values, { setSubmitting }) => {
                const res: any = await dispatch(postForgotEmail(values));
                if (res.error) {
                  setSubmitting(false);
                  throwError(res?.payload);
                  return;
                }
                setSubmitting(false);
                router.push('/auth/forgot_password/password_otp');
              }}
              validationSchema={forgotPasswordSchema}
              validateOnMount
            >
              {({
                setFieldValue,
                handleBlur,
                handleSubmit,
                errors,
                touched,
                values,
                isSubmitting,
                isValid,
              }) => (
                <View className="w-full" style={{ rowGap: 36 }}>
                  <View
                    style={{
                      rowGap: 24,
                    }}
                  >
                    <Input
                      label="Email"
                      name="email"
                      value={values.email}
                      errors={errors.email}
                      touched={touched.email}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Enter email address"
                      type="emailAddress"
                      mode="email"
                    />
                  </View>
                  <Button
                    text="Submit"
                    action={handleSubmit}
                    loading={isSubmitting}
                    disabled={!isValid}
                  />
                </View>
              )}
            </Formik>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
