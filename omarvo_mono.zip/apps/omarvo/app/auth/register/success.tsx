import React from 'react';
import SuccessSvg from '../../../assets/svgs/rp_success.svg';
import { Success } from '@omarvo/ui';
import { router } from 'expo-router';

const RegistrationSuccess = () => {
  return (
    <Success
      Svg={SuccessSvg}
      message="Your email address has been verified successfully! Welcome to Omarvo"
      buttonText="Start Shopping"
      action={() => router.replace('/(tabs)/')}
    />
  );
};

export default RegistrationSuccess;
