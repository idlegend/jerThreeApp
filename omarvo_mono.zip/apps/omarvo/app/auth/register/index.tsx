import { View, Text, ScrollView, Pressable } from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import { Formik } from 'formik';
import * as yup from 'yup';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from '@omarvo/hooks';
import {
  Button,
  CheckBox,
  Input,
  Loader,
  RadioGroupComp,
  RegisterHeader,
  Select,
  TextArea,
} from '@omarvo/ui';
import RegisterSvg from '../../../assets/svgs/register.svg';
import { RegisterData, globalStyles, throwError } from '@omarvo/utils';
import { getSchoolCampuses, postRegister } from '@omarvo/store';
import { router } from 'expo-router';

const schoolSchema = yup.object().shape({
  first_name: yup.string().required('This field is required.'),
  last_name: yup.string().required('This field is required.'),
  email: yup.string().required('This field is required.'),
  phone_no: yup.string().required('This field is required.'),
  phone_code: yup.string().required('This field is required.'),
  gender: yup.string().required('This field is required.'),
  password: yup
    .string()
    .required('Password is required')
    .min(8, 'Password must be at least 8 characters long')
    .matches(/[a-z]/, 'Password must contain at least one lowercase letter')
    .matches(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .matches(/[0-9]/, 'Password must contain at least one number'),
  confirm_password: yup
    .string()
    .required('This field is required')
    .oneOf([yup.ref('password')], 'Passwords must match'),
  school_id: yup.string().required('This field is required.'),
  campus_id: yup.string().required('This field is required.'),
  on_campus: yup.boolean().required('This field is required.'),
  read: yup.boolean().isTrue().required('This field is required.'),
  hostel: yup.string().when('on_campus', {
    is: true,
    then: (schema) => schema.required('This field is required'),
  }),
  area: yup.string().when('on_campus', {
    is: false,
    then: (schema) => schema.required('This field is required'),
  }),
  landmark: yup.string().when('on_campus', {
    is: false,
    then: (schema) => schema.required('This field is required'),
  }),
});

interface regsiterValues {
  first_name: string;
  last_name: string;
  email: string;
  phone_no: string;
  phone_code: string;
  gender: string;
  password: string;
  confirm_password: string;
  school_id: string;
  campus_id: string;
  on_campus: NonNullable<boolean | undefined>;
  hostel: string | undefined;
  area: string | undefined;
  landmark: string | undefined;
  read: boolean;
}

const Register = () => {
  const { campuses, campusesLoading } = useAppSelector((state) => state.css);
  const { location } = useAppSelector((state) => state.register);

  const initialValues: regsiterValues = {
    first_name: '',
    last_name: '',
    email: '',
    phone_code: location.phone_code,
    phone_no: '',
    gender: '',
    school_id: location.school_id,
    campus_id: '',
    on_campus: true,
    hostel: '',
    area: '',
    landmark: '',
    password: '',
    confirm_password: '',
    read: false,
  };

  const { bottom } = useSafeAreaInsets();

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (!location.school_id) {
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    dispatch(
      getSchoolCampuses({
        signal,
        school_id: location.school_id,
      })
    );

    return () => controller.abort();
  }, [location.school_id]);

  if (campusesLoading) {
    return <Loader />;
  }

  const handleRegister = async (values: regsiterValues) => {
    const body: RegisterData = {
      email: values.email,
      first_name: values.first_name,
      last_name: values.last_name,
      gender: values.gender,
      password: values.password,
      phone_code: values.phone_code,
      phone_no: values.phone_no,
      school_id: values.school_id,
      school_address: {
        school_id: values.school_id,
        area: values.area,
        campus_id: values.campus_id,
        hostel: values.hostel,
        landmark: values.landmark,
        on_campus: values.on_campus,
      },
    };
    const res = await dispatch(postRegister({ body }));
    return res as any;
  };

  return (
    <View
      className="flex-1 bg-white"
      style={{
        paddingBottom: bottom,
      }}
    >
      <ScrollView bounces={false} className="px-5">
        <View
          className="py-2"
          style={{
            rowGap: 28,
          }}
        >
          <RegisterHeader
            title="Create Account"
            subText="Please provide the following information"
            showCountry={false}
            Svg={RegisterSvg}
          />
          <Formik
            initialValues={initialValues}
            onSubmit={async (values, { setSubmitting }) => {
              const res = await handleRegister(values);

              if (res.error) {
                setSubmitting(false);
                throwError(res?.payload);
                return;
              }
              setSubmitting(false);
              router.push('/auth/register/verify');
            }}
            validationSchema={schoolSchema}
            validateOnMount
          >
            {({
              setFieldValue,
              handleBlur,
              handleSubmit,
              errors,
              touched,
              values,
              isSubmitting,
              isValid,
            }) => (
              <View
                style={{
                  rowGap: 36,
                }}
              >
                <View
                  style={{
                    rowGap: 24,
                  }}
                >
                  <Input
                    label="First Name"
                    name="first_name"
                    value={values.first_name}
                    errors={errors.first_name}
                    touched={touched.first_name}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter first name"
                    type="givenName"
                    mode="text"
                  />

                  <Input
                    label="Last Name"
                    name="last_name"
                    value={values.last_name}
                    errors={errors.last_name}
                    touched={touched.last_name}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter last name"
                    type="familyName"
                    mode="text"
                  />

                  <Input
                    label="Email"
                    name="email"
                    value={values.email}
                    errors={errors.email}
                    touched={touched.email}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter email address"
                    type="emailAddress"
                    mode="email"
                  />

                  <Input
                    label="Phone Number"
                    name="phone_no"
                    value={values.phone_no}
                    errors={errors.phone_no}
                    touched={touched.phone_no}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter phone no"
                    type="telephoneNumber"
                    mode="tel"
                    leadingAccessory={
                      <View className="bg-secondaryThree py-1 px-[10px] rounded ">
                        <Text
                          className="text-primaryOne text-base"
                          style={[globalStyles.regular]}
                        >
                          {values.phone_code}
                        </Text>
                      </View>
                    }
                  />

                  <Select
                    label="Gender"
                    name="gender"
                    value={values.gender}
                    errors={errors.gender}
                    touched={touched.gender}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Select Gender"
                    items={[
                      { label: 'Male', value: 'male' },
                      { label: 'Female', value: 'female' },
                    ]}
                  />

                  <Select
                    label="Select Campus"
                    name="campus_id"
                    value={values.campus_id}
                    errors={errors.campus_id}
                    touched={touched.campus_id}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Select a Campus"
                    items={campuses.map((item) => ({
                      label: item.name,
                      value: item.id,
                    }))}
                  />
                  {values.campus_id && (
                    <>
                      <RadioGroupComp
                        label="Where do you live?"
                        name="on_campus"
                        value={values.on_campus}
                        errors={errors.on_campus}
                        touched={touched.on_campus}
                        handleChange={setFieldValue}
                        handleBlur={handleBlur}
                        buttons={[
                          {
                            label: 'On Campus',
                            value: true,
                          },
                          {
                            label: 'Off Campus',
                            value: false,
                          },
                        ]}
                      />

                      {values.on_campus ? (
                        <>
                          <Select
                            label="Hostel"
                            name="hostel"
                            value={values.hostel}
                            errors={errors.hostel}
                            touched={touched.hostel}
                            handleChange={setFieldValue}
                            handleBlur={handleBlur}
                            placeholder="Select a Hostel"
                            items={
                              campuses
                                .find(
                                  (c) =>
                                    c.id.toString() ===
                                    values.campus_id.toString()
                                )
                                ?.hostels?.map((item) => ({
                                  label: item,
                                  value: item,
                                })) || []
                            }
                          />
                        </>
                      ) : (
                        <>
                          <Select
                            label="Area"
                            name="area"
                            value={values.area}
                            errors={errors.area}
                            touched={touched.area}
                            handleChange={setFieldValue}
                            handleBlur={handleBlur}
                            placeholder="Select a Area"
                            items={
                              campuses
                                .find(
                                  (c) =>
                                    c.id.toString() ===
                                    values.campus_id.toString()
                                )
                                ?.off_campus_areas?.map((item) => ({
                                  label: item,
                                  value: item,
                                })) || []
                            }
                          />
                          <TextArea
                            label="Description of Address/Landmark"
                            name="landmark"
                            value={values.landmark || ''}
                            errors={errors.landmark}
                            touched={touched.landmark}
                            handleChange={setFieldValue}
                            handleBlur={handleBlur}
                            placeholder="Enter address description or Landmark"
                            type="none"
                            mode="text"
                          />
                        </>
                      )}
                    </>
                  )}
                  <Input
                    label="Password"
                    name="password"
                    value={values.password}
                    errors={errors.password}
                    touched={touched.password}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter password"
                    type="password"
                    secureTextEntry={true}
                  />

                  <Input
                    label="Confirm Password"
                    name="confirm_password"
                    value={values.confirm_password}
                    errors={errors.confirm_password}
                    touched={touched.confirm_password}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Confirm password"
                    type="password"
                    secureTextEntry={true}
                  />
                  <CheckBox
                    name="read"
                    label={
                      <View
                        className="w-full flex-row items-center flex-wrap "
                        style={{ gap: 4 }}
                      >
                        <Text
                          className="text-mainBlack"
                          style={[globalStyles.regular, { fontSize: 16 }]}
                        >
                          I have read and agreed to Omarvo's{' '}
                        </Text>
                        <Pressable onPress={() => ''}>
                          <Text
                            className="text-primaryOne "
                            style={[globalStyles.regular, { fontSize: 16 }]}
                          >
                            Terms & Conditions
                          </Text>
                        </Pressable>
                        <Text
                          className="text-mainBlack"
                          style={[globalStyles.regular, { fontSize: 16 }]}
                        >
                          and
                        </Text>
                        <Pressable onPress={() => ''}>
                          <Text
                            className="text-primaryOne "
                            style={[globalStyles.regular, { fontSize: 16 }]}
                          >
                            Privacy Policy.
                          </Text>
                        </Pressable>
                      </View>
                    }
                    errors={errors.read}
                    touched={touched.read}
                    value={values.read}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                  />
                </View>
                <Button
                  text="Sign Up"
                  action={handleSubmit}
                  loading={isSubmitting}
                  disabled={!isValid}
                />
              </View>
            )}
          </Formik>
        </View>
      </ScrollView>
    </View>
  );
};

export default Register;
