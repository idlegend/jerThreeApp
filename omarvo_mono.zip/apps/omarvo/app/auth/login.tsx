import { View, Text, Pressable, ScrollView } from 'react-native';
import React from 'react';
import LoginSvg from '../../assets/svgs/login.svg';
import { Formik } from 'formik';
import * as yup from 'yup';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { globalStyles, throwError } from '@omarvo/utils';
import { postSignIn } from '@omarvo/store';
import { useAppDispatch } from '@omarvo/hooks';
import { Button, Input } from '@omarvo/ui';

const signinSchema = yup.object().shape({
  email: yup
    .string()
    .email('Email address is incorrect')
    .required('This field is required.'),
  password: yup.string().required('This field is required.'),
});

interface signinValues {
  email: string;
  password: string;
}

const LoginComp = () => {
  const initialValues: signinValues = {
    email: '',
    password: '',
  };

  const { bottom, top } = useSafeAreaInsets();

  const dispatch = useAppDispatch();

  return (
    <View
      className="flex-1 bg-white"
      style={{
        paddingBottom: bottom,
        paddingTop: top,
      }}
    >
      <ScrollView bounces={false} className="px-5 py-5 ">
        <View style={{ rowGap: 36 }}>
          <View className="w-full space-y-2 items-center ">
            <LoginSvg />
            <Text
              className="text-[30px] text-mainBlack "
              style={[globalStyles.medium]}
            >
              Welcome!
            </Text>
            <Text
              className="text-base text-mainBlack "
              style={[globalStyles.regular]}
            >
              Enter your Login Information
            </Text>
          </View>
          <Formik
            initialValues={initialValues}
            onSubmit={async (values, { setSubmitting }) => {
              const res: any = await dispatch(postSignIn(values));
              if (res.error) {
                setSubmitting(false);
                throwError(res?.payload);
                return;
              }
              setSubmitting(false);
              router.replace('/(tabs)/');
            }}
            validationSchema={signinSchema}
            validateOnMount
          >
            {({
              setFieldValue,
              handleBlur,
              handleSubmit,
              errors,
              touched,
              values,
              isSubmitting,
              isValid,
            }) => (
              <View
                style={{
                  rowGap: 36,
                }}
              >
                <View
                  style={{
                    rowGap: 24,
                  }}
                >
                  <Input
                    label="Email"
                    name="email"
                    value={values.email}
                    errors={errors.email}
                    touched={touched.email}
                    handleChange={setFieldValue}
                    handleBlur={handleBlur}
                    placeholder="Enter email address"
                    type="emailAddress"
                    mode="email"
                  />
                  <View className="space-y-2">
                    <Input
                      label="Password"
                      name="password"
                      value={values.password}
                      errors={errors.password}
                      touched={touched.password}
                      handleChange={setFieldValue}
                      handleBlur={handleBlur}
                      placeholder="Enter password"
                      type="password"
                      secureTextEntry={true}
                    />
                    <Pressable
                      onPress={() =>
                        router.push('/auth/forgot_password/get_otp')
                      }
                    >
                      <Text
                        className="text-primaryOne text-xs"
                        style={[globalStyles.medium]}
                      >
                        Forgot Password?
                      </Text>
                    </Pressable>
                  </View>
                </View>
                <Button
                  text="Login"
                  action={handleSubmit}
                  loading={isSubmitting}
                  disabled={!isValid}
                />
              </View>
            )}
          </Formik>
          <View className="w-full flex-row items-center space-x-1 justify-center ">
            <Text
              className="text-mainBlack"
              style={[globalStyles.regular, { fontSize: 16 }]}
            >
              Don't have an account?{' '}
            </Text>
            <Pressable
              onPress={() => router.push('/auth/register/choose_country')}
            >
              <Text
                className="text-primaryOne "
                style={[globalStyles.medium, { fontSize: 16 }]}
              >
                Sign up
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default LoginComp;
