import { Iconify } from 'react-native-iconify';
import OnboardingOne from '../assets/svgs/onboarding_1.svg';
import OnboardingTwo from '../assets/svgs/onboarding_2.svg';
import OnboardingThree from '../assets/svgs/onboarding_3.svg';
import OnboardingFour from '../assets/svgs/onboarding_4.svg';
import OnboardingFive from '../assets/svgs/onboarding_5.svg';
import { router } from 'expo-router';

export const iconifyIcons: (
  color?: string,
  size?: number
) => Record<string, React.JSX.Element> = (color = '#FFC244', size = 24) => {
  return {
    'mdi:chicken-leg': (
      <Iconify icon="mdi:chicken-leg" color={color} size={size} />
    ),
    'bxs:dish': <Iconify icon="bxs:dish" color={color} size={size} />,
    'mdi:pasta': <Iconify icon="mdi:pasta" color={color} size={size} />,
    'mdi:burger': <Iconify icon="mdi:burger" color={color} size={size} />,
    'fa6-solid:bowl-rice': (
      <Iconify icon="fa6-solid:bowl-rice" color={color} size={size} />
    ),
    'ri:drinks-2-fill': (
      <Iconify icon="ri:drinks-2-fill" color={color} size={size} />
    ),
    'ph:bowl-food-fill': (
      <Iconify icon="ph:bowl-food-fill" color={color} size={size} />
    ),
    'mdi:television': (
      <Iconify icon="mdi:television" color={color} size={size} />
    ),
    'mdi:tshirt-crew': (
      <Iconify icon="mdi:tshirt-crew" color={color} size={size} />
    ),
    'mdi:sofa': <Iconify icon="mdi:sofa" color={color} size={size} />,
    'mdi:book-open-variant': (
      <Iconify icon="mdi:book-open-variant" color={color} size={size} />
    ),
    'mdi:basketball': (
      <Iconify icon="mdi:basketball" color={color} size={size} />
    ),
    'mdi:lipstick': <Iconify icon="mdi:lipstick" color={color} size={size} />,
    'mdi:toy-brick': <Iconify icon="mdi:toy-brick" color={color} size={size} />,
    'mdi:car': <Iconify icon="mdi:car" color={color} size={size} />,
    'mdi:dog': <Iconify icon="mdi:dog" color={color} size={size} />,
    'mdi:briefcase': <Iconify icon="mdi:briefcase" color={color} size={size} />,
    'mdi:cart': <Iconify icon="mdi:cart" color={color} size={size} />,
    'mdi:chair-rolling': (
      <Iconify icon="mdi:chair-rolling" color={color} size={size} />
    ),
    'mdi:diamond-stone': (
      <Iconify icon="mdi:diamond-stone" color={color} size={size} />
    ),
    'mdi:music': <Iconify icon="mdi:music" color={color} size={size} />,
    'mdi:flower': <Iconify icon="mdi:flower" color={color} size={size} />,
    'mdi:wrench': <Iconify icon="mdi:wrench" color={color} size={size} />,
    'mdi:baby-bottle': (
      <Iconify icon="mdi:baby-bottle" color={color} size={size} />
    ),
    'mdi:palette': <Iconify icon="mdi:palette" color={color} size={size} />,
    'mdi:factory': <Iconify icon="mdi:factory" color={color} size={size} />,
    'mdi:suitcase': <Iconify icon="mdi:luggage" color={color} size={size} />,
    'mdi:cellphone': <Iconify icon="mdi:cellphone" color={color} size={size} />,
    'mdi:controller-classic': (
      <Iconify icon="mdi:controller-classic" color={color} size={size} />
    ),
    'mdi:watch': <Iconify icon="mdi:watch" color={color} size={size} />,
    'mdi:code-tags': <Iconify icon="mdi:code-tags" color={color} size={size} />,
    'mdi:guitar-electric': (
      <Iconify icon="mdi:guitar-electric" color={color} size={size} />
    ),
    'mdi:camera': <Iconify icon="mdi:camera" color={color} size={size} />,
    'mdi:washing-machine': (
      <Iconify icon="mdi:washing-machine" color={color} size={size} />
    ),
    'mdi:brush': <Iconify icon="mdi:brush" color={color} size={size} />,
    'mdi:hand-heart': (
      <Iconify icon="mdi:hand-heart" color={color} size={size} />
    ),
    'mdi:face': <Iconify icon="mdi:face" color={color} size={size} />,
    'mdi:bottle-wine': (
      <Iconify icon="mdi:bottle-wine" color={color} size={size} />
    ),
  };
};

export const daysArray = [
  'Sunday',
  'Monday',
  'Tueday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

export const slides = [
  {
    id: '1',
    title: 'Find Exquisite Services',
    description:
      'Discover a curated selection of tailored, top-notch services that perfectly align with your preferences and needs, all at your fingertips.',
    image: <OnboardingOne />,
  },
  {
    id: '2',
    title: 'Find Restaurants Easily',
    description:
      'Explore a diverse array of dining options nearby with just a few taps, ranging from cozy cafes to upscale eateries, ensuring you always find the perfect spot to satisfy your cravings.',
    image: <OnboardingTwo />,
  },
  {
    id: '3',
    title: 'Shop from Stores Near You',
    description:
      "Offering everything from everyday essentials to unique finds, ensuring you find exactly what you're looking for without the need to travel far.",
    image: <OnboardingThree />,
  },
  {
    id: '4',
    title: 'Locate  Events',
    description:
      "Most exciting events happening around you, whether it's concerts, workshops, or cultural festivals, ensuring you always have something fun and interesting to do nearby.",
    image: <OnboardingFour />,
  },
  {
    id: '5',
    title: 'Quick and Fast Errand Delivery',
    description:
      'Get your errands completed swiftly and effortlessly with quick and efficient delivery service, ensuring that your tasks are taken care of promptly.',
    image: <OnboardingFive />,
  },
];

export const sections = [
  {
    icon: <Iconify icon="ion:restaurant-sharp" size={16} color="#fff" />,
    name: 'Restaurants',
    description: 'Build your menu and reach more customers nearby',
    primaryColor: '#DDDDFD',
    secondaryColor: '#4C4CC3',
    handlePress: () => router.push('/(main)/restaurants/'),
  },
  {
    icon: <Iconify icon="streamline:store-1-solid" size={16} color="#fff" />,
    name: 'Stores',
    description: 'Find nearby stores for all your shopping needs',
    primaryColor: '#FDF1DD',
    secondaryColor: '#E8B053',
    handlePress: () => router.push('/(main)/stores/'),
  },
];
