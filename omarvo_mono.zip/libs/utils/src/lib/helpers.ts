import * as SecureStore from 'expo-secure-store';
import { messageAlert } from './alert';
import { ImagePickerAsset } from 'expo-image-picker';

export const saveSecure = async (key: string, value: string) => {
  await SecureStore.setItemAsync(key, value);
};
export const getSecureValueFor = async (key: string) => {
  const result = await SecureStore.getItemAsync(key);
  return result;
};
export const deleteSecure = async (key: string) => {
  await SecureStore.deleteItemAsync(key);
};

export const processMedia = (asset: ImagePickerAsset) => {
  const fileName = asset?.fileName || asset?.uri?.split('/').pop();
  const file = {
    uri: asset.uri,
    type: `${asset.type}/${fileName?.split('.').pop()}`,
    name: fileName,
  };

  return file;
};

export const throwError = (payload: { error: string }[], title = 'Error') => {
  if (!payload || typeof payload !== 'object') {
    return messageAlert(title, 'Oops, Something went wrong');
  }

  payload.forEach((item: any) => {
    messageAlert(title, item.error || 'Oops, Something went wrong');
  });
};

export const formatFormData = (
  values: Record<string, any>,
  body: FormData,
  prefix = ''
) => {
  Object.keys(values).forEach((key) => {
    const value = values[key];
    if (Array.isArray(value)) {
      value.forEach((item, index) => {
        if (typeof item === 'object') {
          formatFormData(item, body, `${prefix}${key}[${index}].`);
        } else {
          body.append(`${key}[${index}]`, item);
        }
      });
    } else if (typeof value === 'object') {
      formatFormData(value, body, `${prefix}${key}.`);
    } else {
      body.append(`${prefix}${key}`, value);
    }
  });
};
