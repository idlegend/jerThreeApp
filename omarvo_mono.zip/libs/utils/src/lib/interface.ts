export interface Pagination {
  total: number;
  items_per_page: number;
  page: number;
}

export type RegisterData = {
  first_name: string;
  last_name: string;
  email: string;
  phone_no: string;
  phone_code: string;
  gender: string;
  password: string;
  school_id: string;
  school_address: {
    campus_id: string;
    school_id: string;
    on_campus: NonNullable<boolean | undefined>;
    hostel: string | undefined;
    area: string | undefined;
    landmark: string | undefined;
  };
};

export type EntrepreneurRegisterData = {
  first_name: string;
  last_name: string;
  email: string;
  phone_no: string;
  phone_code: string;
  password: string;
  gender: string;
  school_id: string;
  nin: string;
  is_student: boolean;
};

export interface Entrepreneur {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  nin: string;
  phoneCode: string;
  phoneNo: string;
  gender: string;
  symbol: string;
  currency: string;
  is_student: boolean;
  schools: School[];
}

export interface User {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phoneCode: string;
  phoneNo: string;
  gender: string;
  symbol: string;
  currency: string;
  schools: School[];
}

export interface File {
  uri: string;
  type: string;
  name: string | undefined;
}

export interface Restaurant {
  id: string;
  name: string;
  description: string;
  owner_id?: string;
  is_active?: boolean;
  is_reg_business: boolean;
  rc_number: string;
  media?: Media;
  opening_hours: Openinghour[];
  school_address: SchoolAddress;
  restaurant_banner?: any;
  victuals?: null;
  categories?: Category[];
  stats?: Stats;
}

export interface Store {
  id: string;
  name: string;
  description: string;
  owner_id?: string;
  is_active?: boolean;
  is_reg_business: boolean;
  rc_number: string;
  media?: Media;
  opening_hours: Openinghour[];
  school_address: SchoolAddress;
  store_banner?: any;
  victuals?: null;
  categories?: Category[];
  stats?: Stats;
}

export interface Victualcategory {
  id: string;
  name: string;
}

export interface Stats {
  num_of_items: number;
  todays_earning: number;
  ongoing_orders_count: number;
  completed_order_count: number;
}

export interface Category {
  name: string;
  id: string;
  icon?: string;
}

export interface Victual {
  id: string;
  name: string;
  price: number;
  description: string;
  in_stock?: boolean;
  media: Media[];
  selections: Selection[];
  stats?: ItemStats;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  quantity: number;
  is_negotiable: boolean;
  in_stock?: boolean;
  media: Media[];
  stats?: ItemStats;
}

export interface ItemStats {
  todays_orders: number;
  todays_earning: number;
  ongoing_orders_count: number;
  completed_order_count: number;
}

export interface Selection {
  id: string;
  title: string;
  is_required: boolean;
  options: Option[];
}

export interface Option {
  name: string;
  upcharge: number;
}

export interface SchoolAddress {
  id?: string;
  school_id: string;
  campus_id: string;
  on_campus: boolean;
  is_entrepreneur: boolean;
  base: string;
  is_default?: boolean;
  restaurant_id?: string;
}

export interface Openinghour {
  day_of_week: number;
  open_time: any;
  close_time: any;
}

export interface Media {
  id: string;
  type: string;
  url: string;
  content_type: string;
  size: number;
  blur_hash: string;
}

export type State = {
  id: number;
  name: string;
  country_id: number;
  state_code: string;
  country_name: string;
};

export type School = {
  id: string;
  name: string;
  country_id: number;
  state_id: number;
};

export type Campus = {
  id: string;
  name: string;
  school_id: string;
  longitude: string;
  latitude: string;
  hostels: string[];
  bases: string[];
  off_campus_areas: string[];
};
