import { StyleSheet } from 'react-native';

export const globalStyles = StyleSheet.create({
  bold: {
    fontWeight: '700',
    fontFamily: 'bold',
  },
  medium: {
    fontWeight: '500',
    fontFamily: 'medium',
  },
  regular: {
    fontWeight: '400',
    fontFamily: 'regular',
  },
  light: {
    fontWeight: '300',
    fontFamily: 'light',
  },
  codeFiledRoot: { marginTop: 20 },
  cell: {
    width: 56,
    height: 56,
    lineHeight: 54,
    fontSize: 20,
    borderWidth: 1,
    borderRadius: 8,
    borderColor: '#E4E5E7',
    textAlign: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#2B2B2B',
  },
  focusCell: {
    borderColor: '#00A082',
  },
  textGreen: {
    color: '#00A082',
  },
  big_text: {
    fontSize: 23,
  },
  normal_text: {
    fontSize: 16,
  },
});

export const options: any = {
  headerTitleAlign: 'center',
  headerShadowVisible: false,
  headerTitleStyle: {
    fontWeight: '500',
    fontFamily: 'medium',
    fontSize: 18,
    color: '#00A082',
  },
  headerTintColor: '#222B38',
  headerBackTitleVisible: false,
  animation: 'slide_from_right',
};
