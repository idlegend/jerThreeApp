import { globalStyles } from '@omarvo/utils';
import React from 'react';
import { Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button } from './button';
import { SvgProps } from 'react-native-svg';

type Props = {
  title?: string;
  message: string;
  buttonText: string;
  action: () => void;
  Svg: React.FC<SvgProps>;
};

const Success: React.FC<Props> = ({
  title = 'Congratulations!🎉',
  message,
  buttonText,
  action,
  Svg,
}) => {
  const { top, bottom } = useSafeAreaInsets();

  return (
    <View
      className="flex-1 justify-center bg-white"
      style={{
        paddingTop: top,
        paddingBottom: bottom,
      }}
    >
      <View className="px-5 items-center space-y-10 ">
        <View className="items-center space-y-6">
          <Svg />
          <View className="items-center space-y-2">
            <Text
              className="text-lg text-mainBlack "
              style={[globalStyles.medium]}
            >
              {title}
            </Text>
            <Text
              className="text-base text-mainBlack  text-center"
              style={[globalStyles.regular]}
            >
              {message}
            </Text>
          </View>
        </View>
        <View className="w-full">
          <Button text={buttonText} action={action} />
        </View>
      </View>
    </View>
  );
};

export { Success };
