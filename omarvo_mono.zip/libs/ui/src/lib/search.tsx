import { globalStyles } from '@omarvo/utils';
import { View, Text, Platform } from 'react-native';
import { Iconify } from 'react-native-iconify';
import { TextField } from 'react-native-ui-lib';
import { SearchNormal } from 'iconsax-react-native';

interface Props {
  placeholder?: string;
  showFilter?: boolean;
}

const SearchComponent: React.FC<Props> = ({
  placeholder = 'Search',
  showFilter = false,
}) => {
  return (
    <View className="w-full flex-row space-x-3 ">
      <TextField
        placeholder={placeholder}
        placeholderTextColor="#6E7A8B"
        className="text-mainBlack"
        color="#1B222D"
        style={[globalStyles.regular, { fontSize: 14 }]}
        containerStyle={[
          {
            height: 48,
            borderWidth: 1,
            borderColor: '#DADEE3',
            paddingHorizontal: 12,
            borderRadius: 8,
            flex: 1,
          },
        ]}
        fieldStyle={{
          height: '100%',
          alignItems: 'center',
        }}
        leadingAccessory={
          <>
            <SearchNormal
              size={20}
              color="#6E7A8B"
              style={{ marginRight: 8 }}
            />
          </>
        }
        // onChangeText={handleChange}
      />
      {showFilter && (
        <View className="w-12 items-center justify-center border border-[#DADEE3] rounded-lg ">
          <Iconify icon="ion:filter-sharp" size={24} color="#6E7A8B" />
        </View>
      )}
    </View>
  );
};

export { SearchComponent };
