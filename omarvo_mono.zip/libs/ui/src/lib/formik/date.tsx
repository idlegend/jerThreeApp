import React from 'react';
import { Platform, Text, View } from 'react-native';
import { DateTimePicker } from 'react-native-ui-lib';
import { Iconify } from 'react-native-iconify';
import moment from 'moment';
import { globalStyles } from '@omarvo/utils';

interface Props {
  label: string;
  name: string;
  value: Date | undefined;
  placeholder: string;
  handleChange: any;
  errors: any;
  touched: any;
  handleBlur?: any;
  disabled?: boolean;
  mode?: 'date' | 'time';
}

const DateTime: React.FC<Props> = ({
  label,
  name,
  placeholder,
  value,
  handleChange,
  handleBlur,
  disabled,
  errors,
  touched,
  mode = 'date',
}) => {
  return (
    <View className="w-full flex space-y-2">
      <DateTimePicker
        label={label}
        placeholder={placeholder}
        mode={mode}
        value={value}
        onChange={(e) => handleChange(name, e)}
        onBlur={handleBlur(name)}
        fieldStyle={{
          borderWidth: 1,
          borderColor: '#DADEE3',
          padding: Platform.OS === 'ios' ? 16 : 14,
          borderRadius: 8,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#fff',
        }}
        style={[
          globalStyles.regular,
          {
            fontSize: 16,
            color: '#1B222D',
            textTransform: 'capitalize',
          },
        ]}
        labelStyle={[
          globalStyles.regular,
          {
            paddingBottom: 8,
            fontSize: 16,
            color: '#1B222D',
          },
        ]}
        containerStyle={{
          flexDirection: 'column',
        }}
        placeholderTextColor="#858C94"
        trailingAccessory={
          mode === 'time' ? (
            <Iconify icon="radix-icons:clock" size={20} color="#858C94" />
          ) : (
            <Iconify icon="ic:round-date-range" size={20} color="#858C94" />
          )
        }
        dateTimeFormatter={(value, mode) => {
          if (mode === 'time') {
            return moment(value).format('h:mm A');
          } else {
            return moment(value).format('l');
          }
        }}
      />
      {errors && touched && (
        <Text
          style={[
            globalStyles.regular,
            {
              color: '#DA1414',
              fontSize: 12,
              paddingLeft: 16,
            },
          ]}
        >
          {errors}
        </Text>
      )}
    </View>
  );
};

export { DateTime };
