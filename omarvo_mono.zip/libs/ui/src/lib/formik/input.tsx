import React, { useState, useEffect } from 'react';
import {
  Platform,
  Text,
  TextInputIOSProps,
  TextInput,
  View,
  Pressable,
} from 'react-native';
import { TextInputProps } from 'react-native';
import { EyeClose, EyeOpen } from '../svg';
import { globalStyles } from '@omarvo/utils';

interface Props {
  label: string;
  name: string;
  value?: string;
  placeholder: string;
  type: TextInputIOSProps['textContentType'];
  mode?: TextInputProps['inputMode'];
  handleChange: any;
  errors: any;
  touched: any;
  handleBlur?: any;
  disabled?: boolean;
  secureTextEntry?: boolean;
  autoCapitalize?: 'characters' | 'words' | 'sentences' | 'none';
  extraLogic?: (e: any) => void;
  leadingAccessory?: React.ReactElement;
  bgColor?: string;
  paddingLeft?: number;
}

const Input: React.FC<Props> = ({
  label,
  name,
  placeholder,
  type,
  value = '',
  handleChange,
  handleBlur,
  disabled = false,
  errors,
  touched,
  autoCapitalize = 'none',
  secureTextEntry = false,
  mode = 'text',
  extraLogic,
  leadingAccessory,
  bgColor = '#fff',
  paddingLeft = 74,
}) => {
  const [shouldHide, setSecureTextEntry] = useState<boolean>(secureTextEntry);

  useEffect(() => {
    setSecureTextEntry(secureTextEntry);
  }, []);

  return (
    <View className="w-full flex space-y-2">
      <Text className="text-sm text-[#6E7A8B]" style={globalStyles.medium}>
        {label}
      </Text>
      <View className="w-full relative">
        <TextInput
          placeholder={placeholder}
          className="focus:border-primaryOne/60"
          style={[
            globalStyles.regular,
            {
              borderWidth: 1,
              borderColor: '#DADEE3',
              paddingVertical: Platform.OS === 'ios' ? 17 : 12,
              paddingHorizontal: 12,
              paddingLeft: leadingAccessory ? paddingLeft : 12,
              fontSize: 14,
              borderRadius: 8,
              color: disabled ? 'rgba(43, 43, 43, 0.8)' : '#1B222D',
              backgroundColor: disabled ? '#DADEE3' : bgColor,
            },
          ]}
          onChangeText={(e) => {
            extraLogic?.(e);
            handleChange(name, e);
          }}
          onBlur={handleBlur(name)}
          value={value}
          autoCapitalize={autoCapitalize}
          textContentType={type}
          inputMode={mode}
          secureTextEntry={shouldHide}
          placeholderTextColor="#858C94"
          editable={!disabled}
        />

        {leadingAccessory && (
          <View className="absolute h-full top-0 bottom-0 left-3 flex flex-col justify-center">
            {leadingAccessory}
          </View>
        )}

        {type === 'password' && (
          <View className="absolute h-full top-0 bottom-0 right-3 flex flex-col justify-center">
            {shouldHide ? (
              <Pressable onPress={() => setSecureTextEntry(false)}>
                <EyeOpen />
              </Pressable>
            ) : (
              <Pressable onPress={() => setSecureTextEntry(true)}>
                <EyeClose />
              </Pressable>
            )}
          </View>
        )}
      </View>
      {errors && touched && (
        <Text
          className="capitalize"
          style={[
            globalStyles.regular,
            {
              color: '#DA1414',
              fontSize: 12,
            },
          ]}
        >
          {errors}
        </Text>
      )}
    </View>
  );
};

export { Input };
