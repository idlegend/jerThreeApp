import React, { useEffect, useState } from 'react';
import { Platform, Text, TextInput, View } from 'react-native';
import { Picker, PickerModes } from 'react-native-ui-lib';
import { ChevronDown, SearchStatus } from '../svg';
import { Category, globalStyles } from '@omarvo/utils';

interface Props {
  label: string;
  name: string;
  value: any;
  placeholder: string;
  handleChange: any;
  errors: any;
  touched: any;
  handleBlur?: any;
  disabled?: boolean;
  useWheel?: boolean;
  showSearch?: boolean;
  items: {
    label: string;
    value: string | number;
  }[];
  setValue?: any;
  showLeadingAccessory?: boolean;
  useDialog?: boolean;
  extraLogic?: (e: any) => void;
  mode?: 'MULTI' | 'SINGLE';
  renderCustomSearch?: boolean;
  setMainList?: React.Dispatch<React.SetStateAction<Category[]>>;
}

const Select: React.FC<Props> = ({
  label,
  name,
  placeholder,
  value,
  handleChange,
  handleBlur,
  disabled,
  errors,
  touched,
  items,
  showSearch = true,
  useWheel = false,
  setValue,
  extraLogic,
  mode = 'SINGLE',
  showLeadingAccessory = true,
  useDialog = true,
  renderCustomSearch,
  setMainList,
}) => {
  const [category, setCategory] = useState('');
  const [list, setList] = useState<
    {
      label: string;
      value: string | number;
    }[]
  >(items);

  useEffect(() => {
    setList(items);
  }, [items]);

  return (
    <View className="w-full flex space-y-2">
      <Picker
        label={label}
        value={value}
        showSearch={showSearch}
        placeholder={placeholder}
        onChange={(e) => {
          extraLogic?.(e);
          handleChange(name, e);
          setValue && setValue(e);
        }}
        useDialog={useDialog}
        useSafeArea
        mode={PickerModes[mode]}
        className="focus:border-primaryOne/60"
        onBlur={handleBlur(name)}
        useWheelPicker={useWheel}
        fieldStyle={{
          borderWidth: 1,
          borderColor: '#DADEE3',
          paddingVertical: Platform.OS === 'ios' ? 17 : 12,
          paddingHorizontal: 12,
          borderRadius: 8,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#fff',
        }}
        {...(renderCustomSearch
          ? {
              renderCustomSearch: () => (
                <View className="px-5">
                  <TextInput
                    placeholder="Search, or type and hit enter to add new"
                    className="bg-[#FBFCFD] placeholder:text-base px-3 rounded"
                    style={{
                      height: 48,
                      fontSize: 16,
                    }}
                    textAlign="left"
                    textAlignVertical="center"
                    value={category}
                    enterKeyHint="enter"
                    onChangeText={(value) => {
                      setList(
                        (prev) =>
                          (prev = items.filter((item) =>
                            item.label
                              .toLowerCase()
                              .includes(value.toLowerCase())
                          ))
                      );
                      setCategory(value);
                    }}
                    placeholderTextColor="#6E7A8B"
                    onSubmitEditing={(e) => {
                      if (!category || !category.trim()) {
                        return;
                      }
                      const existing = list.find(
                        (i) => i.label.toLowerCase() === category.toLowerCase()
                      );

                      if (existing) {
                        return;
                      }

                      setMainList?.(
                        (prev) =>
                          (prev = [
                            { name: category.trim(), id: category.trim() },
                            ...items.map((i) => ({
                              name: i.label,
                              id: i.value.toString(),
                            })),
                          ])
                      );

                      handleChange(name, mode === 'MULTI' ? [] : '');

                      setCategory('');
                    }}
                  />
                </View>
              ),
            }
          : {})}
        style={[
          globalStyles.regular,
          {
            fontSize: 14,
            color: '#1B222D',
            textTransform: 'capitalize',
          },
        ]}
        labelStyle={[
          globalStyles.medium,
          {
            fontSize: 14,
            color: '#6E7A8B',
          },
        ]}
        containerStyle={{
          flexDirection: 'column',
          rowGap: 8,
          height: Platform.OS === 'ios' ? 84 : 82,
        }}
        items={list}
        onSearchChange={(value) =>
          setList(
            (prev) =>
              (prev = items.filter((item) =>
                item.label.toLowerCase().includes(value.toLowerCase())
              ))
          )
        }
        leadingAccessory={
          showLeadingAccessory ? (
            <View className="pr-3">
              <SearchStatus />
            </View>
          ) : (
            <></>
          )
        }
        trailingAccessory={<ChevronDown />}
        placeholderTextColor="#858C94"
        searchStyle={{
          placeholderTextColor: '#858C94',
        }}
        editable={!disabled}
      />

      {errors && touched && (
        <Text
          style={[
            globalStyles.regular,
            {
              color: '#DA1414',
              fontSize: 12,
            },
          ]}
        >
          {errors}
        </Text>
      )}
    </View>
  );
};

export { Select };
