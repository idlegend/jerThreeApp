import { globalStyles } from '@omarvo/utils';
import React from 'react';
import { Text, View } from 'react-native';
import { RadioButton, RadioGroup } from 'react-native-ui-lib';

interface Props {
  label: string;
  name: string;
  value: any;
  handleChange: any;
  errors: any;
  touched: any;
  handleBlur?: any;
  disabled?: boolean;
  extraLogic?: (e: any) => void;
  buttons: { value: any; label: any }[];
}

const RadioGroupComp: React.FC<Props> = ({
  label,
  name,
  value,
  handleChange,
  handleBlur,
  disabled = false,
  errors,
  touched,
  buttons,
}) => {
  return (
    <View className="w-full flex space-y-3">
      <Text className="text-sm text-[#6E7A8B]" style={globalStyles.medium}>
        {label}
      </Text>
      <View className="w-full relative">
        <RadioGroup
          initialValue={value}
          onValueChange={(e: any) => handleChange(name, e)}
          className="flex-row space-x-8 items-center"
        >
          {buttons.map(({ label, value }, i) => (
            <RadioButton
              key={i}
              color="#00A082"
              size={22}
              value={value}
              labelStyle={{
                fontSize: 14,
                color: '#1B222D',
                ...globalStyles.regular,
              }}
              label={label}
            />
          ))}
        </RadioGroup>
      </View>
    </View>
  );
};

export { RadioGroupComp };
