import React, { useState } from 'react';
import {
  Platform,
  Pressable,
  Text,
  TextInput,
  TextInputIOSProps,
  View,
} from 'react-native';
import { TextInputProps } from 'react-native';
import { globalStyles } from '@omarvo/utils';
import { Iconify } from 'react-native-iconify';

interface Props {
  label: string;
  name: string;
  values: string[];
  placeholder: string;
  type: TextInputIOSProps['textContentType'];
  mode?: TextInputProps['inputMode'];
  handleChange: any;
  errors: any;
  touched: any;
  handleBlur?: any;
  disabled?: boolean;
  autoCapitalize?: 'characters' | 'words' | 'sentences' | 'none';
}

const TagsInput: React.FC<Props> = ({
  label,
  name,
  placeholder,
  type,
  values,
  handleChange,
  handleBlur,
  disabled,
  errors,
  touched,
  autoCapitalize = 'none',
  mode = 'text',
}) => {
  const [text, setText] = useState('');
  return (
    <View className="w-full  flex space-y-2">
      <Text className="text-sm text-[#6E7A8B]" style={globalStyles.medium}>
        {label}
      </Text>
      <View className="w-full relative">
        <TextInput
          placeholder={placeholder}
          className="focus:border-primaryOne/60"
          style={[
            globalStyles.regular,
            {
              borderWidth: 1,
              borderColor: '#DADEE3',
              paddingVertical: Platform.OS === 'ios' ? 17 : 12,
              paddingHorizontal: 12,
              paddingLeft: 12,
              fontSize: 16,
              borderRadius: 8,
              color: disabled ? 'rgba(43, 43, 43, 0.8)' : '#1B222D',
              backgroundColor: disabled ? '#DADEE3' : '#fff',
            },
          ]}
          onChangeText={(e) => setText(e)}
          value={text}
          onSubmitEditing={(e) => {
            const updatedValues = new Set([
              ...values,
              e.nativeEvent.text.trim(),
            ]);
            setText('');
            handleChange(name, [...updatedValues]);
            e.preventDefault();
          }}
          onBlur={handleBlur(name)}
          autoCapitalize={autoCapitalize}
          textContentType={type}
          inputMode={mode}
          placeholderTextColor="#858C94"
        />
      </View>
      <View
        className="flex flex-row flex-wrap"
        style={{
          columnGap: 8,
          rowGap: 8,
        }}
      >
        {values.map((value, index) => (
          <View
            key={index}
            style={[
              {
                backgroundColor: '#A5ABB3',
                paddingVertical: 4,
                paddingLeft: 12,
                paddingRight: 10,
                borderRadius: 9999,
                flexDirection: 'row',
                columnGap: 8,
                justifyContent: 'space-between',
              },
            ]}
          >
            <Text
              style={[globalStyles.medium, { color: 'white', fontSize: 15 }]}
            >
              {value}
            </Text>
            <Pressable
              onPress={() => {
                const updatedValues = values.filter((item) => item !== value);
                handleChange(name, updatedValues);
              }}
            >
              <Iconify icon="prime:times" size={18} color="white" />
            </Pressable>
          </View>
        ))}
      </View>
      {errors && touched && (
        <Text
          style={[
            globalStyles.regular,
            {
              color: '#DA1414',
              fontSize: 12,
            },
          ]}
        >
          {errors}
        </Text>
      )}
    </View>
  );
};

export { TagsInput };
