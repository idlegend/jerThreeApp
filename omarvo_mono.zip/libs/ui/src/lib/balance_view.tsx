import { View, Text } from 'react-native';
import React from 'react';
import { globalStyles } from '@omarvo/utils';
import { useHideBalance } from '@omarvo/hooks';
import { Iconify } from 'react-native-iconify';

const BalanceView: React.FC<{ value: number; hideBalance: boolean }> = ({
  value,
  hideBalance,
}) => {
  return (
    <View className="flex-row space-x-0 min-h-[30px] ">
      {hideBalance ? (
        <>
          <Iconify icon="material-symbols:asterisk" size={16} />
          <Iconify icon="material-symbols:asterisk" size={16} />
          <Iconify icon="material-symbols:asterisk" size={16} />
          <Iconify icon="material-symbols:asterisk" size={16} />
        </>
      ) : (
        <Text className="text-xl text-mainBlack " style={[globalStyles.bold]}>
          ₦ {value.toLocaleString()}
        </Text>
      )}
    </View>
  );
};

export { BalanceView };
