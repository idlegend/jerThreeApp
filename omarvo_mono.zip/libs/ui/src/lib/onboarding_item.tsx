import { View, useWindowDimensions, Image } from 'react-native';
import React from 'react';

interface Props {
  item: {
    id: string;
    title: string;
    description: string;
    image: React.JSX.Element;
  };
}

const OnboardingItem: React.FC<Props> = ({ item }) => {
  const { width } = useWindowDimensions();

  return (
    <View className="items-center" style={{ width, flex: 1 }}>
      <View className="flex-1">
        <View className="flex-[0.7] items-center justify-center ">
          {item.image}
        </View>
      </View>
    </View>
  );
};

export { OnboardingItem };
