import { View, Text } from 'react-native';
import React from 'react';
import { Button } from './button';
import { globalStyles } from '@omarvo/utils';

interface Props {
  svg: React.ReactNode;
  text: string;
  buttonText?: string;
  action?: () => void;
  showButton?: boolean;
}

const Empty = ({
  svg,
  buttonText = 'Go Back',
  text,
  action = () => {},
  showButton = true,
}: Props) => {
  return (
    <View className="flex-1 justify-center items-center px-5 space-y-10">
      {svg}
      <View className="w-full items-center" style={{ rowGap: 64 }}>
        <Text
          className="text-base text-mainBlack max-w-[280px] text-center "
          style={[globalStyles.regular]}
        >
          {text}
        </Text>
        {showButton && <Button text={buttonText} action={action} />}
      </View>
    </View>
  );
};

export { Empty };
