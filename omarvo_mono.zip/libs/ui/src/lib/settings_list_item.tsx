import { View, Text, Pressable, StyleProp, ViewStyle } from 'react-native';
import React from 'react';
import { Iconify } from 'react-native-iconify';
import { Switch } from 'react-native-ui-lib';
import { truncate } from 'lodash';
import { globalStyles } from '@omarvo/utils';

type Props = {
  title: string;
  desc: string;
  icon: React.JSX.Element;
  action: () => void;
  showDesc?: boolean;
  isToggle?: boolean;
  toggleValue?: boolean;
  handleToggle?: (value: boolean) => void;
  styles?: StyleProp<ViewStyle>;
  iconStyles?: StyleProp<ViewStyle>;
};

const SettingsListItem: React.FC<Props> = ({
  title,
  desc,
  icon,
  action,
  showDesc = true,
  isToggle = false,
  toggleValue,
  handleToggle,
  styles,
  iconStyles,
}) => {
  return (
    <Pressable
      onPress={action}
      className="px-4 py-[14px] w-full flex flex-row space-x-5 items-center border-b-[0.5px] border-[#E6E6E6]  "
      style={[styles]}
    >
      <View
        className="w-9 h-9 bg-primary-100/70 rounded-full flex justify-center items-center"
        style={[iconStyles]}
      >
        {icon}
      </View>
      <View className="flex w-[86%] flex-row items-center justify-between">
        <View className="space-y-[2px]">
          <Text
            className="text-base text-mainBlack/80 "
            style={[globalStyles.medium]}
          >
            {title}
          </Text>
          {showDesc && (
            <Text
              className="text-sm text-primaryThree "
              style={[globalStyles.regular]}
            >
              {truncate(desc, { length: 40 })}
            </Text>
          )}
        </View>
        {isToggle ? (
          <Switch
            value={toggleValue}
            onValueChange={handleToggle}
            onColor="#00A082"
            offColor="#6E7A8B"
            style={{ marginRight: 4 }}
          />
        ) : (
          <Iconify icon="charm:chevron-right" size={24} color="#6E7A8B" />
        )}
      </View>
    </Pressable>
  );
};

export { SettingsListItem };
