import { View, Text } from 'react-native';
import React from 'react';
import { globalStyles } from '@omarvo/utils';
import { SvgProps } from 'react-native-svg';

interface Props {
  showCountry?: boolean;
  title: string;
  subText: string;
  Svg: React.FC<SvgProps>;
}

export const RegisterHeader: React.FC<Props> = ({
  title,
  subText,
  showCountry = true,
  Svg,
}) => {
  return (
    <View className="items-center space-y-6">
      {showCountry && (
        <View className="w-[174px] py-1 rounded bg-secondaryThree items-center ">
          <Text
            className="text-primaryOne text-base"
            style={[globalStyles.regular]}
          >
            Nigeria
          </Text>
        </View>
      )}

      <View className="items-center space-y-2 ">
        <Svg />
        <View className="items-center space-y-1">
          <Text
            className="text-mainBlack text-lg"
            style={[globalStyles.medium]}
          >
            {title}
          </Text>
          <Text
            className="text-mainBlack text-base "
            style={[globalStyles.regular]}
          >
            {subText}
          </Text>
        </View>
      </View>
    </View>
  );
};
