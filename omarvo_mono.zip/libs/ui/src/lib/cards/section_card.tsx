import { View, Text, Dimensions, Pressable } from 'react-native';
import React from 'react';
import { globalStyles } from '@omarvo/utils';

interface Props {
  icon: React.JSX.Element;
  name: string;
  description: string;
  primaryColor: string;
  secondaryColor: string;
  handlePress?: () => void;
}

const SectionCard: React.FC<Props> = ({
  description,
  icon,
  name,
  primaryColor,
  secondaryColor,
  handlePress,
}) => {
  const calc = Dimensions.get('screen').width - 56;
  const width = calc / 2;
  return (
    <Pressable
      className="py-[13px] px-4 rounded-lg space-y-2"
      style={{ width, backgroundColor: primaryColor }}
      onPress={handlePress}
    >
      <View
        className="w-7 h-7 rounded justify-center items-center "
        style={{ backgroundColor: secondaryColor }}
      >
        {icon}
      </View>
      <View className="space-y-1">
        <Text className="text-mainBlack text-sm" style={[globalStyles.medium]}>
          {name}
        </Text>
        <Text className="text-black text-xs " style={[globalStyles.regular]}>
          {description}
        </Text>
      </View>
    </Pressable>
  );
};

export { SectionCard };
