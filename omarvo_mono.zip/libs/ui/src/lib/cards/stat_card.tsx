import { globalStyles } from '@omarvo/utils';
import { View, Text } from 'react-native';

const StatCard = ({ value, desc }: { value: string; desc: string }) => {
  return (
    <View className="flex-1 px-[14px] space-y-3 py-3 bg-secondary-50 rounded-lg ">
      <Text
        className="text-2xl text-secondary-700 "
        style={[globalStyles.bold]}
      >
        {value}
      </Text>
      <Text className="text-mainBlack text-xs" style={[globalStyles.regular]}>
        {desc}
      </Text>
    </View>
  );
};

export { StatCard };
