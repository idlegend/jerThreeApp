import { Restaurant, globalStyles } from '@omarvo/utils';
import { Pressable, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { Iconify } from 'react-native-iconify';

interface Props extends Restaurant {
  action: () => void;
}

export const EnBusinessCard = ({
  media,
  name,
  action,
  school_address: { base },
}: Props) => {
  return (
    <Pressable
      onPress={action}
      className="flex-row w-full items-center justify-between "
    >
      <View className="w-full max-w-[90%] flex-row space-x-4 items-center ">
        <Image
          source={media?.url}
          placeholder={media?.blur_hash}
          style={{
            width: 90,
            height: 75,
            borderTopLeftRadius: 4,
            borderBottomLeftRadius: 4,
          }}
          contentFit="cover"
        />
        <View className="space-y-2">
          <Text
            className="text-mainBlack text-base "
            style={[globalStyles.bold]}
          >
            {name}
          </Text>
          <Text
            className="text-mainBlack text-sm "
            style={[globalStyles.regular]}
          >
            {base}
          </Text>
        </View>
      </View>
      <View>
        <Iconify icon="lucide:chevron-right" size={24} color="#222B38" />
      </View>
    </Pressable>
  );
};
