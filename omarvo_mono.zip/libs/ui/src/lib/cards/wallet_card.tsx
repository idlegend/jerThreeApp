import { View, Text, Pressable } from 'react-native';
import { Iconify } from 'react-native-iconify';
import { globalStyles } from '@omarvo/utils';
import { ImageBackground } from 'expo-image';
import { useHideBalance } from '@omarvo/hooks';
import { BalanceView } from '../balance_view';

const WalletCard = ({ image }: { image: any }) => {
  const { hideBalance, toggleHideBalnce } = useHideBalance();

  return (
    <View className=" bg-secondaryFour overflow-hidden  rounded-[10px]   ">
      <ImageBackground
        className="flex-row p-4 justify-between items-start "
        source={image}
        contentFit="cover"
      >
        <View className="space-y-8">
          <View style={{ rowGap: 8 }}>
            <Text
              className="text-sm text-mainBlack "
              style={[globalStyles.regular]}
            >
              Available Balance
            </Text>
            <BalanceView hideBalance={hideBalance} value={544568.23} />
          </View>
          <View style={{ rowGap: 8 }}>
            <Text
              className="text-sm text-mainBlack "
              style={[globalStyles.regular]}
            >
              Locked Balance
            </Text>
            <BalanceView hideBalance={hideBalance} value={544568.23} />
          </View>
        </View>
        <View className="items-center space-y-1 ">
          <Pressable onPress={toggleHideBalnce}>
            {hideBalance ? (
              <Iconify icon="ri:eye-line" size={24} />
            ) : (
              <Iconify icon="ri:eye-off-line" size={24} />
            )}
          </Pressable>

          <Text
            className="text-xs text-mainBlack "
            style={[globalStyles.medium]}
          >
            {hideBalance ? 'Show' : 'Hide'}
          </Text>
        </View>
      </ImageBackground>
    </View>
  );
};

export { WalletCard };
