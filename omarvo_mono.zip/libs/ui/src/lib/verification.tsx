import { View, Text, ActivityIndicator, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SvgProps } from 'react-native-svg';
import { globalStyles } from '@omarvo/utils';
import { CodeFieldComp } from './codefield';
import { Button } from './button';

interface Props {
  email: string;
  value: string;
  setValue: React.Dispatch<React.SetStateAction<string>>;
  handleVerify: () => Promise<void> | any;
  handleResendOTP: () => Promise<void>;
  Svg: React.FC<SvgProps>;
  title?: string;
  buttonText?: string;
  loading: boolean;
  resending: boolean;
  showResend?: boolean;
  initSec?: number;
}

const Verification: React.FC<Props> = ({
  email,
  value,
  setValue,
  loading,
  handleVerify,
  handleResendOTP,
  resending,
  Svg,
  showResend = true,
  initSec = 0,
  title = 'Email Verification',
  buttonText = 'Verify Account',
}) => {
  const { top, bottom } = useSafeAreaInsets();

  const [remainingTime, setRemainingTime] = useState(initSec);

  useEffect(() => {
    if (!initSec) {
      return;
    }
    if (remainingTime <= 0) {
      return; // Countdown finished
    }
    const timerInterval = setInterval(() => {
      setRemainingTime((prevTime) => prevTime - 1);
    }, 1000);

    return () => {
      clearInterval(timerInterval);
    };
  }, [initSec, remainingTime]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  return (
    <View
      className="flex-1 bg-white"
      style={{
        paddingTop: top,
        paddingBottom: bottom,
      }}
    >
      <ScrollView className="bg-white  flex-1">
        <View className="px-5 py-4 space-y-14">
          <View className="flex flex-col space-y-6 items-center">
            <Svg />
            <View className="w-full flex flex-col items-center space-y-2 max-w-[298px] ">
              <Text
                className="text-2xl text-center"
                style={[globalStyles.medium]}
              >
                {title}
              </Text>
              <Text
                className="text-center text-base "
                style={[globalStyles.regular]}
              >
                Please type the verification code sent to {email}
              </Text>
            </View>
          </View>
          <View
            style={{
              flexDirection: 'column',
              rowGap: 40,
            }}
          >
            <CodeFieldComp value={value} setValue={setValue} cell_count={6} />
            <Button
              text={buttonText}
              action={handleVerify}
              loading={loading}
              disabled={value?.length < 6}
            />
            <View className="items-center space-y-1">
              {showResend && (
                <View className="w-full flex-row items-center space-x-1 justify-center ">
                  <Text style={[globalStyles.regular, { fontSize: 16 }]}>
                    Didn't received email?{' '}
                  </Text>
                  <Pressable
                    onPress={() => handleResendOTP()}
                    disabled={remainingTime > 0}
                  >
                    <Text
                      className={`${
                        remainingTime > 0
                          ? 'text-secondaryOne'
                          : 'text-primaryOne'
                      }`}
                      style={[globalStyles.medium, { fontSize: 16 }]}
                    >
                      Resend
                    </Text>
                  </Pressable>
                  {resending && (
                    <ActivityIndicator size="small" color="#8863F2" />
                  )}
                </View>
              )}
              {initSec && (
                <Text
                  className="text-base text-mainBlack/70 "
                  style={[globalStyles.medium]}
                >
                  {formatTime(remainingTime)}
                </Text>
              )}
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export { Verification };
