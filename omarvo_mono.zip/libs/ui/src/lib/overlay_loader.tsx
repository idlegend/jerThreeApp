import { View, ActivityIndicator } from 'react-native';
import React from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const OverlayLoader = () => {
  const { top } = useSafeAreaInsets();

  return (
    <View className="absolute top-0 left-0 bottom-0 right-0 flex-1 bg-mainBlack/5 justify-center items-center">
      <ActivityIndicator
        size="large"
        color="#00A082"
        style={{ paddingBottom: top }}
      />
    </View>
  );
};

export { OverlayLoader };
