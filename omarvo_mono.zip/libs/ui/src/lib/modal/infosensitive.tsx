import { View, Text, Image, Pressable } from 'react-native';
import React from 'react';
import Modal from 'react-native-modal';
import { globalStyles } from '@omarvo/utils';
import { Button } from '../button';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Iconify } from 'react-native-iconify';

type Props = {
  modalVisible: boolean;
  closeModal: () => void;
  action: () => void;
  loading: boolean;
  question: string;
  buttonText: string;
  title: string;
  image: React.JSX.Element;
};

const InfoSensitiveModal: React.FC<Props> = ({
  modalVisible,
  closeModal,
  action,
  loading,
  question,
  buttonText,
  title,
  image,
}) => {
  const { bottom } = useSafeAreaInsets();

  return (
    <Modal
      isVisible={modalVisible}
      backdropColor="#000000"
      backdropOpacity={0.6}
      className="m-0 justify-end"
      onBackdropPress={closeModal}
    >
      <View
        className="bg-white rounded-t-[36px] relative py-6 px-5 "
        style={{ paddingBottom: bottom + 24, rowGap: 29 }}
      >
        <View
          className="w-full items-center justify-center"
          style={{
            rowGap: 22,
          }}
        >
          {image}
          <View className="space-y-2">
            <Text
              className="text-lg text-center text-primaryOne"
              style={[globalStyles.bold]}
            >
              {title}
            </Text>
            <Text
              className="text-base text-center max-w-[272px] text-mainBlack"
              style={[globalStyles.regular]}
            >
              {question}
            </Text>
          </View>
        </View>
        <Button
          action={action}
          text={buttonText}
          styles={{ backgroundColor: '#BE4646' }}
          loading={loading}
        />
        <Pressable
          onPress={closeModal}
          className="absolute top-[22px] right-[22px]"
        >
          <Iconify icon="tabler:x" size={20} color="#6E7A8B" />
        </Pressable>
      </View>
    </Modal>
  );
};

export { InfoSensitiveModal };
