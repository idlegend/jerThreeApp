import { View, Modal, ScrollView, Platform } from 'react-native';
import React from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

type Props = {
  modalVisible: boolean;
  children: React.ReactNode;
};

const FullScreenModal: React.FC<Props> = ({ modalVisible, children }) => {
  const { bottom, top } = useSafeAreaInsets();

  return (
    <Modal visible={modalVisible} animationType="slide">
      <View
        className="flex-1 bg-white"
        style={{
          paddingBottom: bottom,
          paddingTop: Platform.OS === 'ios' ? top : 20,
        }}
      >
        {/* Body */}
        {children}
      </View>
    </Modal>
  );
};

export { FullScreenModal };
