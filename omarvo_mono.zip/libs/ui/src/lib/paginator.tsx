import {
  View,
  Animated,
  useWindowDimensions,
  StyleProp,
  ViewStyle,
} from 'react-native';
import React from 'react';

interface Props {
  data: any[];
  scrollX: Animated.Value;
  backgroundColor?: string;
  faintColor?: string;
  range: number[];
  height?: number;
  currentIndex: number;
  style?: StyleProp<ViewStyle>;
  itemStyle?: StyleProp<ViewStyle>;
}

const Paginator: React.FC<Props> = ({
  data,
  scrollX,
  backgroundColor = '#FFFFFF',
  faintColor = '#E3D8C1',
  height = 4,
  currentIndex,
  style,
  itemStyle,
  range,
}) => {
  const { width } = useWindowDimensions();

  return (
    <View
      className="flex w-full flex-row space-x-2 h-auto justify-between px-5 "
      style={style}
    >
      {data.map((_, i) => {
        const inputRange = [(i - 1) * width, i * width, (i + 1) * width];

        const dothWidth = scrollX.interpolate({
          inputRange,
          outputRange: range,
          extrapolate: 'clamp',
        });

        return (
          <Animated.View
            className=" rounded-[5px] "
            style={[
              {
                width: dothWidth,
                backgroundColor:
                  i === currentIndex ? backgroundColor : faintColor,
                height,
              },
              itemStyle,
            ]}
            key={i.toString()}
          />
        );
      })}
    </View>
  );
};

export { Paginator };
