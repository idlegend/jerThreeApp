import { combineReducers, configureStore } from '@reduxjs/toolkit';
import locationReducer from './slices/app/location';
import cssReducer from './slices/app/css';
import categoriesReducer from './slices/app/categories';
import registerReducer from './slices/user/register';
import signinReducer from './slices/user/signin';
import profileReducer from './slices/user/profile';
import restaurantReducer from './slices/user/restaurant';
import victualsReducer from './slices/user/victuals';
import storeReducer from './slices/user/store';
import productsReducer from './slices/user/products';
import forgotPasswordReducer from './slices/user/forgot_password';
import entrepreneurRegisterReducer from './slices/entrepreneur/register';
import entrepreneurSigninReducer from './slices/entrepreneur/signin';
import entrepreneurProfileReducer from './slices/entrepreneur/profile';
import entrepreneurForgotPasswordReducer from './slices/entrepreneur/forgot_password';
import entrepreneurRestaurantReducer from './slices/entrepreneur/restaurant';
import entrepreneurVictualsReducer from './slices/entrepreneur/victuals';
import entrepreneurStoreReducer from './slices/entrepreneur/store';
import entrepreneurProductsReducer from './slices/entrepreneur/products';

const rootReducer = combineReducers({
  location: locationReducer,
  css: cssReducer,
  categories: categoriesReducer,
  register: registerReducer,
  signin: signinReducer,
  profile: profileReducer,
  restaurant: restaurantReducer,
  victuals: victualsReducer,
  store: storeReducer,
  products: productsReducer,
  forgotPassword: forgotPasswordReducer,
  entrepreneurRegister: entrepreneurRegisterReducer,
  entrepreneurSignin: entrepreneurSigninReducer,
  entrepreneurForgotPassword: entrepreneurForgotPasswordReducer,
  entrepreneurProfile: entrepreneurProfileReducer,
  entrepreneurRestaurant: entrepreneurRestaurantReducer,
  entrepreneurVictuals: entrepreneurVictualsReducer,
  entrepreneurStore: entrepreneurStoreReducer,
  entrepreneurProducts: entrepreneurProductsReducer,
});

// Define store with redux persist to persist data in local storage
export const store = configureStore({
  reducer: rootReducer,
});

// `AppDispatch` types from the store itself
export type AppStore = typeof store;
export type RootState = ReturnType<AppStore['getState']>;
export type AppDispatch = typeof store.dispatch;
