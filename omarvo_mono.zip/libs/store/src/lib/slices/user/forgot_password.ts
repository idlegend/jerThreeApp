import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

export type error = {
  errors: {}[];
};

// Define a type for the slice state
export interface forgotPasswordState {
  loading: boolean;
  email: string;
  token: string;
  data: object;
  error: any;
}

export const postResetPassword = createAsyncThunk(
  'forgotPassword/postResetPassword',
  async (
    body: { reset_token: string; password: string },
    { rejectWithValue }
  ) => {
    try {
      const { data }: any = await axios.post(
        `/api/user/auth/reset-password`,
        body
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const postVerifyEmail = createAsyncThunk(
  `forgotPassword/postVerifyEmail`,
  async (body: { email: string; otp: string }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.post(
        `/api/user/auth/forgot-password`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const postForgotEmail = createAsyncThunk(
  'forgotPassword/postForgotEmail',
  async (body: { email: string }, { rejectWithValue }) => {
    try {
      const { data } = await axios.post(`/api/user/auth/send-otp`, body, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: forgotPasswordState = {
  loading: false,
  token: '',
  email: '',
  data: {},
  error: null,
};

export const forgotPasswordSlice = createSlice({
  name: 'forgotPassword',
  initialState,
  reducers: {
    resetForgotPasswordState: (state) => {
      return (state = initialState);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(postForgotEmail.pending, (state) => {
        state.loading = true;
      })
      .addCase(postForgotEmail.fulfilled, (state, { payload }) => {
        state.email = payload;
        state.loading = false;
      })
      .addCase(postForgotEmail.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(postVerifyEmail.pending, (state) => {
        state.loading = true;
      })
      .addCase(postVerifyEmail.fulfilled, (state, { payload }) => {
        state.token = payload;
        state.loading = false;
      })
      .addCase(postVerifyEmail.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
  },
});

export const { resetForgotPasswordState } = forgotPasswordSlice.actions;

export default forgotPasswordSlice.reducer;
