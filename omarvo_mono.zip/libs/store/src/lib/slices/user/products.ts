import { Pagination, Product, getSecureValueFor } from '@omarvo/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface productsState {
  loading: boolean;
  dataLoading: boolean;
  list: Record<string, Product[]>;
  trending: Pagination & { data: Product[] };
  data: Product | null;
  error: any;
}

export const getProducts = createAsyncThunk(
  `products/getProducts`,
  async (
    { signal, store_id }: { signal?: AbortSignal; store_id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(
        `/api/user/stores/${store_id}/products`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const getTrendingProducts = createAsyncThunk(
  `products/getTrendingProducts`,
  async ({ signal }: { signal?: AbortSignal }, { rejectWithValue }) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(`/api/user/stores/products`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const getProduct = createAsyncThunk(
  `products/getProduct`,
  async (
    {
      signal,
      store_id,
      id,
    }: { signal?: AbortSignal; store_id: string; id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(
        `/api/user/stores/${store_id}/products/${id}`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: productsState = {
  loading: true,
  dataLoading: true,
  trending: { data: [], items_per_page: 0, page: 1, total: 0 },
  list: {},
  data: null,
  error: null,
};

export const productsSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    resetProduct: (state) => {
      return (state = initialState);
    },
    resetProductDetails: (state) => {
      return (state = {
        ...state,
        data: null,
      });
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getProducts.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(getProducts.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.list = payload;
      }),
      builder.addCase(getProducts.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
    builder.addCase(getTrendingProducts.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(getTrendingProducts.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.trending = payload;
      }),
      builder.addCase(getTrendingProducts.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
    builder.addCase(getProduct.pending, (state) => {
      state.dataLoading = true;
    }),
      builder.addCase(getProduct.fulfilled, (state, { payload }) => {
        state.dataLoading = false;
        state.data = payload;
      }),
      builder.addCase(getProduct.rejected, (state, { payload }) => {
        state.dataLoading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetProduct, resetProductDetails } = productsSlice.actions;

export default productsSlice.reducer;
