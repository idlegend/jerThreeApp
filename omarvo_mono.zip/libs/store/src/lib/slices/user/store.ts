import { Category, Pagination, Store, getSecureValueFor } from '@omarvo/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface storesState {
  dataLoading: boolean;
  loading: boolean;
  list: Pagination & { data: Store[] };
  data: Store | null;
  categories: Category[];
  error: any;
}

export const getStores = createAsyncThunk(
  `stores/getStores`,
  async (
    { signal, params }: { signal?: AbortSignal; params?: Record<string, any> },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(`/api/user/stores`, {
        params: { page: 1, ...params },
        signal,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);
export const getStore = createAsyncThunk(
  `stores/getStore`,
  async (
    { signal, id }: { signal?: AbortSignal; id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(`/api/user/stores/${id}`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: storesState = {
  loading: true,
  dataLoading: true,
  list: { data: [], items_per_page: 0, page: 1, total: 0 },
  categories: [],
  data: null,
  error: null,
};

export const storesSlice = createSlice({
  name: 'stores',
  initialState,
  reducers: {
    resetStores: (state) => {
      return (state = initialState);
    },
    resetStoreDetails: (state) => {
      return (state = {
        ...state,
        data: null,
      });
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getStores.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(getStores.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.list = payload;
      }),
      builder.addCase(getStores.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
    builder.addCase(getStore.pending, (state) => {
      state.dataLoading = true;
    }),
      builder.addCase(getStore.fulfilled, (state, { payload }) => {
        state.dataLoading = false;
        state.data = payload;
      }),
      builder.addCase(getStore.rejected, (state, { payload }) => {
        state.dataLoading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetStores, resetStoreDetails } = storesSlice.actions;

export default storesSlice.reducer;
