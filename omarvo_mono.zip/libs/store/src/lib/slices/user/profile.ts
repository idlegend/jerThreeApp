import { User, getSecureValueFor } from '@omarvo/utils';
import { PayloadAction, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface profileState {
  loading: boolean;
  data: User | null;
  error: any;
}

export const getCurrentUserProfile = createAsyncThunk(
  `profile/getCurrentUserProfile`,
  async (_, { rejectWithValue }) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(`/api/user/profile`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: profileState = {
  loading: true,
  data: null,
  error: null,
};

export const profileSlice = createSlice({
  name: 'profile',
  initialState,
  reducers: {
    resetUser: (state) => {
      return (state = initialState);
    },
    updateUserProfile: (state, { payload }: PayloadAction<User>) => {
      state.data = payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getCurrentUserProfile.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(getCurrentUserProfile.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.data = payload;
      }),
      builder.addCase(getCurrentUserProfile.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetUser, updateUserProfile } = profileSlice.actions;

export default profileSlice.reducer;
