import { Victual, getSecureValueFor } from '@omarvo/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface victualsState {
  loading: boolean;
  dataLoading: boolean;
  list: Record<string, Victual[]>;
  data: Victual | null;
  error: any;
}

export const getVictuals = createAsyncThunk(
  `victuals/getVictuals`,
  async (
    { signal, restaurant_id }: { signal?: AbortSignal; restaurant_id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(
        `/api/user/restaurants/${restaurant_id}/victuals`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const getVictual = createAsyncThunk(
  `victuals/getVictual`,
  async (
    {
      signal,
      restaurant_id,
      id,
    }: { signal?: AbortSignal; restaurant_id: string; id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(
        `/api/user/restaurants/${restaurant_id}/victuals/${id}`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: victualsState = {
  loading: true,
  dataLoading: true,
  list: {},
  data: null,
  error: null,
};

export const victualsSlice = createSlice({
  name: 'victuals',
  initialState,
  reducers: {
    resetVictual: (state) => {
      return (state = initialState);
    },
    resetVictualDetails: (state) => {
      return (state = {
        ...state,
        data: null,
      });
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getVictuals.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(getVictuals.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.list = payload;
      }),
      builder.addCase(getVictuals.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
    builder.addCase(getVictual.pending, (state) => {
      state.dataLoading = true;
    }),
      builder.addCase(getVictual.fulfilled, (state, { payload }) => {
        state.dataLoading = false;
        state.data = payload;
      }),
      builder.addCase(getVictual.rejected, (state, { payload }) => {
        state.dataLoading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetVictual, resetVictualDetails } = victualsSlice.actions;

export default victualsSlice.reducer;
