import {
  Category,
  Pagination,
  Restaurant,
  getSecureValueFor,
} from '@omarvo/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface restaurantsState {
  dataLoading: boolean;
  loading: boolean;
  list: Pagination & { data: Restaurant[] };
  data: Restaurant | null;
  categories: Category[];
  error: any;
}

export const getRestaurants = createAsyncThunk(
  `restaurants/getRestaurants`,
  async (
    { signal, params }: { signal?: AbortSignal; params?: Record<string, any> },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(`/api/user/restaurants`, {
        params: { page: 1, ...params },
        signal,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);
export const getRestaurant = createAsyncThunk(
  `restaurants/getRestaurant`,
  async (
    { signal, id }: { signal?: AbortSignal; id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('userToken');
    try {
      const { data }: any = await axios.get(`/api/user/restaurants/${id}`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: restaurantsState = {
  loading: true,
  dataLoading: true,
  list: { data: [], items_per_page: 0, page: 1, total: 0 },
  categories: [],
  data: null,
  error: null,
};

export const restaurantsSlice = createSlice({
  name: 'restaurants',
  initialState,
  reducers: {
    resetRestaurants: (state) => {
      return (state = initialState);
    },
    resetRestaurantDetails: (state) => {
      return (state = {
        ...state,
        data: null,
      });
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getRestaurants.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(getRestaurants.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.list = payload;
      }),
      builder.addCase(getRestaurants.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
    builder.addCase(getRestaurant.pending, (state) => {
      state.dataLoading = true;
    }),
      builder.addCase(getRestaurant.fulfilled, (state, { payload }) => {
        state.dataLoading = false;
        state.data = payload;
      }),
      builder.addCase(getRestaurant.rejected, (state, { payload }) => {
        state.dataLoading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetRestaurants, resetRestaurantDetails } =
  restaurantsSlice.actions;

export default restaurantsSlice.reducer;
