import { Campus, School, State } from '@omarvo/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
export interface cssState {
  countries: any[];
  states: State[];
  schools: School[];
  campuses: Campus[];
  countriesLoading: boolean;
  statesLoading: boolean;
  schoolsLoading: boolean;
  campusesLoading: boolean;
  error: any;
}

// Define the initial state using that type
const initialState: cssState = {
  countries: [],
  states: [],
  schools: [],
  campuses: [],
  schoolsLoading: true,
  countriesLoading: true,
  campusesLoading: true,
  statesLoading: true,
  error: null,
};

export const getActiveCountries = createAsyncThunk(
  `css/getActiveCountries`,
  async ({ signal }: { signal: AbortSignal }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.get(`/api/app/countries`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const getCountryActiveStates = createAsyncThunk(
  `css/getCountryActiveStates`,
  async (
    { signal, country_id }: { signal: AbortSignal; country_id: string },
    { rejectWithValue }
  ) => {
    try {
      const { data }: any = await axios.get(
        `/api/app/countries/${country_id}/states`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const getCountryStateSchools = createAsyncThunk(
  `css/getCountryStateSchools`,
  async (
    {
      signal,
      country_id,
      state_id,
    }: { signal: AbortSignal; country_id: string; state_id: string },
    { rejectWithValue }
  ) => {
    try {
      const { data }: any = await axios.get(
        `/api/app/countries/${country_id}/states/${state_id}/schools`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const getSchoolCampuses = createAsyncThunk(
  `css/getSchoolCampuses`,
  async (
    { signal, school_id }: { signal: AbortSignal; school_id: string },
    { rejectWithValue }
  ) => {
    try {
      const { data }: any = await axios.get(
        `/api/app/schools/${school_id}/campuses`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const cssSlice = createSlice({
  name: 'css',
  initialState,
  reducers: {
    resetCssStates: (state) => {
      return (state = initialState);
    },
  },
  extraReducers: (builder) => {
    // countries
    builder.addCase(getActiveCountries.pending, (state) => {
      state.countriesLoading = true;
    }),
      builder.addCase(getActiveCountries.fulfilled, (state, { payload }) => {
        state.countriesLoading = false;
        state.countries = payload;
      }),
      builder.addCase(getActiveCountries.rejected, (state, { payload }) => {
        state.countriesLoading = false;
        state.error = payload;
      });
    //    states
    builder.addCase(getCountryActiveStates.pending, (state) => {
      state.statesLoading = true;
    }),
      builder.addCase(
        getCountryActiveStates.fulfilled,
        (state, { payload }) => {
          state.statesLoading = false;
          state.states = payload;
        }
      ),
      builder.addCase(getCountryActiveStates.rejected, (state, { payload }) => {
        state.statesLoading = false;
        state.error = payload;
      });
    //    schools
    builder.addCase(getCountryStateSchools.pending, (state) => {
      state.schoolsLoading = true;
    }),
      builder.addCase(
        getCountryStateSchools.fulfilled,
        (state, { payload }) => {
          state.schoolsLoading = false;
          state.schools = payload;
        }
      ),
      builder.addCase(getCountryStateSchools.rejected, (state, { payload }) => {
        state.schoolsLoading = false;
        state.error = payload;
      });
    //    campuses
    builder.addCase(getSchoolCampuses.pending, (state) => {
      state.campusesLoading = true;
    }),
      builder.addCase(getSchoolCampuses.fulfilled, (state, { payload }) => {
        state.campusesLoading = false;
        state.campuses = payload;
      }),
      builder.addCase(getSchoolCampuses.rejected, (state, { payload }) => {
        state.campusesLoading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetCssStates } = cssSlice.actions;

export default cssSlice.reducer;
