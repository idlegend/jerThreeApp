import { Campus, Category, School, State } from '@omarvo/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
export interface categoriesState {
  resloading: boolean;
  storeloading: boolean;
  prodloading: boolean;
  resCategories: Category[];
  storeCategories: Category[];
  prodCategories: Category[];
  vcloading: boolean;
  victualCategories: Category[];
  error: any;
}

// Define the initial state using that type
const initialState: categoriesState = {
  resCategories: [],
  storeCategories: [],
  victualCategories: [],
  prodCategories: [],
  resloading: true,
  storeloading: true,
  prodloading: true,
  vcloading: true,
  error: null,
};

export const getRestaurantCategories = createAsyncThunk(
  `categories/getRestaurantCategories`,
  async ({ signal }: { signal: AbortSignal }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.get(`/api/app/categories/0`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const getStoreCategories = createAsyncThunk(
  `categories/getStoreCategories`,
  async ({ signal }: { signal: AbortSignal }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.get(`/api/app/categories/1`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const getVictualCategories = createAsyncThunk(
  `categories/getVictualCategories`,
  async ({ signal }: { signal: AbortSignal }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.get(`/api/app/categories/victuals`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const getProductCategories = createAsyncThunk(
  `categories/getProductCategories`,
  async ({ signal }: { signal: AbortSignal }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.get(`/api/app/categories/products`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const categoriesSlice = createSlice({
  name: 'categories',
  initialState,
  reducers: {
    resetCategoriesState: (state) => {
      return (state = initialState);
    },
  },
  extraReducers: (builder) => {
    // restaurant categories
    builder.addCase(getRestaurantCategories.pending, (state) => {
      state.resloading = true;
    }),
      builder.addCase(
        getRestaurantCategories.fulfilled,
        (state, { payload }) => {
          state.resloading = false;
          state.resCategories = payload;
        }
      ),
      builder.addCase(
        getRestaurantCategories.rejected,
        (state, { payload }) => {
          state.resloading = false;
          state.error = payload;
        }
      );
    // product categories
    builder.addCase(getStoreCategories.pending, (state) => {
      state.storeloading = true;
    }),
      builder.addCase(getStoreCategories.fulfilled, (state, { payload }) => {
        state.storeloading = false;
        state.storeCategories = payload;
      }),
      builder.addCase(getStoreCategories.rejected, (state, { payload }) => {
        state.storeloading = false;
        state.error = payload;
      });
    // victual categories
    builder.addCase(getVictualCategories.pending, (state) => {
      state.vcloading = true;
    }),
      builder.addCase(getVictualCategories.fulfilled, (state, { payload }) => {
        state.vcloading = false;
        state.victualCategories = payload;
      }),
      builder.addCase(getVictualCategories.rejected, (state, { payload }) => {
        state.vcloading = false;
        state.error = payload;
      });
    // product categories
    builder.addCase(getProductCategories.pending, (state) => {
      state.prodloading = true;
    }),
      builder.addCase(getProductCategories.fulfilled, (state, { payload }) => {
        state.prodloading = false;
        state.prodCategories = payload;
      }),
      builder.addCase(getProductCategories.rejected, (state, { payload }) => {
        state.prodloading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetCategoriesState } = categoriesSlice.actions;

export default categoriesSlice.reducer;
