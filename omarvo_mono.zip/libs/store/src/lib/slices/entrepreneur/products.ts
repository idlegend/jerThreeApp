import { Product, getSecureValueFor } from '@omarvo/utils';
import { PayloadAction, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface entrepreneurProductState {
  loading: boolean;
  dataLoading: boolean;
  list: Record<string, Product[]>;
  data: Product | null;
  error: any;
}

export const getEntrepreneurProducts = createAsyncThunk(
  `entrepreneurProduct/getEntrepreneurProducts`,
  async (
    { signal, store_id }: { signal?: AbortSignal; store_id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.get(
        `/api/entrepreneur/stores/${store_id}/products`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const createProduct = createAsyncThunk(
  `entrepreneurProduct/createProduct`,
  async (
    { body, store_id }: { body: any; store_id: string },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/stores/${store_id}/products`,
        body,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      dispatch(getEntrepreneurProducts({ store_id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const getEntrepreneurProduct = createAsyncThunk(
  `entrepreneurProduct/getEntrepreneurProduct`,
  async (
    {
      signal,
      store_id,
      id,
    }: { signal?: AbortSignal; store_id: string; id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.get(
        `/api/entrepreneur/stores/${store_id}/products/${id}`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateEntrepreneurProduct = createAsyncThunk(
  `entrepreneurProduct/updateEntrepreneurProduct`,
  async (
    { store_id, id, body }: { store_id: string; id: string; body: any },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.patch(
        `/api/entrepreneur/stores/${store_id}/products/${id}`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurProduct({ id, store_id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateEntrepreneurProductStockCondition = createAsyncThunk(
  `entrepreneurProduct/updateEntrepreneurProductStockCondition`,
  async (
    {
      store_id,
      id,
      body,
    }: { store_id: string; id: string; body: { in_stock: boolean } },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.put(
        `/api/entrepreneur/stores/${store_id}/products/${id}`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      dispatch(updateEntrepreneurProductDetails(data.data));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const deleteEntrepreneurProduct = createAsyncThunk(
  `entrepreneurProduct/deleteEntrepreneurProduct`,
  async (
    { store_id, id }: { store_id: string; id: string },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.delete(
        `/api/entrepreneur/stores/${store_id}/products/${id}`,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurProducts({ store_id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Media
export const addToEntrepreneurProductMedia = createAsyncThunk(
  `entrepreneurProduct/addToEntrepreneurProductMedia`,
  async (
    { store_id, id, body }: { store_id: string; id: string; body: any },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/stores/${store_id}/products/${id}/media`,
        body,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurProduct({ store_id, id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const deleteEntrepreneurProductMedia = createAsyncThunk(
  `entrepreneurProduct/deleteEntrepreneurProductMedia`,
  async (
    {
      store_id,
      mediaId,
      id,
    }: { store_id: string; mediaId: string; id: string },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.delete(
        `/api/entrepreneur/stores/${store_id}/products/${id}/media/${mediaId}`,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurProduct({ store_id, id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: entrepreneurProductState = {
  loading: true,
  dataLoading: true,
  list: {},
  data: null,
  error: null,
};

export const entrepreneurProductSlice = createSlice({
  name: 'entrepreneurProduct',
  initialState,
  reducers: {
    resetEntrepreneurProduct: (state) => {
      return (state = initialState);
    },
    resetEntrepreneurProductDetails: (state) => {
      return (state = {
        ...state,
        data: null,
      });
    },
    updateEntrepreneurProductDetails: (
      state,
      { payload }: PayloadAction<Product>
    ) => {
      return (state = {
        ...state,
        data: {
          ...(state.data ? state.data : {}),
          ...payload,
        },
      });
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getEntrepreneurProducts.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(
        getEntrepreneurProducts.fulfilled,
        (state, { payload }) => {
          state.loading = false;
          state.list = payload;
        }
      ),
      builder.addCase(
        getEntrepreneurProducts.rejected,
        (state, { payload }) => {
          state.loading = false;
          state.error = payload;
        }
      );
    builder.addCase(getEntrepreneurProduct.pending, (state) => {
      state.dataLoading = true;
    }),
      builder.addCase(
        getEntrepreneurProduct.fulfilled,
        (state, { payload }) => {
          state.dataLoading = false;
          state.data = payload;
        }
      ),
      builder.addCase(getEntrepreneurProduct.rejected, (state, { payload }) => {
        state.dataLoading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const {
  resetEntrepreneurProduct,
  updateEntrepreneurProductDetails,
  resetEntrepreneurProductDetails,
} = entrepreneurProductSlice.actions;

export default entrepreneurProductSlice.reducer;
