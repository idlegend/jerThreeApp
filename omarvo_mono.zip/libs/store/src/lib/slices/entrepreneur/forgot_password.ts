import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface forgotPasswordState {
  loading: boolean;
  email: string;
  token: string;
  data: object;
  error: any;
}

export const postEntrepreneurResetPassword = createAsyncThunk(
  'forgotPassword/postEntrepreneurResetPassword',
  async (
    body: { reset_token: string; password: string },
    { rejectWithValue }
  ) => {
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/auth/reset-password`,
        body
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const postEntrepreneurVerifyEmail = createAsyncThunk(
  `forgotPassword/postEntrepreneurVerifyEmail`,
  async (body: { email: string; otp: string }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/auth/forgot-password`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const postEntrepreneurForgotEmail = createAsyncThunk(
  'forgotPassword/postEntrepreneurForgotEmail',
  async (body: { email: string }, { rejectWithValue }) => {
    try {
      const { data } = await axios.post(
        `/api/entrepreneur/auth/send-otp`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: forgotPasswordState = {
  loading: false,
  token: '',
  email: '',
  data: {},
  error: null,
};

export const entrepreneurForgotPasswordSlice = createSlice({
  name: 'forgotPassword',
  initialState,
  reducers: {
    resetEntrepreneurForgotPasswordState: (state) => {
      return (state = initialState);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(postEntrepreneurForgotEmail.pending, (state) => {
        state.loading = true;
      })
      .addCase(postEntrepreneurForgotEmail.fulfilled, (state, { payload }) => {
        state.email = payload;
        state.loading = false;
      })
      .addCase(postEntrepreneurForgotEmail.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(postEntrepreneurVerifyEmail.pending, (state) => {
        state.loading = true;
      })
      .addCase(postEntrepreneurVerifyEmail.fulfilled, (state, { payload }) => {
        state.token = payload;
        state.loading = false;
      })
      .addCase(postEntrepreneurVerifyEmail.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
  },
});

export const { resetEntrepreneurForgotPasswordState } =
  entrepreneurForgotPasswordSlice.actions;

export default entrepreneurForgotPasswordSlice.reducer;
