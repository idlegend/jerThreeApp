import { Victual, getSecureValueFor } from '@omarvo/utils';
import { PayloadAction, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface entrepreneurVictualState {
  loading: boolean;
  dataLoading: boolean;
  list: Record<string, Victual[]>;
  data: Victual | null;
  error: any;
}

export const getEntrepreneurVictuals = createAsyncThunk(
  `entrepreneurVictual/getEntrepreneurVictuals`,
  async (
    { signal, restaurant_id }: { signal?: AbortSignal; restaurant_id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.get(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const createVictual = createAsyncThunk(
  `entrepreneurVictual/createVictual`,
  async (
    { body, restaurant_id }: { body: any; restaurant_id: string },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals`,
        body,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      dispatch(getEntrepreneurVictuals({ restaurant_id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const getEntrepreneurVictual = createAsyncThunk(
  `entrepreneurVictual/getEntrepreneurVictual`,
  async (
    {
      signal,
      restaurant_id,
      id,
    }: { signal?: AbortSignal; restaurant_id: string; id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.get(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals/${id}`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateEntrepreneurVictual = createAsyncThunk(
  `entrepreneurVictual/updateEntrepreneurVictual`,
  async (
    {
      restaurant_id,
      id,
      body,
    }: { restaurant_id: string; id: string; body: any },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.patch(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals/${id}`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurVictual({ id, restaurant_id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateEntrepreneurVictualStockCondition = createAsyncThunk(
  `entrepreneurVictual/updateEntrepreneurVictualStockCondition`,
  async (
    {
      restaurant_id,
      id,
      body,
    }: { restaurant_id: string; id: string; body: { in_stock: boolean } },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.put(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals/${id}`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      dispatch(updateEntrepreneurVictualDetails(data.data));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const deleteEntrepreneurVictual = createAsyncThunk(
  `entrepreneurVictual/deleteEntrepreneurVictual`,
  async (
    { restaurant_id, id }: { restaurant_id: string; id: string },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.delete(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals/${id}`,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurVictuals({ restaurant_id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// selections
export const deleteEntrepreneurVictualSelection = createAsyncThunk(
  `entrepreneurVictual/deleteEntrepreneurVictualSelection`,
  async (
    {
      restaurant_id,
      selectionId,
      id,
    }: { restaurant_id: string; selectionId: string; id: string },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.delete(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals/${id}/selections/${selectionId}`,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurVictual({ restaurant_id, id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Media
export const addToEntrepreneurVictualMedia = createAsyncThunk(
  `entrepreneurVictual/addToEntrepreneurVictualMedia`,
  async (
    {
      restaurant_id,
      id,
      body,
    }: { restaurant_id: string; id: string; body: any },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals/${id}/media`,
        body,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurVictual({ restaurant_id, id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const deleteEntrepreneurVictualMedia = createAsyncThunk(
  `entrepreneurVictual/deleteEntrepreneurVictualMedia`,
  async (
    {
      restaurant_id,
      mediaId,
      id,
    }: { restaurant_id: string; mediaId: string; id: string },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.delete(
        `/api/entrepreneur/restaurants/${restaurant_id}/victuals/${id}/media/${mediaId}`,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      await dispatch(getEntrepreneurVictual({ restaurant_id, id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: entrepreneurVictualState = {
  loading: true,
  dataLoading: true,
  list: {},
  data: null,
  error: null,
};

export const entrepreneurVictualSlice = createSlice({
  name: 'entrepreneurVictual',
  initialState,
  reducers: {
    resetEntrepreneurVictual: (state) => {
      return (state = initialState);
    },
    resetEntrepreneurVictualDetails: (state) => {
      return (state = {
        ...state,
        data: null,
      });
    },
    updateEntrepreneurVictualDetails: (
      state,
      { payload }: PayloadAction<Victual>
    ) => {
      return (state = {
        ...state,
        data: {
          ...(state.data ? state.data : {}),
          ...payload,
        },
      });
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getEntrepreneurVictuals.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(
        getEntrepreneurVictuals.fulfilled,
        (state, { payload }) => {
          state.loading = false;
          state.list = payload;
        }
      ),
      builder.addCase(
        getEntrepreneurVictuals.rejected,
        (state, { payload }) => {
          state.loading = false;
          state.error = payload;
        }
      );
    builder.addCase(getEntrepreneurVictual.pending, (state) => {
      state.dataLoading = true;
    }),
      builder.addCase(
        getEntrepreneurVictual.fulfilled,
        (state, { payload }) => {
          state.dataLoading = false;
          state.data = payload;
        }
      ),
      builder.addCase(getEntrepreneurVictual.rejected, (state, { payload }) => {
        state.dataLoading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const {
  resetEntrepreneurVictual,
  updateEntrepreneurVictualDetails,
  resetEntrepreneurVictualDetails,
} = entrepreneurVictualSlice.actions;

export default entrepreneurVictualSlice.reducer;
