import { EntrepreneurRegisterData, saveSecure } from '@omarvo/utils';
import { PayloadAction, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface regsiterState {
  loading: boolean;
  resending: boolean;
  email: string;
  location: {
    country_id: string;
    state_id: string;
    school_id: string;
    country_name: string;
    phone_code: string;
  };
  error: any;
}

// Define the initial state using that type
const initialState: regsiterState = {
  loading: false,
  resending: false,
  email: '',
  error: null,
  location: {
    country_id: '161',
    school_id: '',
    state_id: '',
    country_name: 'Nigeria',
    phone_code: '+234',
  },
};

export const postEntrepreneurRegister = createAsyncThunk(
  `register/postEntrepreneurRegister`,
  async ({ body }: { body: EntrepreneurRegisterData }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/auth/register`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      return data.data.email;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const postEntrepreneurResendOTP = createAsyncThunk(
  `register/postEntrepreneurResendOTP`,
  async (body: { email: string }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/auth/resend-otp`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const postEntrepreneurVerfifyAccount = createAsyncThunk(
  `register/postEntrepreneurVerfifyAccount`,
  async (body: { email: string; otp: string }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/auth/verify`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      const token = data.data.token;
      await saveSecure('entrepreneurToken', token);
      return data.data;
    } catch (error: any) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);

export const entrepreneurRegisterSlice = createSlice({
  name: 'register',
  initialState,
  reducers: {
    resetEntrepreneurRegisterStates: (state) => {
      return (state = initialState);
    },
    setEntrepreneurLocation: (
      state: regsiterState,
      action: PayloadAction<{ data: any }>
    ) => {
      return {
        ...state,
        location: {
          ...state.location,
          ...action.payload.data,
        },
      };
    },
  },
  extraReducers: (builder) => {
    builder.addCase(postEntrepreneurRegister.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(
        postEntrepreneurRegister.fulfilled,
        (state, { payload }) => {
          state.loading = false;
          state.email = payload;
        }
      ),
      builder.addCase(
        postEntrepreneurRegister.rejected,
        (state, { payload }) => {
          state.loading = false;
          state.error = payload;
        }
      );
    builder.addCase(postEntrepreneurResendOTP.pending, (state) => {
      state.resending = true;
    }),
      builder.addCase(
        postEntrepreneurResendOTP.fulfilled,
        (state, { payload }) => {
          state.resending = false;
          state.email = payload;
        }
      ),
      builder.addCase(
        postEntrepreneurResendOTP.rejected,
        (state, { payload }) => {
          state.resending = false;
          state.error = payload;
        }
      );
    builder.addCase(postEntrepreneurVerfifyAccount.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(
        postEntrepreneurVerfifyAccount.fulfilled,
        (state, { payload }) => {
          state.loading = false;
        }
      ),
      builder.addCase(
        postEntrepreneurVerfifyAccount.rejected,
        (state, { payload }) => {
          state.loading = false;
          state.error = payload;
        }
      );
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetEntrepreneurRegisterStates, setEntrepreneurLocation } =
  entrepreneurRegisterSlice.actions;

export default entrepreneurRegisterSlice.reducer;
