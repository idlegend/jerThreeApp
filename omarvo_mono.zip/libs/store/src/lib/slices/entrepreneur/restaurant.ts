import { Restaurant, getSecureValueFor } from '@omarvo/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface entrepreneurRestaurantState {
  loading: boolean;
  dataLoading: boolean;
  list: Restaurant[];
  data: Restaurant | null;
  error: any;
}

export const getEntrepreneurRestaurants = createAsyncThunk(
  `entrepreneurRestaurant/getEntrepreneurRestaurants`,
  async ({ signal }: { signal?: AbortSignal }, { rejectWithValue }) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.get(`/api/entrepreneur/restaurants`, {
        signal,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const getEntrepreneurRestaurant = createAsyncThunk(
  `entrepreneurRestaurant/getEntrepreneurRestaurant`,
  async (
    { signal, id }: { signal?: AbortSignal; id: string },
    { rejectWithValue }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.get(
        `/api/entrepreneur/restaurants/${id}`,
        {
          signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const createRestaurant = createAsyncThunk(
  `entrepreneurRestaurant/createRestaurant`,
  async (body: any, { rejectWithValue, dispatch }) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/restaurants`,
        body,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      dispatch(getEntrepreneurRestaurants({}));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateRestaurant = createAsyncThunk(
  `entrepreneurRestaurant/updateRestaurant`,
  async (
    { id, body }: { id: string; body: any },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.patch(
        `/api/entrepreneur/restaurants/${id}`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      dispatch(getEntrepreneurRestaurant({ id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateRestaurantBannerImage = createAsyncThunk(
  `entrepreneurRestaurant/updateRestaurantBannerImage`,
  async (
    { id, body }: { id: string; body: any },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.patch(
        `/api/entrepreneur/restaurants/${id}/media`,
        body,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      dispatch(getEntrepreneurRestaurant({ id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateRestaurantActiveCondition = createAsyncThunk(
  `entrepreneurRestaurant/updateRestaurantActiveCondition`,
  async (
    { id, body }: { id: string; body: { is_active: boolean } },
    { rejectWithValue, dispatch }
  ) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.put(
        `/api/entrepreneur/restaurants/${id}`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        }
      );
      dispatch(getEntrepreneurRestaurant({ id }));
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: entrepreneurRestaurantState = {
  loading: true,
  dataLoading: true,
  list: [],
  data: null,
  error: null,
};

export const entrepreneurRestaurantSlice = createSlice({
  name: 'entrepreneurRestaurant',
  initialState,
  reducers: {
    resetEntrepreneurRestaurant: (state) => {
      return (state = initialState);
    },
    resetEntrepreneurRestaurantDetails: (state) => {
      return (state = {
        ...state,
        data: null,
      });
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getEntrepreneurRestaurants.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(
        getEntrepreneurRestaurants.fulfilled,
        (state, { payload }) => {
          state.loading = false;
          state.list = payload;
        }
      ),
      builder.addCase(
        getEntrepreneurRestaurants.rejected,
        (state, { payload }) => {
          state.loading = false;
          state.error = payload;
        }
      );
    builder.addCase(getEntrepreneurRestaurant.pending, (state) => {
      state.dataLoading = true;
    }),
      builder.addCase(
        getEntrepreneurRestaurant.fulfilled,
        (state, { payload }) => {
          state.dataLoading = false;
          state.data = payload;
        }
      ),
      builder.addCase(
        getEntrepreneurRestaurant.rejected,
        (state, { payload }) => {
          state.dataLoading = false;
          state.error = payload;
        }
      );
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const {
  resetEntrepreneurRestaurant,
  resetEntrepreneurRestaurantDetails,
} = entrepreneurRestaurantSlice.actions;

export default entrepreneurRestaurantSlice.reducer;
