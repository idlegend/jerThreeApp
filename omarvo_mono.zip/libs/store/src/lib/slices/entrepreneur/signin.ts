import { saveSecure } from '@omarvo/utils';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface signinState {
  loading: boolean;
  data: object;
  error: any;
}

export const postEntrepreneurSignIn = createAsyncThunk(
  `signin/postEntrepreneurSignIn`,
  async (body: { email: string; password: string }, { rejectWithValue }) => {
    try {
      const { data }: any = await axios.post(
        `/api/entrepreneur/auth/login`,
        body,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      const token = data.data.token;
      await saveSecure('entrepreneurToken', token);
      return data.data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: signinState = {
  loading: true,
  data: {},
  error: null,
};

export const entrepreneurSigninSlice = createSlice({
  name: 'signin',
  initialState,
  reducers: {
    resetEntrepreneurSigninState: (state) => {
      return (state = initialState);
    },
  },
  extraReducers: (builder) => {
    builder.addCase(postEntrepreneurSignIn.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(postEntrepreneurSignIn.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.data = payload;
      }),
      builder.addCase(postEntrepreneurSignIn.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetEntrepreneurSigninState } = entrepreneurSigninSlice.actions;

export default entrepreneurSigninSlice.reducer;
