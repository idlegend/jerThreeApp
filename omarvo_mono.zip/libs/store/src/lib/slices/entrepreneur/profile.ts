import { Entrepreneur, getSecureValueFor } from '@omarvo/utils';
import { PayloadAction, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// Define a type for the slice state
interface entrepreneurProfileState {
  loading: boolean;
  data: Entrepreneur | null;
  error: any;
}

export const getCurrentEntrepreneurProfile = createAsyncThunk(
  `entrepreneurProfile/getCurrentEntrepreneurProfile`,
  async (_, { rejectWithValue }) => {
    const token = await getSecureValueFor('entrepreneurToken');
    try {
      const { data }: any = await axios.get(`/api/entrepreneur/profile`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      return data.data;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Define the initial state using that type
const initialState: entrepreneurProfileState = {
  loading: true,
  data: null,
  error: null,
};

export const entrepreneurProfileSlice = createSlice({
  name: 'entrepreneurProfile',
  initialState,
  reducers: {
    resetEntrepreneur: (state) => {
      return (state = initialState);
    },
    updateEntrepreneurProfile: (
      state,
      { payload }: PayloadAction<Entrepreneur>
    ) => {
      state.data = payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getCurrentEntrepreneurProfile.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(
        getCurrentEntrepreneurProfile.fulfilled,
        (state, { payload }) => {
          state.loading = false;
          state.data = payload;
        }
      ),
      builder.addCase(
        getCurrentEntrepreneurProfile.rejected,
        (state, { payload }) => {
          state.loading = false;
          state.error = payload;
        }
      );
  },
});

// // Other code such as selectors can use the imported `RootState` type
export const { resetEntrepreneur, updateEntrepreneurProfile } =
  entrepreneurProfileSlice.actions;

export default entrepreneurProfileSlice.reducer;
