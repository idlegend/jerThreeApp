import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const useHideBalance = () => {
  const [hideBalance, setHideBalance] = useState(false);

  useEffect(() => {
    (async () => {
      const hideBalance = await AsyncStorage.getItem('@hideBalance');
      setHideBalance(hideBalance === 'true' || false);
    })();
  }, []);

  const toggleHideBalnce = async () => {
    if (hideBalance) {
      await AsyncStorage.setItem('@hideBalance', 'false');
      return setHideBalance(false);
    }

    await AsyncStorage.setItem('@hideBalance', 'true');
    return setHideBalance(true);
  };

  return { hideBalance, toggleHideBalnce };
};

export { useHideBalance };
